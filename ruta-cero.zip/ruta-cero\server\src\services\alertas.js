import { db, listarServicios, usuarioPublico } from '../db.js';
import { enviarNotificacion } from './notificaciones.js';
import {
  CENTRO_CHIHUAHUA,
  enlaceGoogleMaps,
  servicioMasCercano,
  textoDistancia
} from '../utils/geo.js';

const ahoraISO = () => new Date().toISOString();

function horaLocal() {
  try {
    return new Intl.DateTimeFormat('es-MX', {
      dateStyle: 'short',
      timeStyle: 'short',
      timeZone: 'America/Chihuahua'
    }).format(new Date());
  } catch {
    return new Date().toISOString();
  }
}

function mensajePara(tipoDestinatario, usuario, contexto) {
  const { tipoIncidente, enlace, servicio } = contexto;
  const saludo = `${usuario.nombre} (${usuario.modelo_vehiculo}, placas ${usuario.placas})`;
  const cuando = horaLocal();
  const incidente = tipoIncidente === 'emergencia' ? 'POSIBLE ACCIDENTE GRAVE' : tipoIncidente.toUpperCase();

  if (tipoDestinatario === 'contacto') {
    return `RUTA CERO: ${incidente}. ${saludo} activó una alerta. Ubicación: ${enlace} · Hora: ${cuando}. Intenta comunicarte. Si no responde, llama al 911.`;
  }

  if (tipoDestinatario === 'grua') {
    return `RUTA CERO solicita GRÚA. ${saludo}. ${incidente}. Ubicación: ${enlace} · Hora: ${cuando}. Servicio asignado: ${servicio.nombre}.`;
  }

  if (tipoDestinatario === 'transito') {
    return `RUTA CERO solicita apoyo de TRÁNSITO para mantener el flujo vial. ${saludo}. ${incidente}. Ubicación: ${enlace} · Hora: ${cuando}.`;
  }

  if (tipoDestinatario === 'ambulancia') {
    return `RUTA CERO solicita AMBULANCIA. ${saludo}. ${incidente}. Ubicación: ${enlace} · Hora: ${cuando}. Servicio asignado: ${servicio.nombre}.`;
  }

  return `RUTA CERO: alerta de ${usuario.nombre}. Ubicación: ${enlace}`;
}

const ETIQUETAS = {
  contacto: 'Contacto de emergencia',
  grua: 'Grúa',
  transito: 'Tránsito',
  ambulancia: 'Ambulancia'
};

/**
 * Crea la alerta, elige los servicios más cercanos con Haversine, registra los
 * envíos simulados (o SMS reales si Twilio está configurado) y devuelve todo
 * lo necesario para la pantalla de confirmación.
 */
export async function crearAlerta({
  usuario,
  tipo,
  serviciosSolicitados = [],
  lat,
  lng,
  precision = null,
  aproximada = false,
  tipoIncidente = tipo
}) {
  const enlace = enlaceGoogleMaps(lat, lng);
  const catalogo = listarServicios();
  const grupos = {
    grua: catalogo.filter((s) => s.tipo === 'grua'),
    transito: catalogo.filter((s) => s.tipo === 'transito'),
    ambulancia: catalogo.filter((s) => s.tipo === 'ambulancia')
  };

  const asignados = {};
  for (const tipoServicio of serviciosSolicitados) {
    const cercano = servicioMasCercano(grupos[tipoServicio] || [], lat, lng);
    if (cercano) asignados[tipoServicio] = cercano;
  }

  const contexto = { tipoIncidente, enlace };

  const destinos = [];

  if (serviciosSolicitados.includes('contacto')) {
    destinos.push({
      tipo_destinatario: 'contacto',
      nombre: usuario.contacto_emergencia_nombre,
      telefono: usuario.contacto_emergencia_telefono,
      servicio: null,
      mensaje: mensajePara('contacto', usuario, contexto)
    });
  }

  for (const tipoServicio of ['grua', 'transito', 'ambulancia']) {
    // Mantiene el orden de prioridad visual aunque el usuario los marque al azar.
    if (!serviciosSolicitados.includes(tipoServicio)) continue;
    const servicio = asignados[tipoServicio];
    if (!servicio) continue;

    destinos.push({
      tipo_destinatario: tipoServicio,
      nombre: servicio.nombre,
      telefono: servicio.telefono,
      servicio,
      mensaje: mensajePara(tipoServicio, usuario, { ...contexto, servicio })
    });
  }

  const serviciosRegistrados = [
    ...new Set(['contacto', ...serviciosSolicitados.filter((s) => s !== 'contacto')])
  ];

  const mensajeContacto =
    destinos.find((d) => d.tipo_destinatario === 'contacto')?.mensaje || '';

  const insertarAlerta = db.prepare(`
    INSERT INTO alertas (
      usuario_id, tipo, servicios_solicitados, latitud, longitud,
      precision_metros, ubicacion_aproximada, estado, mensaje, creado_en
    ) VALUES (
      @usuario_id, @tipo, @servicios_solicitados, @latitud, @longitud,
      @precision_metros, @ubicacion_aproximada, @estado, @mensaje, @creado_en
    )
  `);

  const resultadoAlerta = insertarAlerta.run({
    usuario_id: usuario.id,
    tipo,
    servicios_solicitados: JSON.stringify(serviciosRegistrados),
    latitud: lat,
    longitud: lng,
    precision_metros: precision,
    ubicacion_aproximada: aproximada ? 1 : 0,
    estado: 'Enviado',
    mensaje: mensajeContacto || `Alerta ${tipo} registrada.`,
    creado_en: ahoraISO()
  });

  const alertaId = Number(resultadoAlerta.lastInsertRowid);

  const insertarEnvio = db.prepare(`
    INSERT INTO envios (
      alerta_id, tipo_destinatario, destinatario_nombre, destinatario_telefono,
      servicio_id, estado, canal, detalle, creado_en
    ) VALUES (
      @alerta_id, @tipo_destinatario, @destinatario_nombre, @destinatario_telefono,
      @servicio_id, @estado, @canal, @detalle, @creado_en
    )
  `);

  const envios = await Promise.all(
    destinos.map(async (destino) => {
      let envio;
      try {
        envio = await enviarNotificacion({
          telefono: destino.telefono,
          mensaje: destino.mensaje,
          destinatario: destino.nombre
        });
      } catch {
        envio = {
          estado: 'Enviado',
          canal: 'simulado',
          detalle: 'Notificación registrada en modo simulado.'
        };
      }

      const creado = ahoraISO();
      const fila = insertarEnvio.run({
        alerta_id: alertaId,
        tipo_destinatario: destino.tipo_destinatario,
        destinatario_nombre: destino.nombre,
        destinatario_telefono: destino.telefono,
        servicio_id: destino.servicio?.id ?? null,
        estado: envio.estado,
        canal: envio.canal,
        detalle: envio.detalle,
        creado_en: creado
      });

      return {
        id: Number(fila.lastInsertRowid),
        alerta_id: alertaId,
        tipo_destinatario: destino.tipo_destinatario,
        etiqueta: ETIQUETAS[destino.tipo_destinatario],
        destinatario_nombre: destino.nombre,
        destinatario_telefono: destino.telefono,
        estado: envio.estado,
        canal: envio.canal,
        detalle: envio.detalle,
        creado_en: creado,
        mensaje: destino.mensaje,
        servicio: destino.servicio
          ? {
              id: destino.servicio.id,
              tipo: destino.servicio.tipo,
              nombre: destino.servicio.nombre,
              telefono: destino.servicio.telefono,
              direccion: destino.servicio.direccion,
              latitud: destino.servicio.latitud,
              longitud: destino.servicio.longitud,
              distancia_km: destino.servicio.distancia_km,
              distancia_texto: textoDistancia(destino.servicio.distancia_km),
              eta_min: destino.servicio.eta_min
            }
          : null
      };
    })
  );

  const serviciosMapa = Object.values(asignados).map((servicio) => ({
    id: servicio.id,
    tipo: servicio.tipo,
    nombre: servicio.nombre,
    telefono: servicio.telefono,
    latitud: servicio.latitud,
    longitud: servicio.longitud,
    distancia_km: servicio.distancia_km,
    distancia_texto: textoDistancia(servicio.distancia_km),
    eta_min: servicio.eta_min
  }));

  return {
    alerta: {
      id: alertaId,
      usuario_id: usuario.id,
      tipo,
      servicios_solicitados: serviciosRegistrados,
      latitud: lat,
      longitud: lng,
      precision_metros: precision,
      ubicacion_aproximada: Boolean(aproximada),
      estado: 'Enviado',
      creado_en: ahoraISO()
    },
    usuario: usuarioPublico(usuario),
    envios,
    servicios: serviciosMapa,
    ubicacion: {
      lat,
      lng,
      precision,
      aproximada: Boolean(aproximada),
      ciudad: aproximada ? 'Chihuahua (referencia)' : 'Ubicación del dispositivo',
      google_maps: enlace
    },
    mensaje_contacto: mensajeContacto,
    simulado: envios.every((envio) => envio.canal === 'simulado')
  };
}

/** Alertas recientes de un usuario, con el detalle de cada envío. */
export function listarAlertas(usuarioId, limite = 20) {
  const alertas = db
    .prepare(
      `SELECT * FROM alertas
       WHERE usuario_id = ?
       ORDER BY datetime(creado_en) DESC, id DESC
       LIMIT ?`
    )
    .all(usuarioId, limite);

  const enviosStmt = db.prepare(
    'SELECT * FROM envios WHERE alerta_id = ? ORDER BY id ASC'
  );

  return alertas.map((alerta) => {
    let servicios = [];
    try {
      servicios = JSON.parse(alerta.servicios_solicitados);
    } catch {
      servicios = [];
    }

    return {
      id: alerta.id,
      usuario_id: alerta.usuario_id,
      tipo: alerta.tipo,
      servicios_solicitados: Array.isArray(servicios) ? servicios : [],
      latitud: alerta.latitud,
      longitud: alerta.longitud,
      precision_metros: alerta.precision_metros,
      ubicacion_aproximada: Boolean(alerta.ubicacion_aproximada),
      estado: alerta.estado,
      mensaje: alerta.mensaje,
      creado_en: alerta.creado_en,
      google_maps: enlaceGoogleMaps(alerta.latitud, alerta.longitud),
      envios: enviosStmt.all(alerta.id).map((envio) => ({
        id: envio.id,
        tipo_destinatario: envio.tipo_destinatario,
        etiqueta: ETIQUETAS[envio.tipo_destinatario] || envio.tipo_destinatario,
        destinatario_nombre: envio.destinatario_nombre,
        destinatario_telefono: envio.destinatario_telefono,
        estado: envio.estado,
        canal: envio.canal,
        detalle: envio.detalle,
        creado_en: envio.creado_en
      }))
    };
  });
}
