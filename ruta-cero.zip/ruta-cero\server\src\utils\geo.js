/** Utilidades geográficas: distancia Haversine, servicio más cercano y tiempos estimados. */

const RADIO_TIERRA_KM = 6371;

const aRadianes = (grados) => (grados * Math.PI) / 180;

/** Distancia en kilómetros entre dos coordenadas usando la fórmula de Haversine. */
export function distanciaKm(a, b) {
  const dLat = aRadianes(b.lat - a.lat);
  const dLng = aRadianes(b.lng - a.lng);
  const lat1 = aRadianes(a.lat);
  const lat2 = aRadianes(b.lat);

  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;

  return 2 * RADIO_TIERRA_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Tiempo estimado de llegada en minutos (velocidad urbana promedio configurable). */
export function minutosEstimados(km, velocidadPromedio = 28) {
  return Math.max(2, Math.round((km / velocidadPromedio) * 60));
}

/** Devuelve el servicio más cercano de una lista, con distancia y ETA. */
export function servicioMasCercano(servicios, lat, lng) {
  if (!servicios?.length) return null;

  return servicios
    .map((servicio) => {
      const km = distanciaKm(
        { lat, lng },
        { lat: servicio.latitud, lng: servicio.longitud }
      );
      return {
        ...servicio,
        distancia_km: Number(km.toFixed(2)),
        eta_min: minutosEstimados(km)
      };
    })
    .sort((a, b) => a.distancia_km - b.distancia_km)[0];
}

/** Centro aproximado de Chihuahua para mapas y datos simulados. */
export const CENTRO_CHIHUAHUA = { lat: 28.6353, lng: -106.0889 };

/** Enlace de Google Maps con las coordenadas de la alerta. */
export function enlaceGoogleMaps(lat, lng) {
  return `https://www.google.com/maps?q=${Number(lat).toFixed(6)},${Number(lng).toFixed(6)}`;
}

/** Formatea una distancia para mostrarla en español. */
export function textoDistancia(km) {
  return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`;
}
