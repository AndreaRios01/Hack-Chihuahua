import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/** Raíz del proyecto (carpeta que contiene client/, server/ y package.json). */
export const RAIZ = path.resolve(__dirname, '../..');

// Carga .env desde la raíz del proyecto. No falla si no existe.
dotenv.config({ path: path.join(RAIZ, '.env'), quiet: true });

const archivo = process.env.DB_ARCHIVO || 'ruta_cero.db';

export const PUERTO = Number(process.env.PUERTO) || 4000;
export const DB_RUTA = path.isAbsolute(archivo) ? archivo : path.join(RAIZ, archivo);
export const ORIGEN_CLIENTE = process.env.ORIGEN_CLIENTE || 'http://localhost:5173';

/** Ubicación de respaldo: centro de Chihuahua, Chihuahua, México. */
export const UBICACION_REFERENCIA = {
  lat: 28.6353,
  lng: -106.0889,
  ciudad: 'Chihuahua, Chihuahua, México'
};

export const TWILIO = {
  sid: process.env.TWILIO_ACCOUNT_SID || '',
  token: process.env.TWILIO_AUTH_TOKEN || '',
  desde: process.env.TWILIO_FROM || ''
};

export const twilioConfigurado = () =>
  Boolean(TWILIO.sid && TWILIO.token && TWILIO.desde);
