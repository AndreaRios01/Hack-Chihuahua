import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSesion } from '../context/SesionContexto.jsx';
import { useUbicacion } from '../hooks/useUbicacion.js';
import { api } from '../lib/api.js';
import { esDispositivoMovil } from '../lib/formato.js';
import { guardarResultado } from '../lib/sesion.js';
import BotonVolver from '../components/BotonVolver.jsx';
import IndicadorUbicacion from '../components/IndicadorUbicacion.jsx';
import Aviso from '../components/Aviso.jsx';
import {
  IconoAmbulancia,
  IconoCheck,
  IconoChoque,
  IconoGrua,
  IconoTransito
} from '../components/Iconos.jsx';

const OPCIONES_SERVICIO = [
  {
    tipo: 'ambulancia',
    titulo: 'Ambulancia',
    descripcion: 'Atención médica y traslado',
    Icono: IconoAmbulancia
  },
  {
    tipo: 'grua',
    titulo: 'Grúa',
    descripcion: 'Arrastre y apoyo mecánico',
    Icono: IconoGrua
  },
  {
    tipo: 'transito',
    titulo: 'Tránsito',
    descripcion: 'Control vial y peritaje',
    Icono: IconoTransito
  }
];

export default function Choque() {
  const navigate = useNavigate();
  const { usuario } = useSesion();
  const { ubicacion, estado, solicitar } = useUbicacion();

  const [tipo, setTipo] = useState('choque');
  const [servicios, setServicios] = useState([]);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    document.title = 'Choque · RUTA CERO';
  }, []);

  const alternarServicio = (tipoServicio) => {
    setServicios((previos) =>
      previos.includes(tipoServicio)
        ? previos.filter((servicio) => servicio !== tipoServicio)
        : [...previos, tipoServicio]
    );
    setError(null);
  };

  const alLlamar = async () => {
    if (servicios.length === 0 || enviando) {
      setError('Marca al menos un servicio para poder llamar.');
      return;
    }

    setEnviando(true);
    setError(null);

    try {
      const ubi = ubicacion || (await solicitar());

      const datos = await api.choque({
        usuario_id: usuario.id,
        tipo,
        servicios,
        latitud: ubi.lat,
        longitud: ubi.lng,
        precision: ubi.precision,
        aproximada: ubi.aproximada
      });

      guardarResultado({
        ...datos,
        marcar_al_llegar: esDispositivoMovil(),
        origen: 'choque'
      });

      navigate('/resultado');
    } catch (fallo) {
      setError(fallo.message);
    } finally {
      setEnviando(false);
    }
  };

  const puedeLlamar = servicios.length > 0 && !enviando;

  return (
    <main className="pantalla pantalla-interior">
      <header className="barra-superior">
        <BotonVolver />
        <div className="barra-titulo">
          <span>Reportar incidente</span>
          <h1>Choque o accidente</h1>
        </div>
      </header>

      <div className="contenido-interior">
        <section aria-labelledby="titulo-tipo">
          <div className="paso-cabecera">
            <span className="paso-numero" aria-hidden="true">
              1
            </span>
            <div>
              <h2 id="titulo-tipo">¿Qué ocurrió?</h2>
              <p>Elige una opción. Podrás cambiarla antes de llamar.</p>
            </div>
          </div>

          <div className="opciones-tipo" role="radiogroup" aria-labelledby="titulo-tipo">
            <label
              className={`opcion-tipo ${tipo === 'choque' ? 'opcion-activa' : ''}`.trim()}
            >
              <input
                type="radio"
                name="tipo-incidente"
                value="choque"
                checked={tipo === 'choque'}
                onChange={() => setTipo('choque')}
              />
              <span className="tipo-icono" aria-hidden="true">
                <IconoChoque size={26} />
              </span>
              <span className="tipo-texto">
                <strong>Choque</strong>
                <small>Daños materiales</small>
              </span>
              <span className="tipo-marca" aria-hidden="true">
                {tipo === 'choque' ? <IconoCheck size={18} /> : null}
              </span>
            </label>

            <label
              className={`opcion-tipo ${tipo === 'accidente' ? 'opcion-activa' : ''}`.trim()}
            >
              <input
                type="radio"
                name="tipo-incidente"
                value="accidente"
                checked={tipo === 'accidente'}
                onChange={() => setTipo('accidente')}
              />
              <span className="tipo-icono" aria-hidden="true">
                <IconoAmbulancia size={26} />
              </span>
              <span className="tipo-texto">
                <strong>Accidente</strong>
                <small>Personas involucradas</small>
              </span>
              <span className="tipo-marca" aria-hidden="true">
                {tipo === 'accidente' ? <IconoCheck size={18} /> : null}
              </span>
            </label>
          </div>

          <p className="nota-contexto">
            {tipo === 'accidente'
              ? 'Además de los servicios marcados, avisaremos a tu contacto de emergencia.'
              : 'Solo se notificará a los servicios que marques abajo.'}
          </p>
        </section>

        <section aria-labelledby="titulo-servicios">
          <div className="paso-cabecera">
            <span className="paso-numero" aria-hidden="true">
              2
            </span>
            <div>
              <h2 id="titulo-servicios">¿Qué necesitas?</h2>
              <p>Puedes marcar varios servicios.</p>
            </div>
          </div>

          <div className="lista-servicios">
            {OPCIONES_SERVICIO.map(({ tipo: tipoServicio, titulo, descripcion, Icono }) => {
              const activo = servicios.includes(tipoServicio);
              return (
                <label
                  key={tipoServicio}
                  className={`opcion-servicio ${activo ? 'opcion-activa' : ''}`.trim()}
                >
                  <span className={`servicio-icono servicio-${tipoServicio}`} aria-hidden="true">
                    <Icono size={24} />
                  </span>
                  <span className="servicio-texto">
                    <strong>{titulo}</strong>
                    <small>{descripcion}</small>
                  </span>
                  <input
                    type="checkbox"
                    name="servicios"
                    value={tipoServicio}
                    checked={activo}
                    onChange={() => alternarServicio(tipoServicio)}
                  />
                </label>
              );
            })}
          </div>

          <p className="contador-seleccion" aria-live="polite">
            {servicios.length === 0
              ? 'Ningún servicio seleccionado todavía.'
              : `${servicios.length} servicio${servicios.length === 1 ? '' : 's'} seleccionado${servicios.length === 1 ? '' : 's'}.`}
            {tipo === 'accidente' ? ' Se avisará también a tu contacto.' : ''}
          </p>
        </section>

        <section aria-labelledby="titulo-ubicacion-choque">
          <div className="paso-cabecera">
            <span className="paso-numero" aria-hidden="true">
              3
            </span>
            <div>
              <h2 id="titulo-ubicacion-choque">Tu ubicación</h2>
              <p>La usamos para elegir el servicio más cercano con Haversine.</p>
            </div>
          </div>
          <IndicadorUbicacion
            ubicacion={ubicacion}
            estado={estado}
            solicitar={solicitar}
          />
          {ubicacion?.aproximada ? (
            <Aviso tipo="aviso" className="aviso-compacto">
              {ubicacion.motivo ||
                'No tenemos tu GPS. Usaremos el centro de Chihuahua como referencia.'}
            </Aviso>
          ) : null}
        </section>

        {error ? (
          <Aviso tipo="error" onCerrar={() => setError(null)}>
            {error}
          </Aviso>
        ) : null}
      </div>

      <div className="barra-accion-fija">
        <button
          type="button"
          className="boton boton-amarillo boton-grande boton-ancho boton-llamar"
          onClick={alLlamar}
          disabled={!puedeLlamar}
          aria-describedby="ayuda-llamar"
        >
          {enviando ? (
            <>
              <span className="girador girador-boton" aria-hidden="true" />
              CONTACTANDO SERVICIOS…
            </>
          ) : (
            'LLAMAR'
          )}
        </button>
        <p id="ayuda-llamar" className="nota-accion">
          {servicios.length === 0
            ? 'Marca al menos un servicio para activar LLAMAR.'
            : tipo === 'accidente'
              ? 'Se registrará el accidente y se avisará a tu contacto.'
              : 'Se registrará el reporte y la solicitud a los servicios.'}
        </p>
        <p className="nota-accion nota-accion-suave">
          Comunicación simulada · En celular se abrirá el marcador con un número
          de demostración.
        </p>
      </div>
    </main>
  );
}
