export default function Campo({
  id,
  label,
  valor,
  onChange,
  tipo = 'text',
  error,
  ayuda,
  placeholder,
  inputMode,
  autoComplete,
  maxLength,
  minLength,
  required = true,
  disabled = false,
  prefijo,
  autoFocus = false
}) {
  const idError = `${id}-error`;
  const idAyuda = `${id}-ayuda`;

  const descrito = error ? idError : ayuda ? idAyuda : undefined;

  return (
    <div className={`campo ${error ? 'campo-con-error' : ''}`.trim()}>
      <label htmlFor={id}>
        {label}
        {required ? (
          <span className="campo-obligatorio" aria-hidden="true">
            {' '}
            *
          </span>
        ) : null}
      </label>

      <div className={`entrada-envoltura ${prefijo ? 'entrada-con-prefijo' : ''}`.trim()}>
        {prefijo ? (
          <span className="entrada-prefijo" aria-hidden="true">
            {prefijo}
          </span>
        ) : null}
        <input
          id={id}
          name={id}
          type={tipo}
          value={valor}
          onChange={(evento) => onChange(evento.target.value)}
          placeholder={placeholder}
          inputMode={inputMode}
          autoComplete={autoComplete}
          maxLength={maxLength}
          minLength={minLength}
          required={required}
          disabled={disabled}
          autoFocus={autoFocus}
          aria-invalid={error ? 'true' : undefined}
          aria-describedby={descrito}
          className="entrada"
        />
      </div>

      {error ? (
        <p id={idError} className="campo-error" role="alert">
          {error}
        </p>
      ) : ayuda ? (
        <p id={idAyuda} className="campo-ayuda">
          {ayuda}
        </p>
      ) : null}
    </div>
  );
}
