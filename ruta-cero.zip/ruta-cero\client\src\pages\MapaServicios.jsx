import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useUbicacion } from '../hooks/useUbicacion.js';
import { api } from '../lib/api.js';
import { UBICACION_REFERENCIA } from '../lib/ubicacion.js';
import { formatearTelefono } from '../lib/formato.js';
import BotonVolver from '../components/BotonVolver.jsx';
import Aviso, { Cargador } from '../components/Aviso.jsx';
import IndicadorUbicacion from '../components/IndicadorUbicacion.jsx';
import Mapa from '../components/Mapa.jsx';
import {
  IconoActualizar,
  IconoAmbulancia,
  IconoGrua,
  IconoMapa,
  IconoRuta,
  IconoTelefono,
  IconoTrafico,
  IconoTransito
} from '../components/Iconos.jsx';

const ICONOS = {
  grua: IconoGrua,
  transito: IconoTransito,
  ambulancia: IconoAmbulancia
};

const NOMBRES = {
  grua: 'Grúa más cercana',
  transito: 'Tránsito más cercano',
  ambulancia: 'Ambulancia más cercana'
};

export default function MapaServicios() {
  const { ubicacion, estado, solicitar } = useUbicacion();

  const [cercanos, setCercanos] = useState(null);
  const [trafico, setTrafico] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);
  const [refresco, setRefresco] = useState(0);

  useEffect(() => {
    document.title = 'Mapa y tráfico · RUTA CERO';
  }, []);

  const lat = ubicacion?.lat ?? UBICACION_REFERENCIA.lat;
  const lng = ubicacion?.lng ?? UBICACION_REFERENCIA.lng;

  useEffect(() => {
    let activo = true;
    setCargando(true);
    setError(null);

    Promise.all([api.cercanos(lat, lng), api.trafico()])
      .then(([datosCercanos, datosTrafico]) => {
        if (!activo) return;
        setCercanos(datosCercanos);
        setTrafico(datosTrafico);
      })
      .catch((fallo) => {
        if (activo) setError(fallo.message);
      })
      .finally(() => {
        if (activo) setCargando(false);
      });

    return () => {
      activo = false;
    };
  }, [lat, lng, refresco]);

  const actualizar = () => {
    setRefresco((valor) => valor + 1);
    if (!ubicacion) solicitar();
  };

  const puntoUsuario =
    ubicacion && !ubicacion.aproximada
      ? {
          lat: ubicacion.lat,
          lng: ubicacion.lng,
          precision: ubicacion.precision
        }
      : null;

  return (
    <main className="pantalla pantalla-interior">
      <header className="barra-superior">
        <BotonVolver />
        <div className="barra-titulo">
          <span>Espacio inteligente</span>
          <h1>Mapa y tráfico</h1>
        </div>
        <button
          type="button"
          className="boton-icono boton-icono-chico"
          onClick={actualizar}
          aria-label="Actualizar servicios y tráfico"
          disabled={cargando}
        >
          <IconoActualizar size={20} aria-hidden="true" />
        </button>
      </header>

      <div className="contenido-interior">
        <div className="fila-ubicacion">
          <IndicadorUbicacion
            ubicacion={ubicacion}
            estado={estado}
            solicitar={solicitar}
          />
          {cargando ? <Cargador texto="Calculando…" compacto /> : null}
        </div>

        {error ? (
          <Aviso tipo="error" titulo="No pudimos cargar el mapa" onCerrar={() => setError(null)}>
            {error}{' '}
            <button type="button" className="enlace-texto" onClick={actualizar}>
              Reintentar
            </button>
          </Aviso>
        ) : null}

        <Aviso tipo="info" titulo="Tráfico simulado">
          Este indicador no usa APIs externas: los niveles se generan localmente
          para demostrar optimización de rutas. El mapa sí es real
          (OpenStreetMap).
        </Aviso>

        <section aria-labelledby="titulo-mapa-red">
          <div className="bloque-cabecera">
            <h2 id="titulo-mapa-red">Red de servicios en Chihuahua</h2>
            <span className="contador-chip">
              {cercanos?.servicios?.length ?? 0}
            </span>
          </div>
          <Mapa
            usuario={puntoUsuario}
            servicios={cercanos?.servicios || []}
            trafico={trafico?.corredores || []}
            conexiones={false}
            alto={330}
            zoom={12}
            etiqueta="Mapa de grúas, tránsito, ambulancias y tráfico simulado"
          />
          {!puntoUsuario ? (
            <p className="nota-pie">
              No tenemos tu GPS real: el mapa y las distancias usan el centro de
              Chihuahua como referencia.
            </p>
          ) : null}
        </section>

        <section aria-labelledby="titulo-cercanos">
          <div className="bloque-cabecera">
            <h2 id="titulo-cercanos">Servicios más cercanos</h2>
          </div>

          <div className="tarjetas-servicio">
            {['grua', 'transito', 'ambulancia'].map((tipo) => {
              const servicio = cercanos?.grupos?.[tipo];
              const Icono = ICONOS[tipo];
              if (!servicio) {
                return (
                  <div className="tarjeta-servicio tarjeta-servicio-vacia" key={tipo}>
                    <div className="esqueleto esqueleto-chico" />
                  </div>
                );
              }

              return (
                <article className="tarjeta-servicio" key={tipo}>
                  <span className={`servicio-icono servicio-${tipo}`} aria-hidden="true">
                    <Icono size={22} />
                  </span>
                  <div className="tarjeta-servicio-cuerpo">
                    <span className="tarjeta-servicio-kicker">{NOMBRES[tipo]}</span>
                    <strong>{servicio.nombre}</strong>
                    <span className="tarjeta-servicio-meta">
                      {servicio.distancia_texto} · ≈ {servicio.eta_min} min
                    </span>
                    <a
                      className="enlace-telefono"
                      href={`tel:${servicio.telefono}`}
                      aria-label={`Llamar a ${servicio.nombre} (número demo)`}
                    >
                      <IconoTelefono size={14} aria-hidden="true" />
                      {formatearTelefono(servicio.telefono)}
                    </a>
                  </div>
                </article>
              );
            })}
          </div>
          <p className="nota-pie">
            Catálogo y teléfonos ficticios. Distancias con fórmula de Haversine.
          </p>
        </section>

        <section className="bloque" aria-labelledby="titulo-trafico">
          <div className="bloque-cabecera">
            <h2 id="titulo-trafico">Indicador de tráfico</h2>
            <span className="insignia insignia-suave">SIMULADO</span>
          </div>

          {trafico?.ruta_sugerida ? (
            <div className="ruta-sugerida">
              <span className="ruta-sugerida-icono" aria-hidden="true">
                <IconoRuta size={26} />
              </span>
              <div>
                <span className="ruta-sugerida-kicker">RUTA SUGERIDA</span>
                <h3>{trafico.ruta_sugerida.nombre}</h3>
                <p>
                  {trafico.ruta_sugerida.nivel} · demora estimada{' '}
                  {trafico.ruta_sugerida.demora_min} min · ahorro aprox.{' '}
                  {trafico.ruta_sugerida.ahorro_estimado_min} min
                </p>
              </div>
            </div>
          ) : null}

          {trafico?.indice_general ? (
            <p className="indice-trafico">
              Índice general: <strong>{trafico.indice_general.nivel}</strong> (
              {trafico.indice_general.porcentaje}%)
            </p>
          ) : null}

          <ul className="lista-trafico">
            {(trafico?.corredores || []).map((corredor) => (
              <li key={corredor.id}>
                <div className="trafico-cabecera">
                  <strong>{corredor.nombre}</strong>
                  <span style={{ color: corredor.color }}>
                    {corredor.nivel} · {corredor.porcentaje}%
                  </span>
                </div>
                <div className="trafico-barra">
                  <span
                    style={{
                      width: `${corredor.porcentaje}%`,
                      background: corredor.color
                    }}
                  />
                </div>
                <div className="trafico-meta">
                  <span>{corredor.sentido}</span>
                  <span>
                    {corredor.velocidad_estimada_kmh} km/h · +
                    {corredor.demora_min} min
                  </span>
                </div>
              </li>
            ))}
          </ul>

          <p className="nota-pie">
            <IconoTrafico size={14} aria-hidden="true" /> Los niveles de tráfico
            son una simulación determinista generada por el servidor. No son
            datos de tráfico en tiempo real.
          </p>
        </section>

        <Link to="/inicio" className="boton boton-secundario boton-ancho">
          <IconoMapa size={18} aria-hidden="true" /> VOLVER AL INICIO
        </Link>
      </div>
    </main>
  );
}
