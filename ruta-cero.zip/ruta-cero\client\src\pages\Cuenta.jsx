import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSesion } from '../context/SesionContexto.jsx';
import { api } from '../lib/api.js';
import { borrarResultado } from '../lib/sesion.js';
import {
  ETIQUETAS_ALERTA,
  ETIQUETAS_SERVICIO,
  formatearFecha,
  formatearTelefono
} from '../lib/formato.js';
import BotonVolver from '../components/BotonVolver.jsx';
import TarjetaLicencia from '../components/TarjetaLicencia.jsx';
import Aviso from '../components/Aviso.jsx';
import Modal from '../components/Modal.jsx';
import {
  IconoActualizar,
  IconoAlerta,
  IconoBasura,
  IconoCheckCirculo,
  IconoEditar,
  IconoMapa,
  IconoRuta,
  IconoSalir
} from '../components/Iconos.jsx';

export default function Cuenta() {
  const { usuario, cerrarSesion } = useSesion();
  const navigate = useNavigate();
  const location = useLocation();

  const [alertas, setAlertas] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [errorHistorial, setErrorHistorial] = useState(null);
  const [refresco, setRefresco] = useState(0);

  const [modalBaja, setModalBaja] = useState(false);
  const [procesandoBaja, setProcesandoBaja] = useState(false);
  const [errorBaja, setErrorBaja] = useState(null);
  const [aviso, setAviso] = useState(
    location.state?.actualizado
      ? 'Tus datos se actualizaron correctamente.'
      : null
  );

  useEffect(() => {
    document.title = 'Mi cuenta · RUTA CERO';
  }, []);

  useEffect(() => {
    let activo = true;
    setCargando(true);
    setErrorHistorial(null);

    api
      .alertas(usuario.id)
      .then((respuesta) => {
        if (activo) setAlertas(respuesta.alertas || []);
      })
      .catch((fallo) => {
        if (activo) setErrorHistorial(fallo.message);
      })
      .finally(() => {
        if (activo) setCargando(false);
      });

    return () => {
      activo = false;
    };
  }, [usuario.id, refresco]);

  const confirmarBaja = async () => {
    setProcesandoBaja(true);
    setErrorBaja(null);

    try {
      await api.darDeBaja(usuario.id);
      borrarResultado();
      cerrarSesion();
      navigate('/', {
        replace: true,
        state: {
          aviso:
            'El automóvil quedó dado de baja. Puedes registrarte de nuevo con el mismo teléfono cuando quieras.'
        }
      });
    } catch (fallo) {
      setErrorBaja(fallo.message);
      setProcesandoBaja(false);
    }
  };

  const salir = () => {
    cerrarSesion();
    navigate('/', { replace: true });
  };

  return (
    <main className="pantalla pantalla-interior">
      <header className="barra-superior">
        <BotonVolver />
        <div className="barra-titulo">
          <span>Tu espacio</span>
          <h1>Mi cuenta</h1>
        </div>
      </header>

      <div className="contenido-interior">
        {aviso ? (
          <Aviso tipo="exito" onCerrar={() => setAviso(null)}>
            {aviso}
          </Aviso>
        ) : null}

        <section aria-labelledby="titulo-licencia">
          <div className="bloque-cabecera bloque-cabecera-simple">
            <h2 id="titulo-licencia">Licencia de demostración</h2>
            <span className="insignia insignia-suave">Vehículo activo</span>
          </div>
          <TarjetaLicencia usuario={usuario} />
          <p className="nota-pie">
            Documento ficticio con fines de demostración. No es una licencia
            oficial ni reproduce el diseño de un documento real.
          </p>
        </section>

        <div className="cuenta-acciones">
          <Link
            to="/cuenta/editar"
            className="boton boton-secundario boton-accion-cuenta"
            aria-label="Actualizar mis datos y los del vehículo"
          >
            <IconoEditar size={20} aria-hidden="true" />
            <span>ACTUALIZAR</span>
          </Link>
          <button
            type="button"
            className="boton boton-peligro-suave boton-accion-cuenta"
            onClick={() => {
              setErrorBaja(null);
              setModalBaja(true);
            }}
            aria-label="Dar de baja el automóvil"
          >
            <IconoBasura size={20} aria-hidden="true" />
            <span>
              DAR DE BAJA
              <br />
              EL AUTOMÓVIL
            </span>
          </button>
        </div>

        <section className="bloque" aria-labelledby="titulo-historial">
          <div className="bloque-cabecera">
            <h2 id="titulo-historial">Tus alertas recientes</h2>
            <button
              type="button"
              className="boton-refrescar"
              onClick={() => setRefresco((valor) => valor + 1)}
              aria-label="Actualizar historial de alertas"
              disabled={cargando}
            >
              <IconoActualizar size={18} aria-hidden="true" />
            </button>
          </div>

          {cargando ? (
            <div className="lista-esqueletos" aria-label="Cargando alertas">
              <div className="esqueleto" />
              <div className="esqueleto" />
            </div>
          ) : errorHistorial ? (
            <Aviso tipo="error" titulo="No pudimos cargar tu historial">
              {errorHistorial}{' '}
              <button
                type="button"
                className="enlace-texto"
                onClick={() => setRefresco((valor) => valor + 1)}
              >
                Reintentar
              </button>
            </Aviso>
          ) : alertas.length === 0 ? (
            <div className="vacio vacio-compacto">
              <span className="vacio-icono" aria-hidden="true">
                <IconoAlerta size={26} />
              </span>
              <p>Todavía no has enviado alertas desde esta cuenta.</p>
            </div>
          ) : (
            <ul className="lista-alertas">
              {alertas.map((alerta) => (
                <li key={alerta.id} className="alerta-item">
                  <div className="alerta-cabecera">
                    <span className={`chip-tipo chip-${alerta.tipo}`}>
                      {ETIQUETAS_ALERTA[alerta.tipo] || alerta.tipo}
                    </span>
                    <span className="alerta-fecha">
                      {formatearFecha(alerta.creado_en)}
                    </span>
                  </div>

                  <p className="alerta-resumen">
                    Alerta #{alerta.id} · {alerta.estado} ·{' '}
                    {alerta.envios.length} envío
                    {alerta.envios.length === 1 ? '' : 's'}
                  </p>

                  <div className="chips-servicios">
                    {(alerta.servicios_solicitados || []).map((servicio) => (
                      <span key={servicio} className="chip-servicio">
                        {ETIQUETAS_SERVICIO[servicio] || servicio}
                      </span>
                    ))}
                  </div>

                  {alerta.ubicacion_aproximada ? (
                    <p className="alerta-nota">
                      Ubicación de referencia (Chihuahua), sin GPS.
                    </p>
                  ) : null}

                  <details className="mensaje-detalle">
                    <summary>Ver destinatarios y envíos</summary>
                    <ul className="detalle-envios">
                      {alerta.envios.map((envio) => (
                        <li key={envio.id}>
                          <IconoCheckCirculo size={15} aria-hidden="true" />
                          <span>
                            <strong>{envio.destinatario_nombre}</strong> ·{' '}
                            {envio.etiqueta}
                            {envio.destinatario_telefono
                              ? ` · ${formatearTelefono(envio.destinatario_telefono)}`
                              : ''}
                          </span>
                          <span className="insignia insignia-exito">
                            {envio.estado}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </details>

                  <a
                    className="enlace-mapa-alerta"
                    href={alerta.google_maps}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <IconoMapa size={15} aria-hidden="true" /> Ver ubicación en
                    Google Maps
                  </a>
                </li>
              ))}
            </ul>
          )}
        </section>

        <Link to="/mapa" className="tarjeta-enlace">
          <span className="tarjeta-enlace-icono" aria-hidden="true">
            <IconoRuta size={24} />
          </span>
          <span>
            <strong>Mapa y tráfico simulado</strong>
            <small>
              Consulta grúas cercanas, corredores y una ruta sugerida.
            </small>
          </span>
          <span aria-hidden="true">→</span>
        </Link>

        <div className="cuenta-pie">
          <p>
            Sesión iniciada como {usuario.nombre} ·{' '}
            {formatearTelefono(usuario.telefono)}
          </p>
          <button type="button" className="enlace-salir" onClick={salir}>
            <IconoSalir size={16} aria-hidden="true" /> Cerrar sesión
          </button>
        </div>
      </div>

      <Modal
        abierto={modalBaja}
        onCerrar={() => {
          if (!procesandoBaja) setModalBaja(false);
        }}
        titulo="¿Dar de baja el automóvil?"
        bloquearCierre={procesandoBaja}
        className="modal-baja"
      >
        <p className="modal-texto">
          Se marcará tu vehículo como dado de baja y se cerrará tu sesión. Tus
          alertas históricas permanecen en la base local.
        </p>
        <div className="modal-resumen">
          <strong>{usuario.modelo_vehiculo}</strong>
          <span>
            Placas {usuario.placas} · Licencia {usuario.licencia}
          </span>
        </div>
        <p className="modal-alerta">
          Podrás registrarte otra vez con el teléfono{' '}
          {formatearTelefono(usuario.telefono)}.
        </p>

        {errorBaja ? <Aviso tipo="error">{errorBaja}</Aviso> : null}

        <div className="modal-botones">
          <button
            type="button"
            className="boton boton-secundario boton-ancho"
            onClick={() => setModalBaja(false)}
            disabled={procesandoBaja}
            data-enfoque-inicial
          >
            CANCELAR
          </button>
          <button
            type="button"
            className="boton boton-rojo boton-ancho"
            onClick={confirmarBaja}
            disabled={procesandoBaja}
          >
            {procesandoBaja ? (
              <>
                <span className="girador girador-boton" aria-hidden="true" />
                DANDO DE BAJA…
              </>
            ) : (
              'SÍ, DAR DE BAJA'
            )}
          </button>
        </div>
      </Modal>
    </main>
  );
}
