import { useId } from 'react';

/**
 * Marca RUTA CERO: el cero es un anillo rojo atravesado por un camino.
 * SVG dibujado a mano, sin imágenes externas.
 */
export default function Logo({
  tamano = 46,
  conTexto = true,
  eslogan = false,
  className = ''
}) {
  const id = useId().replace(/[^a-zA-Z0-9]/g, '');
  const mascara = `camino-${id}`;

  return (
    <div className={`marca ${className}`.trim()}>
      <svg
        width={tamano}
        height={tamano}
        viewBox="0 0 64 64"
        className="marca-simbolo"
        aria-hidden="true"
        focusable="false"
      >
        <defs>
          <mask id={mascara}>
            <rect width="64" height="64" fill="#fff" />
            <rect x="24.5" y="-4" width="15" height="72" rx="7.5" fill="#000" />
          </mask>
        </defs>
        <circle
          cx="32"
          cy="32"
          r="20"
          fill="none"
          stroke="#D62828"
          strokeWidth="8"
          mask={`url(#${mascara})`}
        />
        <rect x="27.5" y="3.5" width="9" height="57" rx="4.5" fill="#1E2F44" />
        <path
          d="M32 7v7M32 19v7M32 31v7M32 43v7M32 55v3"
          stroke="#FFC300"
          strokeWidth="2.4"
          strokeLinecap="round"
        />
      </svg>

      {conTexto ? (
        <div className="marca-texto">
          <span className="marca-nombre">
            RUTA <strong>CERO</strong>
          </span>
          {eslogan ? (
            <span className="marca-eslogan">Tu ruta, más segura</span>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
