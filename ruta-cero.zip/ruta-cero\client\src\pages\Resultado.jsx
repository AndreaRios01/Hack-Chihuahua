import { useEffect, useMemo, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Aviso from '../components/Aviso.jsx';
import Mapa from '../components/Mapa.jsx';
import {
  IconoAmbulancia,
  IconoCheckCirculo,
  IconoEscudo,
  IconoGrua,
  IconoMapa,
  IconoTelefono,
  IconoTransito
} from '../components/Iconos.jsx';
import { leerResultado } from '../lib/sesion.js';
import {
  ETIQUETAS_ALERTA,
  esDispositivoMovil,
  formatearFecha,
  formatearTelefono
} from '../lib/formato.js';

const ICONOS_DESTINO = {
  contacto: IconoTelefono,
  grua: IconoGrua,
  transito: IconoTransito,
  ambulancia: IconoAmbulancia
};

const PRIORIDAD_LLAMADA = ['ambulancia', 'grua', 'transito', 'contacto'];

export default function Resultado() {
  const navigate = useNavigate();
  const datos = useMemo(() => leerResultado(), []);
  const yaIntentoLlamar = useRef(false);

  useEffect(() => {
    document.title = 'Alerta enviada · RUTA CERO';
  }, []);

  const envios = datos?.envios || [];

  const telefonoPrincipal = useMemo(() => {
    if (!envios.length) return null;
    for (const tipo of PRIORIDAD_LLAMADA) {
      const envio = envios.find((e) => e.tipo_destinatario === tipo);
      if (envio?.destinatario_telefono) {
        return {
          telefono: envio.destinatario_telefono,
          nombre: envio.destinatario_nombre,
          tipo
        };
      }
    }
    return null;
  }, [envios]);

  useEffect(() => {
    if (
      !datos?.marcar_al_llegar ||
      !telefonoPrincipal?.telefono ||
      !esDispositivoMovil()
    ) {
      return undefined;
    }

    const temporizador = setTimeout(() => {
      if (yaIntentoLlamar.current) return;
      yaIntentoLlamar.current = true;
      window.location.href = `tel:${telefonoPrincipal.telefono}`;
    }, 900);

    return () => clearTimeout(temporizador);
  }, [datos, telefonoPrincipal]);

  if (!datos?.alerta) {
    return (
      <main className="pantalla pantalla-interior">
        <div className="vacio">
          <span className="vacio-icono" aria-hidden="true">
            <IconoEscudo size={38} />
          </span>
          <h1>No hay una alerta reciente</h1>
          <p>
            Cuando envíes una emergencia o reportes un choque, aquí verás el
            estado de cada notificación.
          </p>
          <button
            type="button"
            className="boton boton-verde boton-grande boton-ancho"
            onClick={() => navigate('/inicio')}
          >
            IR AL INICIO
          </button>
        </div>
      </main>
    );
  }

  const { alerta, ubicacion } = datos;
  const serviciosMapa = datos.servicios || [];
  const esAproximada = Boolean(ubicacion?.aproximada);

  return (
    <main className="pantalla pantalla-interior pantalla-resultado">
      <section className="resultado-heroe" aria-labelledby="titulo-resultado">
        <span className="sello-exito" aria-hidden="true">
          <IconoCheckCirculo size={48} />
        </span>
        <p className="resultado-kicker">
          Alerta #{alerta.id} · {ETIQUETAS_ALERTA[alerta.tipo] || alerta.tipo}
        </p>
        <h1 id="titulo-resultado">
          {datos.titulo ||
            (alerta.tipo === 'emergencia'
              ? 'EMERGENCIA ENVIADA'
              : 'REPORTE ENVIADO')}
        </h1>
        <p className="resultado-detalle">
          {datos.detalle ||
            'Tus servicios recibieron la alerta con tu ubicación.'}
        </p>
        <div className="resultado-resumen">
          <span className="insignia insignia-exito">
            <IconoCheckCirculo size={14} aria-hidden="true" />
            {envios.length} envío{envios.length === 1 ? '' : 's'} · Enviado
          </span>
          <span className="resultado-fecha">{formatearFecha(alerta.creado_en)}</span>
        </div>
      </section>

      {esAproximada ? (
        <Aviso tipo="aviso" titulo="Usamos una ubicación de referencia">
          No se pudo obtener tu GPS. La alerta quedó registrada en el centro de
          Chihuahua. Toca el mapa o abre Google Maps para ver el punto exacto.
        </Aviso>
      ) : null}

      {datos.simulado ? (
        <Aviso tipo="info" titulo="Modo demostración">
          No se enviaron SMS ni llamadas reales. Los envíos quedaron registrados
          en la base SQLite local con estado «Enviado».
        </Aviso>
      ) : null}

      <section className="bloque" aria-labelledby="titulo-envios">
        <div className="bloque-cabecera">
          <h2 id="titulo-envios">Estado de cada envío</h2>
          <span className="contador-chip">{envios.length}</span>
        </div>

        <div className="lista-envios">
          {envios.map((envio) => {
            const Icono = ICONOS_DESTINO[envio.tipo_destinatario] || IconoCheckCirculo;
            return (
              <article className="envio" key={envio.id}>
                <span
                  className={`envio-icono servicio-${envio.tipo_destinatario}`}
                  aria-hidden="true"
                >
                  <Icono size={22} />
                </span>

                <div className="envio-cuerpo">
                  <div className="envio-cabecera">
                    <div>
                      <h3>{envio.etiqueta || envio.tipo_destinatario}</h3>
                      <p className="envio-nombre">{envio.destinatario_nombre}</p>
                    </div>
                    <span className="insignia insignia-exito">
                      <IconoCheckCirculo size={13} aria-hidden="true" />
                      Enviado
                    </span>
                  </div>

                  <div className="envio-meta">
                    {envio.destinatario_telefono ? (
                      <a
                        className="enlace-telefono"
                        href={`tel:${envio.destinatario_telefono}`}
                        aria-label={`Llamar a ${envio.destinatario_nombre} al ${formatearTelefono(envio.destinatario_telefono)}`}
                      >
                        <IconoTelefono size={14} aria-hidden="true" />
                        {formatearTelefono(envio.destinatario_telefono)}
                      </a>
                    ) : null}

                    {envio.servicio ? (
                      <span>
                        {envio.servicio.distancia_texto} · ≈{' '}
                        {envio.servicio.eta_min} min
                      </span>
                    ) : null}

                    <span className="canal">
                      {envio.canal === 'sms' ? 'SMS real' : 'Simulado'}
                    </span>
                  </div>

                  {envio.mensaje ? (
                    <details className="mensaje-detalle">
                      <summary>Ver mensaje enviado</summary>
                      <p>{envio.mensaje}</p>
                    </details>
                  ) : null}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {telefonoPrincipal ? (
        <a
          className="boton boton-secundario boton-ancho boton-llamada-principal"
          href={`tel:${telefonoPrincipal.telefono}`}
          onClick={() => {
            yaIntentoLlamar.current = true;
          }}
        >
          <IconoTelefono size={20} aria-hidden="true" />
          LLAMAR A {telefonoPrincipal.tipo === 'contacto' ? 'CONTACTO' : telefonoPrincipal.tipo.toUpperCase()} ·{' '}
          {formatearTelefono(telefonoPrincipal.telefono)}
        </a>
      ) : null}

      <section className="bloque" aria-labelledby="titulo-mapa-resultado">
        <div className="bloque-cabecera">
          <h2 id="titulo-mapa-resultado">Tu ubicación y servicios asignados</h2>
        </div>
        <Mapa
          usuario={{
            lat: ubicacion.lat,
            lng: ubicacion.lng,
            precision: ubicacion.precision
          }}
          servicios={serviciosMapa}
          conexiones
          alto={280}
          etiqueta="Mapa con tu ubicación y los servicios asignados"
        />

        <div className="coordenadas">
          <div>
            <span>LATITUD</span>
            <strong>{Number(ubicacion.lat).toFixed(5)}</strong>
          </div>
          <div>
            <span>LONGITUD</span>
            <strong>{Number(ubicacion.lng).toFixed(5)}</strong>
          </div>
          <div>
            <span>PRECISIÓN</span>
            <strong>
              {ubicacion.precision ? `±${ubicacion.precision} m` : 'Referencia'}
            </strong>
          </div>
        </div>

        <a
          className="boton boton-secundario boton-ancho"
          href={ubicacion.google_maps}
          target="_blank"
          rel="noopener noreferrer"
        >
          <IconoMapa size={19} aria-hidden="true" />
          ABRIR UBICACIÓN EN GOOGLE MAPS
        </a>
      </section>

      {serviciosMapa.length > 0 ? (
        <section className="bloque" aria-labelledby="titulo-asignados">
          <div className="bloque-cabecera">
            <h2 id="titulo-asignados">Servicios más cercanos asignados</h2>
          </div>
          <ul className="lista-asignados">
            {serviciosMapa.map((servicio) => (
              <li key={`${servicio.tipo}-${servicio.id}`}>
                <span className={`servicio-icono servicio-${servicio.tipo}`} aria-hidden="true">
                  {servicio.tipo === 'grua' ? (
                    <IconoGrua size={20} />
                  ) : servicio.tipo === 'transito' ? (
                    <IconoTransito size={20} />
                  ) : (
                    <IconoAmbulancia size={20} />
                  )}
                </span>
                <div>
                  <strong>{servicio.nombre}</strong>
                  <span>
                    {servicio.distancia_texto} de distancia · llegada ≈{' '}
                    {servicio.eta_min} min
                  </span>
                </div>
              </li>
            ))}
          </ul>
          <p className="nota-pie">
            Distancias calculadas con la fórmula de Haversine y el catálogo
            ficticio de Chihuahua.
          </p>
        </section>
      ) : null}

      <div className="resultado-acciones">
        <Link
          to="/inicio"
          className="boton boton-verde boton-grande boton-ancho"
        >
          VOLVER AL INICIO
        </Link>
        <Link to="/cuenta" className="boton boton-secundario boton-ancho">
          VER MI CUENTA E HISTORIAL
        </Link>
      </div>
    </main>
  );
}
