import express from 'express';
import cors from 'cors';
import path from 'node:path';
import os from 'node:os';
import { existsSync } from 'node:fs';
import { ORIGEN_CLIENTE, PUERTO, RAIZ } from './config.js';
import { api } from './routes/api.js';
import { cerrarBase } from './db.js';
import { estadoNotificaciones } from './services/notificaciones.js';

const app = express();

app.disable('x-powered-by');
app.use(cors({ origin: ORIGEN_CLIENTE, credentials: false }));
app.use(express.json({ limit: '256kb' }));

app.use('/api', api);

// En producción sirve el build de Vite desde el mismo Express.
const carpetaCliente = path.join(RAIZ, 'client', 'dist');
const hayBuild = existsSync(path.join(carpetaCliente, 'index.html'));

if (hayBuild) {
  app.use(express.static(carpetaCliente, { maxAge: '1h', index: false }));
  app.get('*', (req, res) => {
    res.sendFile(path.join(carpetaCliente, 'index.html'));
  });
} else {
  app.get('/', (req, res) => {
    res.type('text/plain').send(
      'RUTA CERO · API activa. Ejecuta `npm run dev` y abre http://localhost:5173'
    );
  });
}

// JSON malformado y errores no controlados.
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && 'body' in err) {
    return res.status(400).json({
      error: 'El cuerpo de la petición no es un JSON válido.',
      detalles: []
    });
  }

  console.error('[RUTA CERO] Error inesperado:', err);
  res.status(500).json({
    error: 'Ocurrió un error interno. Intenta de nuevo.',
    detalles: []
  });
});

function ipLocal() {
  const interfaces = os.networkInterfaces();
  for (const lista of Object.values(interfaces)) {
    for (const red of lista || []) {
      if (red.family === 'IPv4' && !red.internal) return red.address;
    }
  }
  return null;
}

const servidor = app.listen(PUERTO, () => {
  const ip = ipLocal();
  console.log('');
  console.log('  ┌─────────────────────────────────────────────┐');
  console.log('  │  RUTA CERO · servidor listo                 │');
  console.log('  └─────────────────────────────────────────────┘');
  console.log(`  API local:      http://localhost:${PUERTO}/api/salud`);
  if (ip) console.log(`  Red local:      http://${ip}:${PUERTO}/api/salud`);
  console.log(`  Frontend dev:   http://localhost:5173`);
  console.log(`  Notificaciones: ${estadoNotificaciones().modo}`);
  console.log(`  Build servido:  ${hayBuild ? 'sí (client/dist)' : 'no (modo desarrollo)'}`);
  console.log('');
});

const apagar = (senal) => {
  console.log(`\n[RUTA CERO] Cerrando servidor (${senal})…`);
  servidor.close(() => {
    cerrarBase();
    process.exit(0);
  });
};

process.on('SIGINT', () => apagar('SIGINT'));
process.on('SIGTERM', () => apagar('SIGTERM'));
