import { TWILIO, twilioConfigurado } from '../config.js';

/**
 * Servicio de notificaciones aislado.
 *
 * Modo por defecto (sin llaves): SIMULADO. No realiza llamadas externas;
 * registra el envío como "Enviado" para que la demo funcione sin internet.
 *
 * Modo opcional: si TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN y TWILIO_FROM
 * existen en .env, intenta enviar un SMS real con la API REST de Twilio.
 * Si el envío real falla, la app NO se rompe: cae al modo simulado.
 */

function telefonoInternacional(telefono) {
  const digitos = String(telefono ?? '').replace(/\D/g, '');
  if (!digitos) return '';
  if (digitos.startsWith('52')) return `+${digitos}`;
  return `+52${digitos.slice(-10)}`;
}

function motivoLegible(error) {
  const texto = String(error?.message || 'error desconocido');
  return texto.length > 140 ? `${texto.slice(0, 140)}…` : texto;
}

/**
 * @param {object} opciones
 * @param {string} opciones.telefono Destino de 10 dígitos (México).
 * @param {string} opciones.mensaje Texto del SMS.
 * @param {string} opciones.destinatario Nombre para el registro.
 * @returns {Promise<{estado:string, canal:'simulado'|'sms', detalle:string, externo_id?:string}>}
 */
export async function enviarNotificacion({ telefono, mensaje, destinatario = '' }) {
  if (!twilioConfigurado()) {
    return {
      estado: 'Enviado',
      canal: 'simulado',
      detalle: `Notificación simulada a ${destinatario || 'destinatario'} (${telefono || 'sin teléfono'}). No se envió ningún SMS real.`
    };
  }

  try {
    const credenciales = Buffer.from(
      `${TWILIO.sid}:${TWILIO.token}`
    ).toString('base64');

    const cuerpo = new URLSearchParams({
      To: telefonoInternacional(telefono),
      From: TWILIO.desde,
      Body: mensaje
    });

    const respuesta = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(TWILIO.sid)}/Messages.json`,
      {
        method: 'POST',
        headers: {
          Authorization: `Basic ${credenciales}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: cuerpo.toString(),
        signal: AbortSignal.timeout(10_000)
      }
    );

    if (!respuesta.ok) {
      throw new Error(`Twilio respondió HTTP ${respuesta.status}`);
    }

    const data = await respuesta.json();

    return {
      estado: 'Enviado',
      canal: 'sms',
      detalle: `SMS enviado a ${destinatario || 'destinatario'} vía Twilio.`,
      externo_id: data.sid
    };
  } catch (error) {
    // Respaldo elegante: la alerta ya quedó registrada en SQLite.
    return {
      estado: 'Enviado',
      canal: 'simulado',
      detalle: `Twilio no pudo enviar el SMS (${motivoLegible(error)}). La alerta quedó registrada en modo simulado.`
    };
  }
}

export function estadoNotificaciones() {
  return {
    modo: twilioConfigurado() ? 'sms_opcional' : 'simulado',
    twilio_configurado: twilioConfigurado(),
    mensaje: twilioConfigurado()
      ? 'Twilio está configurado; se intentará enviar SMS reales.'
      : 'Todo funciona sin API keys: las notificaciones se registran como simuladas.'
  };
}
