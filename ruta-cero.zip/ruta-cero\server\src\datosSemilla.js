/**
 * Catálogo ficticio de servicios ubicado en Chihuahua, Chihuahua.
 * Los teléfonos son números de demostración (614 000 00XX): no llames a ellos.
 */
export const SERVICIOS_SEMILLA = [
  // ── Grúas ────────────────────────────────────────────────
  {
    tipo: 'grua',
    nombre: 'Grúas del Norte',
    telefono: '6140000001',
    direccion: 'Av. Tecnológico 1500, Col. Centro',
    latitud: 28.662,
    longitud: -106.095,
    horario: '24 horas'
  },
  {
    tipo: 'grua',
    nombre: 'Grúa Express Chihuahua',
    telefono: '6140000002',
    direccion: 'Av. Universidad 2200, Col. Zarco',
    latitud: 28.62,
    longitud: -106.075,
    horario: '24 horas'
  },
  {
    tipo: 'grua',
    nombre: 'Grúas Bravo',
    telefono: '6140000003',
    direccion: 'Blvd. Ortiz Mena 3100, Col. Cuauhtémoc',
    latitud: 28.645,
    longitud: -106.13,
    horario: '7:00 a 23:00'
  },
  {
    tipo: 'grua',
    nombre: 'Servicio de Grúas Sur',
    telefono: '6140000004',
    direccion: 'Av. Vallarta 4500, Col. Kennedy',
    latitud: 28.59,
    longitud: -106.09,
    horario: '24 horas'
  },

  // ── Tránsito ─────────────────────────────────────────────
  {
    tipo: 'transito',
    nombre: 'Delegación de Tránsito Centro',
    telefono: '6140000011',
    direccion: 'Calle Juárez 200, Col. Centro',
    latitud: 28.635,
    longitud: -106.077,
    horario: '24 horas'
  },
  {
    tipo: 'transito',
    nombre: 'Delegación de Tránsito Norte',
    telefono: '6140000012',
    direccion: 'Av. Tecnológico 4500, Col. Universidad',
    latitud: 28.675,
    longitud: -106.08,
    horario: '6:00 a 22:00'
  },
  {
    tipo: 'transito',
    nombre: 'Delegación de Tránsito Sur',
    telefono: '6140000013',
    direccion: 'Blvd. Fuentes Mares 900, Col. Granjas',
    latitud: 28.605,
    longitud: -106.1,
    horario: '6:00 a 22:00'
  },

  // ── Ambulancias ──────────────────────────────────────────
  {
    tipo: 'ambulancia',
    nombre: 'Cruz Roja Chihuahua',
    telefono: '6140000021',
    direccion: 'Av. Cuauhtémoc 1200, Col. Centro',
    latitud: 28.641,
    longitud: -106.071,
    horario: '24 horas'
  },
  {
    tipo: 'ambulancia',
    nombre: 'URGE Chihuahua',
    telefono: '6140000022',
    direccion: 'Periférico de la Juventud 5800, Col. Riberas',
    latitud: 28.679,
    longitud: -106.115,
    horario: '24 horas'
  },
  {
    tipo: 'ambulancia',
    nombre: 'Servicios Médicos Municipales',
    telefono: '6140000023',
    direccion: 'Av. Homero 300, Col. Revolución',
    latitud: 28.612,
    longitud: -106.06,
    horario: '24 horas'
  }
];

export const USUARIOS_SEMILLA = [
  {
    nombre: 'Ana Sofía Ramos',
    telefono: '6141234567',
    contacto_emergencia_nombre: 'Luis Ramos',
    contacto_emergencia_telefono: '6149876543',
    modelo_vehiculo: 'Nissan Versa 2021',
    placas: 'RCD-1201',
    licencia: 'CHIH-DEMO-001',
    activo: 1
  },
  {
    nombre: 'Carlos Mendoza',
    telefono: '6142345678',
    contacto_emergencia_nombre: 'Lucía Mendoza',
    contacto_emergencia_telefono: '6148765432',
    modelo_vehiculo: 'Chevrolet Aveo 2019',
    placas: 'RCD-3402',
    licencia: 'CHIH-DEMO-002',
    activo: 1
  },
  {
    nombre: 'María Fernanda Ortega',
    telefono: '6143456789',
    contacto_emergencia_nombre: 'Jorge Ortega',
    contacto_emergencia_telefono: '6147654321',
    modelo_vehiculo: 'Kia Rio 2022',
    placas: 'RCD-5603',
    licencia: 'CHIH-DEMO-003',
    activo: 1
  }
];
