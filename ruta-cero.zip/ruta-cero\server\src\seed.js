/**
 * Seed de demostración de RUTA CERO.
 * Ejecuta: npm run seed  (desde la raíz del proyecto)
 *
 * Reinicia la base y carga 3 usuarios, 4 grúas, 3 oficinas de tránsito,
 * 3 ambulancias y alertas históricas ficticias en Chihuahua.
 */
import { db, cerrarBase } from './db.js';
import { SERVICIOS_SEMILLA, USUARIOS_SEMILLA } from './datosSemilla.js';
import { DB_RUTA } from './config.js';

const diasAtras = (dias, horas = 0) =>
  new Date(Date.now() - dias * 86_400_000 - horas * 3_600_000).toISOString();

console.log(`\n[RUTA CERO] Preparando datos demo en:\n  ${DB_RUTA}\n`);

const insertarServicios = db.prepare(`
  INSERT INTO servicios (tipo, nombre, telefono, direccion, latitud, longitud, horario)
  VALUES (@tipo, @nombre, @telefono, @direccion, @latitud, @longitud, @horario)
`);

const insertarUsuario = db.prepare(`
  INSERT INTO usuarios (
    nombre, telefono, contacto_emergencia_nombre, contacto_emergencia_telefono,
    modelo_vehiculo, placas, licencia, activo, creado_en
  ) VALUES (
    @nombre, @telefono, @contacto_emergencia_nombre, @contacto_emergencia_telefono,
    @modelo_vehiculo, @placas, @licencia, @activo, @creado_en
  )
`);

const insertarAlerta = db.prepare(`
  INSERT INTO alertas (
    usuario_id, tipo, servicios_solicitados, latitud, longitud,
    precision_metros, ubicacion_aproximada, estado, mensaje, creado_en
  ) VALUES (
    @usuario_id, @tipo, @servicios_solicitados, @latitud, @longitud,
    @precision_metros, @ubicacion_aproximada, @estado, @mensaje, @creado_en
  )
`);

const insertarEnvio = db.prepare(`
  INSERT INTO envios (
    alerta_id, tipo_destinatario, destinatario_nombre, destinatario_telefono,
    servicio_id, estado, canal, detalle, creado_en
  ) VALUES (
    @alerta_id, @tipo_destinatario, @destinatario_nombre, @destinatario_telefono,
    @servicio_id, @estado, @canal, @detalle, @creado_en
  )
`);

const reiniciar = db.transaction(() => {
  db.prepare('DELETE FROM envios').run();
  db.prepare('DELETE FROM alertas').run();
  db.prepare('DELETE FROM usuarios').run();
  db.prepare('DELETE FROM servicios').run();

  try {
    db.prepare(
      "DELETE FROM sqlite_sequence WHERE name IN ('envios','alertas','usuarios','servicios')"
    ).run();
  } catch {
    /* sqlite_sequence se crea con el primer AUTOINCREMENT */
  }

  for (const servicio of SERVICIOS_SEMILLA) insertarServicios.run(servicio);

  const idsUsuarios = USUARIOS_SEMILLA.map((usuario) => {
    const creado = diasAtras(30);
    const info = insertarUsuario.run({ ...usuario, creado_en: creado });
    return Number(info.lastInsertRowid);
  });

  const servicios = db.prepare('SELECT * FROM servicios').all();
  const buscarServicio = (nombre) => servicios.find((s) => s.nombre === nombre);

  const crearAlertaDemo = ({
    usuarioId,
    tipo,
    solicitados,
    lat,
    lng,
    creado,
    destinos
  }) => {
    const alertaInfo = insertarAlerta.run({
      usuario_id: usuarioId,
      tipo,
      servicios_solicitados: JSON.stringify(solicitados),
      latitud: lat,
      longitud: lng,
      precision_metros: 18,
      ubicacion_aproximada: 0,
      estado: 'Enviado',
      mensaje: `Alerta de demostración registrada el ${creado}.`,
      creado_en: creado
    });

    const alertaId = Number(alertaInfo.lastInsertRowid);

    for (const destino of destinos) {
      const servicio = destino.servicio ? buscarServicio(destino.servicio) : null;
      insertarEnvio.run({
        alerta_id: alertaId,
        tipo_destinatario: destino.tipo,
        destinatario_nombre: destino.nombre,
        destinatario_telefono: destino.telefono,
        servicio_id: servicio?.id ?? null,
        estado: 'Enviado',
        canal: 'simulado',
        detalle: 'Envío de demostración (simulado, sin SMS real).',
        creado_en: creado
      });
    }
  };

  // Historial de Ana Sofía (usuario 1)
  crearAlertaDemo({
    usuarioId: idsUsuarios[0],
    tipo: 'emergencia',
    solicitados: ['contacto', 'grua', 'transito'],
    lat: 28.6472,
    lng: -106.0914,
    creado: diasAtras(2, 3),
    destinos: [
      {
        tipo: 'contacto',
        nombre: 'Luis Ramos',
        telefono: '6149876543'
      },
      {
        tipo: 'grua',
        nombre: 'Grúas del Norte',
        telefono: '6140000001',
        servicio: 'Grúas del Norte'
      },
      {
        tipo: 'transito',
        nombre: 'Delegación de Tránsito Centro',
        telefono: '6140000011',
        servicio: 'Delegación de Tránsito Centro'
      }
    ]
  });

  crearAlertaDemo({
    usuarioId: idsUsuarios[0],
    tipo: 'choque',
    solicitados: ['grua'],
    lat: 28.6281,
    lng: -106.0756,
    creado: diasAtras(8, 1),
    destinos: [
      {
        tipo: 'grua',
        nombre: 'Grúa Express Chihuahua',
        telefono: '6140000002',
        servicio: 'Grúa Express Chihuahua'
      }
    ]
  });

  // Historial de Carlos Mendoza (usuario 2)
  crearAlertaDemo({
    usuarioId: idsUsuarios[1],
    tipo: 'accidente',
    solicitados: ['ambulancia', 'transito', 'contacto'],
    lat: 28.6701,
    lng: -106.1042,
    creado: diasAtras(4, 6),
    destinos: [
      {
        tipo: 'contacto',
        nombre: 'Lucía Mendoza',
        telefono: '6148765432'
      },
      {
        tipo: 'ambulancia',
        nombre: 'Cruz Roja Chihuahua',
        telefono: '6140000021',
        servicio: 'Cruz Roja Chihuahua'
      },
      {
        tipo: 'transito',
        nombre: 'Delegación de Tránsito Norte',
        telefono: '6140000012',
        servicio: 'Delegación de Tránsito Norte'
      }
    ]
  });
});

reiniciar();

const conteos = {
  usuarios: db.prepare('SELECT COUNT(*) AS n FROM usuarios').get().n,
  gruas: db.prepare("SELECT COUNT(*) AS n FROM servicios WHERE tipo = 'grua'").get().n,
  transito: db.prepare("SELECT COUNT(*) AS n FROM servicios WHERE tipo = 'transito'").get().n,
  ambulancias: db.prepare("SELECT COUNT(*) AS n FROM servicios WHERE tipo = 'ambulancia'").get().n,
  alertas: db.prepare('SELECT COUNT(*) AS n FROM alertas').get().n,
  envios: db.prepare('SELECT COUNT(*) AS n FROM envios').get().n
};

console.log('  ✓ Base de datos reiniciada y sembrada');
console.log(`    Usuarios demo:      ${conteos.usuarios}`);
console.log(`    Grúas:              ${conteos.gruas}`);
console.log(`    Oficinas tránsito:  ${conteos.transito}`);
console.log(`    Ambulancias:        ${conteos.ambulancias}`);
console.log(`    Alertas históricas: ${conteos.alertas}`);
console.log(`    Envíos históricos:  ${conteos.envios}`);
console.log('');
console.log('  Cuenta demo: teléfono 6141234567 (Ana Sofía Ramos)');
console.log('  Ya puedes ejecutar: npm run dev\n');

cerrarBase();
