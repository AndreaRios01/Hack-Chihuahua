import { Router } from 'express';
import {
  buscarUsuarioPorId,
  buscarUsuarioPorTelefono,
  db,
  listarServicios,
  usuarioPublico
} from '../db.js';
import { UBICACION_REFERENCIA } from '../config.js';
import {
  crearAlerta,
  listarAlertas
} from '../services/alertas.js';
import { estadoNotificaciones } from '../services/notificaciones.js';
import {
  CENTRO_CHIHUAHUA,
  distanciaKm,
  enlaceGoogleMaps,
  servicioMasCercano,
  textoDistancia
} from '../utils/geo.js';
import {
  normalizarServicios,
  normalizarTelefono,
  telefonoValido,
  validarRegistro,
  validarUbicacion,
  SERVICIOS_VALIDOS,
  TIPOS_INCIDENTE
} from '../utils/validaciones.js';

export const api = Router();

const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

const error = (res, codigo, mensaje, detalles = []) =>
  res.status(codigo).json({ error: mensaje, detalles });

const idValido = (valor) => {
  const numero = Number(valor);
  return Number.isInteger(numero) && numero > 0 ? numero : null;
};

const fechaISO = () => new Date().toISOString();

/* ─────────────────────────── Salud ─────────────────────────── */

api.get('/salud', (req, res) => {
  res.json({
    ok: true,
    app: 'RUTA CERO',
    version: '1.0.0',
    base_datos: 'SQLite local',
    notificaciones: estadoNotificaciones(),
    servicios: listarServicios().length,
    fecha: fechaISO()
  });
});

/* ───────────────────── Registro y sesión ───────────────────── */

api.post('/registro', (req, res) => {
  const validacion = validarRegistro(req.body);
  if (!validacion.ok) {
    return error(res, 422, 'Revisa los datos del formulario.', validacion.errores);
  }

  const datos = validacion.datos;
  const existente = buscarUsuarioPorTelefono(datos.telefono);

  if (existente) {
    if (existente.activo) {
      // Login simple por teléfono: ya existe una cuenta activa.
      return res.json({
        existente: true,
        usuario: usuarioPublico(existente),
        mensaje: 'Ese teléfono ya está registrado. Entramos a tu cuenta.'
      });
    }

    // El vehículo estaba dado de baja: se reactiva y se actualizan sus datos.
    db.prepare(`
      UPDATE usuarios SET
        nombre = @nombre,
        contacto_emergencia_nombre = @contacto_emergencia_nombre,
        contacto_emergencia_telefono = @contacto_emergencia_telefono,
        modelo_vehiculo = @modelo_vehiculo,
        placas = @placas,
        licencia = @licencia,
        activo = 1
      WHERE id = @id
    `).run({ ...datos, id: existente.id });

    const reactivado = buscarUsuarioPorId(existente.id);
    return res.json({
      existente: true,
      reactivado: true,
      usuario: usuarioPublico(reactivado),
      mensaje: 'Reactivamos tu cuenta con los datos actualizados.'
    });
  }

  const creado = db.prepare(`
    INSERT INTO usuarios (
      nombre, telefono, contacto_emergencia_nombre, contacto_emergencia_telefono,
      modelo_vehiculo, placas, licencia, activo, creado_en
    ) VALUES (
      @nombre, @telefono, @contacto_emergencia_nombre, @contacto_emergencia_telefono,
      @modelo_vehiculo, @placas, @licencia, 1, @creado_en
    )
  `).run({ ...datos, creado_en: fechaISO() });

  const usuario = buscarUsuarioPorId(Number(creado.lastInsertRowid));

  res.status(201).json({
    existente: false,
    usuario: usuarioPublico(usuario),
    mensaje: '¡Bienvenido a RUTA CERO! Tu cuenta quedó lista.'
  });
});

api.post('/login', (req, res) => {
  const telefono = normalizarTelefono(req.body?.telefono);

  if (!telefonoValido(telefono)) {
    return error(res, 400, 'Escribe un teléfono de 10 dígitos.');
  }

  const usuario = buscarUsuarioPorTelefono(telefono);

  if (!usuario) {
    return error(
      res,
      404,
      'No encontramos ese teléfono. Regístrate para crear tu cuenta y poder entrar.'
    );
  }

  if (!usuario.activo) {
    return error(
      res,
      403,
      'Tu vehículo está dado de baja. Regístrate de nuevo con este teléfono para reactivar la cuenta.'
    );
  }

  res.json({
    usuario: usuarioPublico(usuario),
    mensaje: `Hola de nuevo, ${usuario.nombre.split(' ')[0]}.`
  });
});

/* ───────────────────────── Usuarios ────────────────────────── */

api.get('/usuario/:id', (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return error(res, 400, 'Identificador de usuario inválido.');

  const usuario = buscarUsuarioPorId(id);
  if (!usuario) return error(res, 404, 'Usuario no encontrado.');

  res.json({ usuario: usuarioPublico(usuario) });
});

api.put('/usuario/:id', (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return error(res, 400, 'Identificador de usuario inválido.');

  const existente = buscarUsuarioPorId(id);
  if (!existente) return error(res, 404, 'Usuario no encontrado.');

  const validacion = validarRegistro(req.body);
  if (!validacion.ok) {
    return error(res, 422, 'Revisa los datos del formulario.', validacion.errores);
  }

  const datos = validacion.datos;
  const duenoDelTelefono = buscarUsuarioPorTelefono(datos.telefono);

  if (duenoDelTelefono && duenoDelTelefono.id !== id) {
    return error(res, 409, 'Ese teléfono ya pertenece a otra cuenta.');
  }

  db.prepare(`
    UPDATE usuarios SET
      nombre = @nombre,
      telefono = @telefono,
      contacto_emergencia_nombre = @contacto_emergencia_nombre,
      contacto_emergencia_telefono = @contacto_emergencia_telefono,
      modelo_vehiculo = @modelo_vehiculo,
      placas = @placas,
      licencia = @licencia
    WHERE id = @id
  `).run({ ...datos, id });

  res.json({
    usuario: usuarioPublico(buscarUsuarioPorId(id)),
    mensaje: 'Datos actualizados correctamente.'
  });
});

api.patch('/usuario/:id/baja', (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return error(res, 400, 'Identificador de usuario inválido.');

  const usuario = buscarUsuarioPorId(id);
  if (!usuario) return error(res, 404, 'Usuario no encontrado.');

  db.prepare('UPDATE usuarios SET activo = 0 WHERE id = ?').run(id);

  res.json({
    mensaje:
      'El automóvil quedó dado de baja y la sesión se cerró. Puedes registrarte de nuevo con el mismo teléfono.',
    usuario: usuarioPublico(buscarUsuarioPorId(id))
  });
});

api.delete('/usuario/:id', (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return error(res, 400, 'Identificador de usuario inválido.');

  const usuario = buscarUsuarioPorId(id);
  if (!usuario) return error(res, 404, 'Usuario no encontrado.');

  db.prepare('DELETE FROM usuarios WHERE id = ?').run(id);
  res.json({ mensaje: 'El registro del usuario y sus alertas fueron eliminados.' });
});

/* ────────────────────────── Alertas ─────────────────────────── */

api.post(
  '/emergencia',
  asyncHandler(async (req, res) => {
    const usuarioId = idValido(req.body?.usuario_id ?? req.body?.usuarioId);
    if (!usuarioId) return error(res, 400, 'Falta el usuario que activa la emergencia.');

    const usuario = buscarUsuarioPorId(usuarioId);
    if (!usuario) return error(res, 404, 'Usuario no encontrado.');
    if (!usuario.activo) {
      return error(res, 403, 'El vehículo está dado de baja; no puede enviar alertas.');
    }

    const ubicacion = validarUbicacion(
      req.body?.latitud,
      req.body?.longitud,
      UBICACION_REFERENCIA
    );

    const precision = Number(req.body?.precision);
    const aproximada = Boolean(ubicacion.aproximada || req.body?.aproximada);
    const resultado = await crearAlerta({
      usuario,
      tipo: 'emergencia',
      tipoIncidente: 'emergencia',
      serviciosSolicitados: ['contacto', 'grua', 'transito'],
      lat: ubicacion.lat,
      lng: ubicacion.lng,
      precision: Number.isFinite(precision) && !aproximada ? Math.round(precision) : null,
      aproximada
    });

    res.status(201).json({
      ...resultado,
      titulo: 'EMERGENCIA ENVIADA',
      detalle: 'Tu contacto, una grúa y tránsito recibieron la alerta.'
    });
  })
);

api.post(
  '/choque',
  asyncHandler(async (req, res) => {
    const usuarioId = idValido(req.body?.usuario_id ?? req.body?.usuarioId);
    if (!usuarioId) return error(res, 400, 'Falta el usuario que reporta el incidente.');

    const usuario = buscarUsuarioPorId(usuarioId);
    if (!usuario) return error(res, 404, 'Usuario no encontrado.');
    if (!usuario.activo) {
      return error(res, 403, 'El vehículo está dado de baja; no puede enviar alertas.');
    }

    const tipo = String(req.body?.tipo || '').toLowerCase();
    if (!TIPOS_INCIDENTE.includes(tipo)) {
      return error(res, 400, 'Elige el tipo de incidente: choque o accidente.');
    }

    const seleccionados = normalizarServicios(req.body?.servicios);
    if (seleccionados.length === 0) {
      return error(res, 400, 'Selecciona al menos un servicio: ambulancia, grúa o tránsito.');
    }

    // En un accidente avisamos también al contacto de emergencia.
    const serviciosSolicitados = [...seleccionados];
    if (tipo === 'accidente') serviciosSolicitados.push('contacto');

    const ubicacion = validarUbicacion(
      req.body?.latitud,
      req.body?.longitud,
      UBICACION_REFERENCIA
    );

    const precision = Number(req.body?.precision);
    const aproximada = Boolean(ubicacion.aproximada || req.body?.aproximada);
    const resultado = await crearAlerta({
      usuario,
      tipo,
      tipoIncidente: tipo,
      serviciosSolicitados,
      lat: ubicacion.lat,
      lng: ubicacion.lng,
      precision: Number.isFinite(precision) && !aproximada ? Math.round(precision) : null,
      aproximada
    });

    res.status(201).json({
      ...resultado,
      titulo: tipo === 'accidente' ? 'ACCIDENTE REPORTADO' : 'CHOQUE REPORTADO',
      detalle:
        tipo === 'accidente'
          ? 'Servicios notificados y contacto de emergencia avisado.'
          : 'Los servicios seleccionados recibieron la alerta.',
      aviso_contacto: tipo === 'accidente'
    });
  })
);

api.get('/alertas/:usuarioId', (req, res) => {
  const usuarioId = idValido(req.params.usuarioId);
  if (!usuarioId) return error(res, 400, 'Identificador de usuario inválido.');

  const usuario = buscarUsuarioPorId(usuarioId);
  if (!usuario) return error(res, 404, 'Usuario no encontrado.');

  const alertas = listarAlertas(usuarioId);
  res.json({ alertas, total: alertas.length });
});

/* ───────────────────────── Servicios ───────────────────────── */

api.get('/servicios', (req, res) => {
  const tipo = req.query.tipo ? String(req.query.tipo) : null;

  if (tipo && !SERVICIOS_VALIDOS.includes(tipo)) {
    return error(res, 400, 'Tipo de servicio inválido. Usa grua, transito o ambulancia.');
  }

  const servicios = listarServicios(tipo).map((servicio) => ({
    ...servicio,
    google_maps: enlaceGoogleMaps(servicio.latitud, servicio.longitud)
  }));

  res.json({
    servicios,
    total: servicios.length,
    centro: CENTRO_CHIHUAHUA,
    nota: 'Catálogo ficticio de demostración. Los teléfonos no son reales.'
  });
});

api.get('/cercanos', (req, res) => {
  const ubicacion = validarUbicacion(
    req.query.lat,
    req.query.lng,
    UBICACION_REFERENCIA
  );

  const conDistancia = listarServicios()
    .map((servicio) => {
      const km = distanciaKm(
        { lat: ubicacion.lat, lng: ubicacion.lng },
        { lat: servicio.latitud, lng: servicio.longitud }
      );
      return {
        ...servicio,
        distancia_km: Number(km.toFixed(2)),
        distancia_texto: textoDistancia(km),
        eta_min: Math.max(2, Math.round((km / 28) * 60)),
        google_maps: enlaceGoogleMaps(servicio.latitud, servicio.longitud)
      };
    })
    .sort((a, b) => a.distancia_km - b.distancia_km);

  const grupos = {
    grua: servicioMasCercano(
      conDistancia.filter((s) => s.tipo === 'grua'),
      ubicacion.lat,
      ubicacion.lng
    ),
    transito: servicioMasCercano(
      conDistancia.filter((s) => s.tipo === 'transito'),
      ubicacion.lat,
      ubicacion.lng
    ),
    ambulancia: servicioMasCercano(
      conDistancia.filter((s) => s.tipo === 'ambulancia'),
      ubicacion.lat,
      ubicacion.lng
    )
  };

  res.json({
    ubicacion: {
      lat: ubicacion.lat,
      lng: ubicacion.lng,
      aproximada: ubicacion.aproximada,
      google_maps: enlaceGoogleMaps(ubicacion.lat, ubicacion.lng)
    },
    grupos,
    servicios: conDistancia
  });
});

/* ─────────────────── Tráfico simulado (extra) ──────────────── */

const CORREDORES = [
  { nombre: 'Periférico de la Juventud', lat: 28.663, lng: -106.118, factor: 0.72 },
  { nombre: 'Av. Universidad', lat: 28.643, lng: -106.083, factor: 0.58 },
  { nombre: 'Av. Tecnológico', lat: 28.658, lng: -106.092, factor: 0.46 },
  { nombre: 'Blvd. Ortiz Mena', lat: 28.632, lng: -106.072, factor: 0.66 },
  { nombre: 'Av. Vallarta', lat: 28.608, lng: -106.093, factor: 0.35 },
  { nombre: 'Av. Juárez (Centro)', lat: 28.636, lng: -106.077, factor: 0.54 },
  { nombre: 'Blvd. Fuentes Mares', lat: 28.612, lng: -106.045, factor: 0.4 },
  { nombre: 'Av. Homero', lat: 28.62, lng: -106.061, factor: 0.31 }
];

const NIVELES = [
  { hasta: 0.42, etiqueta: 'Fluido', color: '#2E9E4F' },
  { hasta: 0.7, etiqueta: 'Moderado', color: '#FFC300' },
  { hasta: 1, etiqueta: 'Congestionado', color: '#D62828' }
];

api.get('/trafico', (req, res) => {
  const hora = new Date().getHours();
  const semillaHora = hora * 7 + new Date().getDate();

  const corredores = CORREDORES.map((corredor, indice) => {
    const ruido =
      Math.abs(
        Math.sin((indice + 1) * 12.9898 + semillaHora * 3.77) * 43758.5453
      ) % 1;
    const intensidad = Math.min(
      0.97,
      Math.max(0.18, corredor.factor * 0.7 + ruido * 0.55)
    );
    const nivel =
      NIVELES.find((n) => intensidad <= n.hasta) || NIVELES[NIVELES.length - 1];

    return {
      id: indice + 1,
      nombre: corredor.nombre,
      latitud: corredor.lat,
      longitud: corredor.lng,
      nivel: nivel.etiqueta,
      color: nivel.color,
      porcentaje: Math.round(intensidad * 100),
      demora_min: Math.round(intensidad * 12),
      velocidad_estimada_kmh: Math.round(55 - intensidad * 38),
      sentido: indice % 2 === 0 ? 'Norte → Sur' : 'Sur → Norte'
    };
  });

  const mejor = [...corredores].sort((a, b) => a.porcentaje - b.porcentaje)[0];
  const promedio =
    corredores.reduce((suma, c) => suma + c.porcentaje, 0) / corredores.length;

  res.json({
    simulado: true,
    actualizado_en: fechaISO(),
    nota: 'Indicador de tráfico SIMULADO con fines de demostración. No proviene de un servicio externo.',
    corredores,
    ruta_sugerida: {
      nombre: mejor.nombre,
      nivel: mejor.nivel,
      demora_min: mejor.demora_min,
      ahorro_estimado_min: Math.max(
        1,
        Math.round(
          corredores.reduce((suma, c) => suma + c.demora_min, 0) /
            corredores.length -
            mejor.demora_min
        )
      ),
      recomendacion: `Toma ${mejor.nombre}: es el corredor con menor congestión simulada ahora mismo.`
    },
    indice_general: {
      porcentaje: Math.round(promedio),
      nivel:
        NIVELES.find((n) => promedio / 100 <= n.hasta)?.etiqueta || 'Moderado'
    }
  });
});

/* ─────────────────────── 404 de la API ─────────────────────── */

api.use((req, res) => {
  error(res, 404, `Ruta de API no encontrada: ${req.method} ${req.originalUrl}`);
});
