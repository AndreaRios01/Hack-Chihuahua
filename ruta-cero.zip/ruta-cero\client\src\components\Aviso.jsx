import { IconoAlerta, IconoCheckCirculo, IconoInfo, IconoX } from './Iconos.jsx';

const ICONOS = {
  error: IconoAlerta,
  exito: IconoCheckCirculo,
  info: IconoInfo,
  aviso: IconoAlerta
};

export default function Aviso({
  tipo = 'info',
  titulo,
  children,
  onCerrar,
  className = ''
}) {
  const Icono = ICONOS[tipo] || IconoInfo;

  return (
    <div
      className={`aviso aviso-${tipo} ${className}`.trim()}
      role={tipo === 'error' ? 'alert' : 'status'}
      aria-live={tipo === 'error' ? 'assertive' : 'polite'}
    >
      <span className="aviso-icono" aria-hidden="true">
        <Icono size={20} />
      </span>
      <div className="aviso-contenido">
        {titulo ? <p className="aviso-titulo">{titulo}</p> : null}
        {children ? <div className="aviso-texto">{children}</div> : null}
      </div>
      {onCerrar ? (
        <button
          type="button"
          className="aviso-cerrar"
          onClick={onCerrar}
          aria-label="Cerrar aviso"
        >
          <IconoX size={18} />
        </button>
      ) : null}
    </div>
  );
}

export function Cargador({ texto = 'Cargando…', compacto = false }) {
  return (
    <div className={`cargador ${compacto ? 'cargador-compacto' : ''}`.trim()} role="status">
      <span className="girador" aria-hidden="true" />
      <span>{texto}</span>
    </div>
  );
}
