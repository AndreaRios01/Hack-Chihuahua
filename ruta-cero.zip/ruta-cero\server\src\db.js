import Database from 'better-sqlite3';
import { DB_RUTA } from './config.js';
import { SERVICIOS_SEMILLA } from './datosSemilla.js';

/** Conexión única a SQLite local (archivo ruta_cero.db). */
export const db = new Database(DB_RUTA);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    telefono TEXT NOT NULL UNIQUE,
    contacto_emergencia_nombre TEXT NOT NULL,
    contacto_emergencia_telefono TEXT NOT NULL,
    modelo_vehiculo TEXT NOT NULL,
    placas TEXT NOT NULL,
    licencia TEXT NOT NULL,
    activo INTEGER NOT NULL DEFAULT 1,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS servicios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL CHECK (tipo IN ('grua', 'transito', 'ambulancia')),
    nombre TEXT NOT NULL,
    telefono TEXT NOT NULL,
    direccion TEXT,
    latitud REAL NOT NULL,
    longitud REAL NOT NULL,
    horario TEXT
  );

  CREATE TABLE IF NOT EXISTS alertas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    tipo TEXT NOT NULL CHECK (tipo IN ('emergencia', 'choque', 'accidente')),
    servicios_solicitados TEXT NOT NULL DEFAULT '[]',
    latitud REAL NOT NULL,
    longitud REAL NOT NULL,
    precision_metros REAL,
    ubicacion_aproximada INTEGER NOT NULL DEFAULT 0,
    estado TEXT NOT NULL DEFAULT 'Enviado',
    mensaje TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS envios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alerta_id INTEGER NOT NULL REFERENCES alertas(id) ON DELETE CASCADE,
    tipo_destinatario TEXT NOT NULL,
    destinatario_nombre TEXT NOT NULL,
    destinatario_telefono TEXT,
    servicio_id INTEGER REFERENCES servicios(id) ON DELETE SET NULL,
    estado TEXT NOT NULL DEFAULT 'Enviado',
    canal TEXT NOT NULL DEFAULT 'simulado',
    detalle TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_alertas_usuario ON alertas (usuario_id, creado_en DESC);
  CREATE INDEX IF NOT EXISTS idx_envios_alerta ON envios (alerta_id);
  CREATE INDEX IF NOT EXISTS idx_servicios_tipo ON servicios (tipo);
`);

/** Carga el catálogo de grúas, tránsito y ambulancias si la tabla está vacía. */
export function sembrarCatalogoServicios() {
  const { total } = db.prepare('SELECT COUNT(*) AS total FROM servicios').get();
  if (total > 0) return 0;

  const insertar = db.prepare(`
    INSERT INTO servicios (tipo, nombre, telefono, direccion, latitud, longitud, horario)
    VALUES (@tipo, @nombre, @telefono, @direccion, @latitud, @longitud, @horario)
  `);

  const cargar = db.transaction((servicios) => {
    for (const servicio of servicios) insertar.run(servicio);
  });

  cargar(SERVICIOS_SEMILLA);
  return SERVICIOS_SEMILLA.length;
}

// La app debe poder enviar alertas incluso si se olvida ejecutar `npm run seed`.
sembrarCatalogoServicios();

export function listarServicios(tipo) {
  if (tipo) {
    return db
      .prepare('SELECT * FROM servicios WHERE tipo = ? ORDER BY nombre')
      .all(tipo);
  }
  return db.prepare('SELECT * FROM servicios ORDER BY tipo, nombre').all();
}

export function buscarUsuarioPorId(id) {
  return db.prepare('SELECT * FROM usuarios WHERE id = ?').get(id);
}

export function buscarUsuarioPorTelefono(telefono) {
  return db.prepare('SELECT * FROM usuarios WHERE telefono = ?').get(telefono);
}

/** Convierte la fila de SQLite en un objeto seguro para el cliente. */
export function usuarioPublico(usuario) {
  if (!usuario) return null;
  return {
    id: usuario.id,
    nombre: usuario.nombre,
    telefono: usuario.telefono,
    contacto_emergencia_nombre: usuario.contacto_emergencia_nombre,
    contacto_emergencia_telefono: usuario.contacto_emergencia_telefono,
    modelo_vehiculo: usuario.modelo_vehiculo,
    placas: usuario.placas,
    licencia: usuario.licencia,
    activo: Boolean(usuario.activo),
    creado_en: usuario.creado_en
  };
}

export function cerrarBase() {
  try {
    db.close();
  } catch {
    /* la base ya estaba cerrada */
  }
}
