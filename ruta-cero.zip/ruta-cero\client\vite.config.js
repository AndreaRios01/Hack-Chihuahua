import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const puertoApi = process.env.PUERTO || 4000;

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    proxy: {
      '/api': {
        target: `http://localhost:${puertoApi}`,
        changeOrigin: true
      }
    }
  },
  preview: {
    port: 4173,
    host: true
  },
  build: {
    outDir: 'dist',
    sourcemap: false
  }
});
