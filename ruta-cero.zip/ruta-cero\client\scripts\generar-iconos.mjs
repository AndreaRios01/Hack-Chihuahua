/**
 * Genera los iconos PNG de la PWA sin dependencias externas.
 * Uso: npm run iconos
 */
import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const destino = join(__dirname, '..', 'public', 'icons');
mkdirSync(destino, { recursive: true });

/* ── Codificador PNG mínimo ───────────────────────────────── */

const TABLA_CRC = (() => {
  const tabla = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    tabla[n] = c >>> 0;
  }
  return tabla;
})();

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc = TABLA_CRC[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function bloque(tipo, datos) {
  const largo = Buffer.alloc(4);
  largo.writeUInt32BE(datos.length, 0);
  const cuerpo = Buffer.concat([Buffer.from(tipo, 'ascii'), datos]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(cuerpo), 0);
  return Buffer.concat([largo, cuerpo, crc]);
}

function crearPNG(ancho, alto, pixel) {
  const filas = Buffer.alloc((ancho * 4 + 1) * alto);
  let offset = 0;

  for (let y = 0; y < alto; y += 1) {
    filas[offset] = 0; // filtro "None"
    offset += 1;
    for (let x = 0; x < ancho; x += 1) {
      const [r, g, b, a] = pixel(x, y);
      filas[offset] = r;
      filas[offset + 1] = g;
      filas[offset + 2] = b;
      filas[offset + 3] = a;
      offset += 4;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(ancho, 0);
  ihdr.writeUInt32BE(alto, 4);
  ihdr[8] = 8; // profundidad
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    bloque('IHDR', ihdr),
    bloque('IDAT', deflateSync(filas, { level: 9 })),
    bloque('IEND', Buffer.alloc(0))
  ]);
}

/* ── Dibujo del logo ─────────────────────────────────────── */

const ROJO = [214, 40, 40];
const AMARILLO = [255, 195, 0];
const NAVY_1 = [20, 37, 59];
const NAVY_2 = [9, 16, 28];
const ASFALTO = [30, 47, 68];

const mezclar = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));

function dentroRedondeado(u, v, radio) {
  const dx = Math.max(Math.abs(u - 0.5) - (0.5 - radio), 0);
  const dy = Math.max(Math.abs(v - 0.5) - (0.5 - radio), 0);
  return Math.hypot(dx, dy) <= radio;
}

function muestra(u, v, maskable) {
  const radioMarco = maskable ? 0.5 : 0.225;

  if (!maskable && !dentroRedondeado(u, v, radioMarco)) {
    return [0, 0, 0, 0];
  }

  const dy = v - 0.5;
  let color = mezclar(NAVY_1, NAVY_2, Math.min(1, Math.max(0, (v - 0.12) / 0.8)));

  // Halo suave
  const halo = Math.hypot(u - 0.5, v - 0.46);
  if (halo < 0.44) color = mezclar(color, [24, 44, 68], 0.25);

  const r = maskable ? 0.225 : 0.255;
  const grosor = maskable ? 0.068 : 0.078;
  const distancia = Math.hypot(u - 0.5, dy);
  const enAnillo = distancia <= r + grosor / 2 && distancia >= r - grosor / 2;

  const anchoCamino = maskable ? 0.062 : 0.07;
  const enCamino = Math.abs(u - 0.5) < anchoCamino && Math.abs(dy) < r + grosor / 2;

  if (enCamino && Math.abs(dy) < r + grosor / 2 + 0.012) {
    color = ASFALTO;
  }

  if (enAnillo && !enCamino) {
    color = ROJO;
  }

  // Línea central discontinua del camino
  if (enCamino && Math.abs(u - 0.5) < 0.014) {
    const tramo = Math.floor((v + 0.03) * 26) % 2;
    color = tramo === 0 ? AMARILLO : ASFALTO;
  }

  return [...color, 255];
}

function generarIcono(tamano, maskable = false) {
  const SUB = 4;
  const buffer = Buffer.alloc(tamano * tamano * 4);

  for (let y = 0; y < tamano; y += 1) {
    for (let x = 0; x < tamano; x += 1) {
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;

      for (let sy = 0; sy < SUB; sy += 1) {
        for (let sx = 0; sx < SUB; sx += 1) {
          const u = (x + (sx + 0.5) / SUB) / tamano;
          const v = (y + (sy + 0.5) / SUB) / tamano;
          const [pr, pg, pb, pa] = muestra(u, v, maskable);
          r += pr;
          g += pg;
          b += pb;
          a += pa;
        }
      }

      const n = SUB * SUB;
      const idx = (y * tamano + x) * 4;
      buffer[idx] = Math.round(r / n);
      buffer[idx + 1] = Math.round(g / n);
      buffer[idx + 2] = Math.round(b / n);
      buffer[idx + 3] = Math.round(a / n);
    }
  }

  return crearPNG(tamano, tamano, (x, y) => {
    const idx = (y * tamano + x) * 4;
    return [
      buffer[idx],
      buffer[idx + 1],
      buffer[idx + 2],
      buffer[idx + 3]
    ];
  });
}

const salidas = [
  ['icon-192.png', 192, false],
  ['icon-512.png', 512, false],
  ['maskable-512.png', 512, true],
  ['apple-touch-icon.png', 180, false]
];

for (const [nombre, tamano, maskable] of salidas) {
  writeFileSync(join(destino, nombre), generarIcono(tamano, maskable));
  console.log(`✓ ${nombre} (${tamano}×${tamano})`);
}

console.log(`\nIconos generados en ${destino}`);
