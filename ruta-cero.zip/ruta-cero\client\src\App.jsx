import { useEffect } from 'react';
import {
  Navigate,
  Route,
  Routes,
  useLocation
} from 'react-router-dom';
import { SesionProvider, useSesion } from './context/SesionContexto.jsx';
import Registro from './pages/Registro.jsx';
import Inicio from './pages/Inicio.jsx';
import Choque from './pages/Choque.jsx';
import Resultado from './pages/Resultado.jsx';
import Cuenta from './pages/Cuenta.jsx';
import Editar from './pages/Editar.jsx';
import MapaServicios from './pages/MapaServicios.jsx';

function AlCambiarRuta() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function RutaPrivada({ children }) {
  const { autenticado } = useSesion();
  const location = useLocation();

  if (!autenticado) {
    return <Navigate to="/" replace state={{ desde: location.pathname }} />;
  }

  return children;
}

function RutaPublica({ children }) {
  const { autenticado } = useSesion();
  if (autenticado) return <Navigate to="/inicio" replace />;
  return children;
}

export default function App() {
  return (
    <SesionProvider>
      <AlCambiarRuta />
      <Routes>
        <Route
          path="/"
          element={
            <RutaPublica>
              <Registro />
            </RutaPublica>
          }
        />
        <Route
          path="/inicio"
          element={
            <RutaPrivada>
              <Inicio />
            </RutaPrivada>
          }
        />
        <Route
          path="/choque"
          element={
            <RutaPrivada>
              <Choque />
            </RutaPrivada>
          }
        />
        <Route
          path="/resultado"
          element={
            <RutaPrivada>
              <Resultado />
            </RutaPrivada>
          }
        />
        <Route
          path="/cuenta"
          element={
            <RutaPrivada>
              <Cuenta />
            </RutaPrivada>
          }
        />
        <Route
          path="/cuenta/editar"
          element={
            <RutaPrivada>
              <Editar />
            </RutaPrivada>
          }
        />
        <Route
          path="/mapa"
          element={
            <RutaPrivada>
              <MapaServicios />
            </RutaPrivada>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </SesionProvider>
  );
}
