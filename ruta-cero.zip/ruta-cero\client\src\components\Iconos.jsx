/**
 * Set de iconos SVG dibujados a mano, sin dependencias ni fuentes de iconos.
 * Heredan el color con currentColor.
 */

function Icono({ children, size = 24, titulo, className = '', ...resto }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden={titulo ? undefined : 'true'}
      role={titulo ? 'img' : undefined}
      focusable="false"
      {...resto}
    >
      {titulo ? <title>{titulo}</title> : null}
      {children}
    </svg>
  );
}

export const IconoAlerta = (props) => (
  <Icono {...props}>
    <path d="M10.3 3.9 2.6 17.2A2 2 0 0 0 4.3 20h15.4a2 2 0 0 0 1.7-2.8L13.7 3.9a2 2 0 0 0-3.4 0Z" />
    <path d="M12 9v4" />
    <path d="M12 16.6h.01" />
  </Icono>
);

export const IconoChoque = (props) => (
  <Icono {...props}>
    <path d="M3 14.5 4.7 9A2 2 0 0 1 6.6 7.6h8.8A2 2 0 0 1 17.3 9l1.7 5.5" />
    <path d="M3 14.5h18V18h-2.2M5.2 18H3v-3.5" />
    <circle cx="7" cy="18" r="1.8" />
    <circle cx="17" cy="18" r="1.8" />
    <path d="M9.5 11h2.2" />
    <path d="m17.6 3 .8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2Z" />
  </Icono>
);

export const IconoCuenta = (props) => (
  <Icono {...props}>
    <circle cx="12" cy="8" r="3.6" />
    <path d="M4.6 20.2a7.6 7.6 0 0 1 14.8 0" />
  </Icono>
);

export const IconoGrua = (props) => (
  <Icono {...props}>
    <path d="M2.5 17V8h10v9" />
    <path d="M12.5 10h4.2l3.8 4v3" />
    <circle cx="6" cy="18" r="2" />
    <circle cx="17" cy="18" r="2" />
    <path d="M2.5 17h1.5M8 17h7M19 17h2.5" />
    <path d="M5 8 4 4h7l1 4" />
    <path d="M7.5 4.5v2" />
  </Icono>
);

export const IconoTransito = (props) => (
  <Icono {...props}>
    <rect x="7" y="2.5" width="10" height="17" rx="3" />
    <circle cx="12" cy="7" r="1.4" fill="currentColor" stroke="none" />
    <circle cx="12" cy="11.5" r="1.4" />
    <circle cx="12" cy="16" r="1.4" />
    <path d="M12 19.5V22" />
  </Icono>
);

export const IconoAmbulancia = (props) => (
  <Icono {...props}>
    <path d="M2.5 16.5V8.5a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v8" />
    <path d="M15.5 10.5h3.3l2.7 3.2v2.8" />
    <path d="M2.5 16.5h1.8M6.8 16.5h7.4M16.5 16.5h1.2M22 16.5h-.2" />
    <circle cx="5" cy="17.5" r="1.8" />
    <circle cx="14.5" cy="17.5" r="1.8" />
    <path d="M8.5 9.5v4M6.5 11.5h4" />
    <path d="M6 6h5" />
  </Icono>
);

export const IconoTelefono = (props) => (
  <Icono {...props}>
    <path d="M7.2 3.8 9 8.1a1.6 1.6 0 0 1-.4 1.8L7.2 11a12.7 12.7 0 0 0 5.8 5.8l1.1-1.4a1.6 1.6 0 0 1 1.8-.4l4.3 1.8a1.8 1.8 0 0 1 1 1.9l-.2 1.7a2 2 0 0 1-2.2 1.7C10.2 21.3 2.7 13.8 1.9 5.2A2 2 0 0 1 3.6 3l1.7-.2a1.8 1.8 0 0 1 1.9 1Z" />
  </Icono>
);

export const IconoMapa = (props) => (
  <Icono {...props}>
    <path d="m9 4 6 2 5.5-2v14L15 20l-6-2-5.5 2V6L9 4Z" />
    <path d="M9 4v14M15 6v14" />
  </Icono>
);

export const IconoUbicacion = (props) => (
  <Icono {...props}>
    <path d="M20 10.5c0 5.5-8 11-8 11s-8-5.5-8-11a8 8 0 1 1 16 0Z" />
    <circle cx="12" cy="10.5" r="2.8" />
  </Icono>
);

export const IconoCheck = (props) => (
  <Icono {...props}>
    <path d="m4.5 12.5 4.5 4.5L19.5 6.5" />
  </Icono>
);

export const IconoCheckCirculo = (props) => (
  <Icono {...props}>
    <circle cx="12" cy="12" r="9.2" />
    <path d="m8 12.3 2.6 2.6 5.6-6" />
  </Icono>
);

export const IconoReloj = (props) => (
  <Icono {...props}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5.5l3.4 2" />
  </Icono>
);

export const IconoAuto = (props) => (
  <Icono {...props}>
    <path d="m3.5 14 1.8-5.4A2.5 2.5 0 0 1 7.7 7h8.6a2.5 2.5 0 0 1 2.4 1.6L20.5 14" />
    <path d="M3 14h18v4.2h-2.3M5.3 18.2H3V14" />
    <circle cx="7.5" cy="18.3" r="1.7" />
    <circle cx="16.5" cy="18.3" r="1.7" />
    <path d="M6 11h12" />
  </Icono>
);

export const IconoEscudo = (props) => (
  <Icono {...props}>
    <path d="M12 2.7 4.5 5.8v5.4c0 4.9 3.2 8.5 7.5 10.1 4.3-1.6 7.5-5.2 7.5-10.1V5.8L12 2.7Z" />
    <path d="m8.7 11.7 2.2 2.2 4.4-4.6" />
  </Icono>
);

export const IconoEditar = (props) => (
  <Icono {...props}>
    <path d="M4 20h4.2L20 8.2a2.1 2.1 0 0 0-3-3L5.2 17 4 20Z" />
    <path d="m15.5 6.7 1.8 1.8" />
  </Icono>
);

export const IconoBasura = (props) => (
  <Icono {...props}>
    <path d="M4 7h16M9 7V4.5h6V7M6 7l1 13h10l1-13" />
    <path d="M10 11v5.5M14 11v5.5" />
  </Icono>
);

export const IconoSalir = (props) => (
  <Icono {...props}>
    <path d="M14 4h4.5A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5H14" />
    <path d="M9 8l-4 4 4 4M5 12h11" />
  </Icono>
);

export const IconoFlechaIzquierda = (props) => (
  <Icono {...props}>
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </Icono>
);

export const IconoActualizar = (props) => (
  <Icono {...props}>
    <path d="M20 11a8 8 0 1 0-.7 4" />
    <path d="M20 4v7h-7" />
  </Icono>
);

export const IconoInfo = (props) => (
  <Icono {...props}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v5M12 8h.01" />
  </Icono>
);

export const IconoRayo = (props) => (
  <Icono {...props}>
    <path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5Z" />
  </Icono>
);

export const IconoRuta = (props) => (
  <Icono {...props}>
    <circle cx="5.5" cy="18.5" r="2.2" />
    <circle cx="18.5" cy="5.5" r="2.2" />
    <path d="M7.5 17.3c3.6-1.2 2.4-4.8 5-6.5 1.8-1.2 3.9-.8 5-2.1" strokeDasharray="2.5 3" />
  </Icono>
);

export const IconoTrafico = (props) => (
  <Icono {...props}>
    <path d="M4 20V13M10 20V9M16 20V5M22 20H2" />
  </Icono>
);

export const IconoX = (props) => (
  <Icono {...props}>
    <path d="M6 6l12 12M18 6 6 18" />
  </Icono>
);

export const IconoEnviar = (props) => (
  <Icono {...props}>
    <path d="M21 3 10.5 13.5M21 3l-6.5 18-4-8-8-4L21 3Z" />
  </Icono>
);

export const IconoBateria = (props) => (
  <Icono {...props}>
    <rect x="2.5" y="8" width="16" height="9" rx="2" />
    <path d="M21 11v3M5.5 11v3M8.5 11v3M11.5 11v3" />
  </Icono>
);
