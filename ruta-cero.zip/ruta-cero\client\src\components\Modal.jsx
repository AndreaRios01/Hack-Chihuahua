import { useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import { IconoX } from './Iconos.jsx';

const SELECTOR_ENFOCABLES =
  'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/**
 * Diálogo accesible: bloquea el fondo, atrapa el foco y se cierra con Escape.
 */
export default function Modal({
  abierto,
  onCerrar,
  titulo,
  etiqueta,
  children,
  className = '',
  bloquearCierre = false,
  cerrarAlFondo = true
}) {
  const panelRef = useRef(null);
  const idTitulo = useId();

  useEffect(() => {
    if (!abierto) return undefined;

    const focoPrevio = document.activeElement;
    const overflowPrevio = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const temporizador = requestAnimationFrame(() => {
      const panel = panelRef.current;
      if (!panel) return;
      const primero = panel.querySelector('[data-enfoque-inicial]');
      const enfocables = panel.querySelectorAll(SELECTOR_ENFOCABLES);
      (primero || enfocables[0] || panel).focus?.();
    });

    const alPresionar = (evento) => {
      if (evento.key === 'Escape' && !bloquearCierre) {
        evento.preventDefault();
        onCerrar?.();
        return;
      }

      if (evento.key !== 'Tab') return;

      const panel = panelRef.current;
      if (!panel) return;
      const enfocables = [...panel.querySelectorAll(SELECTOR_ENFOCABLES)].filter(
        (elemento) =>
          !elemento.hasAttribute('disabled') &&
          elemento.getAttribute('aria-hidden') !== 'true' &&
          elemento.offsetParent !== null
      );

      if (enfocables.length === 0) {
        evento.preventDefault();
        panel.focus();
        return;
      }

      const primero = enfocables[0];
      const ultimo = enfocables[enfocables.length - 1];

      if (evento.shiftKey && document.activeElement === primero) {
        evento.preventDefault();
        ultimo.focus();
      } else if (!evento.shiftKey && document.activeElement === ultimo) {
        evento.preventDefault();
        primero.focus();
      }
    };

    document.addEventListener('keydown', alPresionar);

    return () => {
      cancelAnimationFrame(temporizador);
      document.removeEventListener('keydown', alPresionar);
      document.body.style.overflow = overflowPrevio;
      if (focoPrevio instanceof HTMLElement && document.contains(focoPrevio)) {
        focoPrevio.focus();
      }
    };
  }, [abierto, bloquearCierre, onCerrar]);

  if (!abierto) return null;

  return createPortal(
    <div
      className="modal-fondo"
      onMouseDown={(evento) => {
        if (
          cerrarAlFondo &&
          !bloquearCierre &&
          evento.target === evento.currentTarget
        ) {
          onCerrar?.();
        }
      }}
    >
      <div
        ref={panelRef}
        className={`modal-panel ${className}`.trim()}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titulo ? idTitulo : undefined}
        aria-label={!titulo ? etiqueta : undefined}
        tabIndex={-1}
      >
        {titulo ? (
          <div className="modal-cabecera">
            <h2 id={idTitulo}>{titulo}</h2>
            {!bloquearCierre ? (
              <button
                type="button"
                className="modal-cerrar"
                onClick={onCerrar}
                aria-label="Cerrar"
              >
                <IconoX size={20} />
              </button>
            ) : null}
          </div>
        ) : null}
        {children}
      </div>
    </div>,
    document.body
  );
}
