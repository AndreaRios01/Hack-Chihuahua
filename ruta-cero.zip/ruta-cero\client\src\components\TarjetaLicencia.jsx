import Avatar from './Avatar.jsx';
import Logo from './Logo.jsx';
import { IconoEscudo, IconoTelefono } from './Iconos.jsx';
import { formatearTelefono } from '../lib/formato.js';

/**
 * Tarjeta ficticia inspirada en una licencia de conducir.
 * No reproduce el diseño de ningún documento oficial: es una pieza de marca DEMO.
 */
export default function TarjetaLicencia({ usuario }) {
  if (!usuario) return null;

  return (
    <article
      className="licencia"
      aria-label={`Licencia de conducir ficticia de demostración de ${usuario.nombre}`}
    >
      <div className="licencia-franja" aria-hidden="true">
        <span />
        <span />
        <span />
      </div>

      <header className="licencia-cabecera">
        <div className="licencia-marca">
          <Logo tamano={30} conTexto={false} />
          <div>
            <strong>RUTA CERO</strong>
            <span>Licencia digital de demostración</span>
          </div>
        </div>
        <span className="licencia-demo">DEMO / FICTICIA</span>
      </header>

      <div className="licencia-cuerpo">
        <div className="licencia-avatar">
          <Avatar nombre={usuario.nombre} tamano={80} />
          <span className="licencia-chip" aria-hidden="true">
            <i />
            <i />
            <i />
          </span>
        </div>

        <div className="licencia-principal">
          <p className="licencia-kicker">TITULAR</p>
          <h2>{usuario.nombre}</h2>

          <dl className="licencia-datos">
            <div>
              <dt>PLACAS</dt>
              <dd>{usuario.placas}</dd>
            </div>
            <div>
              <dt>VEHÍCULO</dt>
              <dd>{usuario.modelo_vehiculo}</dd>
            </div>
            <div className="licencia-dato-ancho">
              <dt>N.º DE LICENCIA</dt>
              <dd>{usuario.licencia}</dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="licencia-contacto">
        <IconoEscudo size={20} aria-hidden="true" />
        <div>
          <span>CONTACTO DE EMERGENCIA</span>
          <strong>
            {usuario.contacto_emergencia_nombre} ·{' '}
            <a href={`tel:${usuario.contacto_emergencia_telefono}`}>
              <IconoTelefono size={13} aria-hidden="true" />{' '}
              {formatearTelefono(usuario.contacto_emergencia_telefono)}
            </a>
          </strong>
        </div>
      </div>

      <footer className="licencia-pie">
        <span className="licencia-codigo" aria-hidden="true" />
        <span>Documento ficticio · No oficial</span>
        <span className="licencia-serie">{usuario.licencia}</span>
      </footer>

      <span className="licencia-marca-agua" aria-hidden="true">
        DEMO
      </span>
    </article>
  );
}
