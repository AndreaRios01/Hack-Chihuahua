import { useNavigate } from 'react-router-dom';
import { IconoFlechaIzquierda } from './Iconos.jsx';

export default function BotonVolver({ destino = '/inicio', etiqueta = 'Regresar' }) {
  const navigate = useNavigate();

  return (
    <button
      type="button"
      className="boton-volver"
      onClick={() => navigate(destino)}
      aria-label={etiqueta}
    >
      <IconoFlechaIzquierda size={20} aria-hidden="true" />
      <span>{etiqueta}</span>
    </button>
  );
}
