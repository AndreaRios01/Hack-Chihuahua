# RUTA CERO

**Espacio inteligente de movilidad y respuesta ante emergencias.**
Prototipo móvil (PWA) para un hackatón: emergencias en 3 segundos, reporte de choques,
servicios cercanos y una licencia digital de demostración. Funciona **sin ninguna API key**
y guarda todo en SQLite local.

> **Aviso:** los teléfonos, servicios, personas y alertas son ficticios. Esta demo **no
> llama al 911, no envía grúas reales y no sustituye a los servicios de emergencia.**
> Si hay una emergencia real, usa tu teléfono.

---

## 1. Qué incluye

| Pantalla | Qué hace |
| --- | --- |
| **Registro / acceso** | Alta sin contraseña (el teléfono es la llave), datos personales, contacto de emergencia y vehículo. |
| **Inicio** | Tres acciones apiladas: **EMERGENCIA** (roja, dominante), **CHOQUE** (amarilla) y **CUENTA** (verde). |
| **Emergencia** | Confirmación cancelable de **3 segundos** con cuenta regresiva. Si se confirma, envía la ubicación al contacto, a la grúa y a tránsito más cercanos. |
| **Choque / accidente** | Tipo de incidente, servicios requeridos (ambulancia, grúa, tránsito) y botón **LLAMAR**. En un accidente también se avisa al contacto. |
| **Resultado** | Estado «Enviado» por destinatario, mapa Leaflet, enlace a Google Maps y botón de llamada al servicio asignado. |
| **Mi cuenta** | Licencia digital ficticia con avatar SVG, historial de alertas, actualización de datos y baja del automóvil. |
| **Mapa** | Grúas, tránsito, ambulancias y tráfico simulado sobre OpenStreetMap; ruta sugerida y servicios más cercanos. |

Extras:

- Geolocalización real con **respaldo automático al centro de Chihuahua** (con aviso visible)
  si el navegador la bloquea o no está disponible.
- Cálculo de distancias con **Haversine** en el servidor.
- Notificaciones **simuladas por defecto**; Twilio opcional mediante variables de entorno.
- Interfaz mobile-first, objetivos táctiles de al menos 48 px, etiquetas ARIA, foco visible,
  mensajes en español y vibración cuando el dispositivo la soporta.
- PWA instalable en producción (manifest, iconos y service worker).

---

## 2. Tecnologías

- **Cliente:** React 18, React Router 6, Vite 6, Leaflet 1.9 + OpenStreetMap, CSS propio.
- **Servidor:** Node.js, Express 4, `better-sqlite3` (SQLite).
- **Monorepo:** npm workspaces (`client` y `server`) y `concurrently` para un solo `npm run dev`.
- **Notificaciones:** servicio aislado con modo simulado y Twilio REST opcional (`fetch`, sin SDK).

---

## 3. Requisitos

- **Node.js 20 o superior** (probado con Node 26).
- npm 10 o superior.
- Navegador moderno. Para probar la PWA conviene Chrome/Edge o Safari en el celular.

No hace falta crear ninguna cuenta ni pegar llaves: la app arranca en modo demo.

---

## 4. Inicio rápido

Desde la carpeta `ruta-cero`:

```bash
npm install
npm run seed
npm run dev
```

Abre **http://localhost:5173**.

El comando `dev` levanta dos procesos:

- API Express en **http://localhost:4000** (Vite le hace proxy a `/api`).
- Cliente Vite en **http://localhost:5173**.

### Cuenta demo

- Teléfono: **614 123 4567**
- No tiene contraseña.
- En la pantalla de acceso puedes tocar **«USAR CUENTA DEMO · ANA SOFÍA»**.
- El seed también crea a Carlos Mendoza (`6142345678`) y María Fernanda Ortega
  (`6143456789`), con historiales de ejemplo.

> `npm run seed` **reinicia** la base: borra usuarios, servicios, alertas y envíos, y vuelve
> a cargar los datos de demostración. Úsalo cuando quieras una demo limpia.

---

## 5. Guion de demo (2 minutos)

| Tiempo | Qué mostrar |
| --- | --- |
| 0:00–0:15 | Abrir `http://localhost:5173`, tocar **USAR CUENTA DEMO · ANA SOFÍA** y entrar al inicio. Señalar el indicador de ubicación y la insignia **MODO DEMO**. |
| 0:15–0:40 | Tocar **EMERGENCIA**. Aparece la cuenta regresiva de **3 s** y el botón **CANCELAR**. Dejar que se envíe sola. |
| 0:40–1:05 | En el resultado: alerta **Enviada**, **3 envíos** (contacto, grúa y tránsito), distancias Haversine, mapa y enlace a Google Maps. Aclarar que no hay SMS reales. |
| 1:05–1:30 | Volver al inicio → **CHOQUE** → elegir **Accidente**, marcar **Ambulancia** y **Tránsito** → **LLAMAR**. Mostrar que ahora hay **4 envíos** porque también se avisa al contacto. |
| 1:30–1:45 | **CUENTA**: licencia ficticia con avatar, historial de alertas, botones **ACTUALIZAR** y **DAR DE BAJA**. |
| 1:45–2:00 | Abrir el **mapa** (tráfico simulado, servicios y ruta sugerida) y cerrar con: «todo corre local, sin API keys; Twilio es opcional». |

**Tip para el jurado:** en escritorio el botón de llamada no marca; en celular abre el
marcador con el número ficticio `614 000 00XX`.

---

## 6. Estructura del proyecto

```text
ruta-cero/
├─ package.json              # scripts raíz y workspaces
├─ .env.example              # variables opcionales (Twilio)
├─ ruta_cero.db              # SQLite local (se crea/llena con npm run seed)
├─ client/
│  ├─ public/
│  │  ├─ manifest.webmanifest
│  │  ├─ sw.js
│  │  └─ icons/              # iconos PNG de la PWA
│  └─ src/
│     ├─ pages/              # Registro, Inicio, Choque, Resultado, Cuenta, Editar, MapaServicios
│     ├─ components/         # EmergenciaOverlay, TarjetaLicencia, Mapa, Modal, Aviso, Iconos…
│     ├─ context/            # sesión (localStorage)
│     ├─ hooks/              # geolocalización
│     ├─ lib/                # api, formato, validaciones, almacenamiento
│     ├─ App.jsx
│     └─ styles.css
└─ server/
   └─ src/
      ├─ index.js            # Express + estáticos del build
      ├─ db.js               # esquema SQLite y helpers
      ├─ seed.js             # datos de demostración
      ├─ datosSemilla.js     # usuarios y servicios ficticios
      ├─ routes/api.js       # endpoints REST
      ├─ services/
      │  ├─ alertas.js       # creación de alertas y asignación Haversine
      │  └─ notificaciones.js# simulado / Twilio
      └─ utils/              # geo y validaciones
```

---

## 7. API REST

Base: `http://localhost:4000/api`

| Método | Ruta | Descripción |
| --- | --- | --- |
| `GET` | `/salud` | Estado del servidor, modo de notificaciones y número de servicios. |
| `POST` | `/registro` | Crea una cuenta. Si el teléfono ya existe activo, entra; si estaba dado de baja, lo reactiva con los datos nuevos. |
| `POST` | `/login` | Acceso por teléfono. Devuelve `403` si el vehículo está dado de baja. |
| `GET` | `/usuario/:id` | Datos públicos del usuario. |
| `PUT` | `/usuario/:id` | Actualiza datos personales, contacto y vehículo. |
| `PATCH` | `/usuario/:id/baja` | Baja lógica del vehículo (`activo = 0`). |
| `DELETE` | `/usuario/:id` | Alias de la baja lógica (no borra el historial). |
| `POST` | `/emergencia` | Crea una alerta de emergencia y notifica a contacto + grúa + tránsito cercanos. |
| `POST` | `/choque` | Crea un reporte de choque/accidente con los servicios marcados; en accidente agrega al contacto. |
| `GET` | `/alertas/:usuarioId` | Historial de alertas con el detalle de cada envío. |
| `GET` | `/servicios` | Catálogo completo de servicios ficticios. |
| `GET` | `/cercanos?lat=&lng=` | Servicios ordenados por distancia Haversine. |
| `GET` | `/trafico?lat=&lng=` | Tráfico simulado determinista y ruta sugerida (sin APIs externas). |

Las alertas se guardan con fecha, coordenadas y estado **«Enviado»**. Cada destinatario
(contacto, grúa, tránsito, ambulancia) genera un registro en `envios` con su estado, canal
(`simulado` o `sms`) y detalle.

### Ejemplos rápidos

```bash
curl http://localhost:4000/api/salud

curl -X POST http://localhost:4000/api/login \
  -H "Content-Type: application/json" \
  -d "{\"telefono\":\"6141234567\"}"

curl -X POST http://localhost:4000/api/emergencia \
  -H "Content-Type: application/json" \
  -d "{\"usuario_id\":1,\"latitud\":28.6353,\"longitud\":-106.0889}"
```

---

## 8. Base de datos

Archivo: `ruta_cero.db` en la raíz (configurable con `DB_ARCHIVO`).

- **`usuarios`**: nombre, teléfono único, contacto de emergencia, vehículo, placas,
  licencia, `activo`, fecha de alta.
- **`servicios`**: tipo (`grua`, `transito`, `ambulancia`), nombre, teléfono, dirección,
  coordenadas y horario.
- **`alertas`**: usuario, tipo, servicios solicitados (JSON), coordenadas, precisión,
  indicador de ubicación aproximada, estado, mensaje y fecha.
- **`envios`**: un registro por destinatario, con nombre, teléfono, servicio asignado,
  estado, canal y detalle del envío.

El catálogo se siembra automáticamente si la tabla de servicios está vacía, y
`npm run seed` deja 3 usuarios, 4 grúas, 3 oficinas de tránsito, 3 ambulancias y
3 alertas históricas con sus envíos.

### Cómo se elige el servicio

1. El cliente envía latitud/longitud (GPS real o centro de Chihuahua como respaldo).
2. El servidor calcula la distancia Haversine a cada servicio del tipo solicitado.
3. Asigna el más cercano, registra el envío y devuelve distancia y ETA estimada.
4. El mensaje generado incluye nombre, vehículo, placas, enlace de Google Maps y hora local.

---

## 9. Notificaciones: simulado por defecto, Twilio opcional

Todo el envío está aislado en `server/src/services/notificaciones.js`.

- **Sin llaves:** no se hace ninguna llamada externa. El envío se registra como
  `Enviado` con canal `simulado`. La app funciona sin internet.
- **Con Twilio:** si defines `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN` y `TWILIO_FROM`,
  intenta enviar un SMS real. Si Twilio falla o no hay red, **no rompe la app**: cae al
  modo simulado y guarda el detalle del error.

Para activarlo, copia `.env.example` a `.env` y completa las tres variables. Reinicia el
servidor. El endpoint `/api/salud` muestra el modo actual (`simulado` o `sms_opcional`).

> En una demo real evita enviar SMS a números ajenos: usa tu propio número o deja el modo
> simulado.

---

## 10. PWA instalable

El service worker solo se registra en **producción** para no interferir con el hot reload.

```bash
npm run build
npm start
```

Abre **http://localhost:4000** y usa «Instalar aplicación» en Chrome/Edge (o «Agregar a
pantalla de inicio» en el celular). El servidor Express sirve `client/dist` y la API desde
el mismo origen.

> Para instalar en un teléfono por red local necesitas HTTPS (o `localhost`); los
> service workers no se habilitan en HTTP con IP. Para la demo alcanza con mostrarla en el
> navegador o desplegarla en un hosting con HTTPS.

---

## 11. Scripts disponibles

Desde la raíz:

| Comando | Qué hace |
| --- | --- |
| `npm run dev` | API con recarga + Vite en paralelo. |
| `npm run seed` | Reinicia y siembra la base de demostración. |
| `npm run build` | Compila el cliente en `client/dist`. |
| `npm start` | Sirve el build y la API en el puerto 4000. |
| `npm run iconos` | Regenera los iconos PNG de la PWA (script propio, sin dependencias). |

---

## 12. Variables de entorno

Archivo `.env` en la raíz (opcional; hay valores por defecto):

```ini
PUERTO=4000
DB_ARCHIVO=ruta_cero.db
ORIGEN_CLIENTE=http://localhost:5173

# Opcionales para SMS reales
# TWILIO_ACCOUNT_SID=AC...
# TWILIO_AUTH_TOKEN=...
# TWILIO_FROM=+1...
```

---

## 13. Decisiones de diseño y accesibilidad

- Paleta: rojo `#D62828`, amarillo `#FFC300`, verde `#2E9E4F` sobre fondo azul marino.
- La acción de emergencia ocupa la mayor parte de la pantalla y tiene confirmación de 3 s
  para reducir falsos positivos.
- Botones de al menos 48 px, foco visible, etiquetas ARIA y mensajes de error junto al campo.
- La cuenta regresiva se anuncia con `role="timer"` y `aria-live`; los avisos usan `role="status"`.
- La licencia es **explícitamente ficticia** y no reproduce el diseño de un documento oficial.
- En escritorio, los enlaces `tel:` no marcan; en móvil abren el marcador del sistema.

---

## 14. Problemas comunes

| Síntoma | Solución |
| --- | --- |
| El puerto 4000 o 5173 está ocupado | Cierra el proceso anterior o cambia `PUERTO` / el puerto de Vite. |
| «No pudimos conectar con el servidor» | Verifica que `npm run dev` siga corriendo y que la API responda en `/api/salud`. |
| La cuenta demo no entra | Ejecuta `npm run seed` para restaurar los usuarios. |
| `better-sqlite3` no instala | Usa Node 20+ y vuelve a ejecutar `npm install`; en Windows instala las Build Tools si npm lo pide. |
| Los mapas no cargan las calles | Leaflet usa OpenStreetMap: sin internet los marcadores siguen visibles, pero las calles no. |
| La PWA no aparece instalable | Compila (`npm run build`) y sirve con `npm start`/HTTPS; en desarrollo el service worker está desactivado a propósito. |

---

## 15. Alcance y créditos

Proyecto educativo de hackatón. No procesa pagos, no sustituye servicios de emergencia y
no envía datos a terceros salvo que configures Twilio de forma explícita.

- Datos, teléfonos y servicios: **ficticios**.
- Mapa: © colaboradores de OpenStreetMap.
- Hecho con React, Vite, Express, SQLite y Leaflet.
