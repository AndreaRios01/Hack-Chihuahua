/**
 * Validaciones y normalización compartidas por los endpoints.
 * Se mantienen deliberadamente estrictas: la demo debe resistir datos basura.
 */

export const SERVICIOS_VALIDOS = ['ambulancia', 'grua', 'transito'];
export const TIPOS_INCIDENTE = ['choque', 'accidente'];

const esTexto = (valor) => typeof valor === 'string' && valor.trim().length > 0;

/** Limpia espacios repetidos y recorta. */
export function limpiarTexto(valor) {
  return typeof valor === 'string' ? valor.replace(/\s+/g, ' ').trim() : '';
}

/**
 * Normaliza teléfonos mexicanos a 10 dígitos.
 * Acepta +52 614 123 4567, (614) 123-4567, 5216141234567, etc.
 */
export function normalizarTelefono(valor) {
  let digitos = String(valor ?? '').replace(/\D/g, '');

  if (digitos.length === 13 && digitos.startsWith('521')) {
    digitos = digitos.slice(3);
  } else if (digitos.length === 12 && digitos.startsWith('52')) {
    digitos = digitos.slice(2);
  }

  return digitos;
}

export function telefonoValido(valor) {
  return /^[0-9]{10}$/.test(normalizarTelefono(valor));
}

export function validarRegistro(datos = {}) {
  const limpio = {
    nombre: limpiarTexto(datos.nombre),
    telefono: normalizarTelefono(datos.telefono),
    contacto_emergencia_nombre: limpiarTexto(datos.contacto_emergencia_nombre),
    contacto_emergencia_telefono: normalizarTelefono(
      datos.contacto_emergencia_telefono
    ),
    modelo_vehiculo: limpiarTexto(datos.modelo_vehiculo),
    placas: limpiarTexto(datos.placas).toUpperCase(),
    licencia: limpiarTexto(datos.licencia).toUpperCase()
  };

  const errores = [];

  if (limpio.nombre.length < 2) {
    errores.push('Escribe tu nombre completo (mínimo 2 letras).');
  } else if (limpio.nombre.length > 80) {
    errores.push('El nombre no puede superar 80 caracteres.');
  }

  if (!/^[0-9]{10}$/.test(limpio.telefono)) {
    errores.push('El teléfono debe tener exactamente 10 dígitos.');
  }

  if (limpio.contacto_emergencia_nombre.length < 2) {
    errores.push('Escribe el nombre de tu contacto de emergencia.');
  }

  if (!/^[0-9]{10}$/.test(limpio.contacto_emergencia_telefono)) {
    errores.push('El teléfono del contacto debe tener 10 dígitos.');
  }

  if (limpio.modelo_vehiculo.length < 2) {
    errores.push('Indica el modelo del vehículo.');
  } else if (limpio.modelo_vehiculo.length > 80) {
    errores.push('El modelo del vehículo no puede superar 80 caracteres.');
  }

  if (!/^[A-Z0-9-]{4,12}$/.test(limpio.placas)) {
    errores.push('Las placas deben tener entre 4 y 12 letras, números o guiones.');
  }

  if (!/^[A-Z0-9-]{4,24}$/.test(limpio.licencia)) {
    errores.push('La licencia debe tener entre 4 y 24 letras, números o guiones.');
  }

  return { ok: errores.length === 0, errores, datos: limpio };
}

/** Acepta latitud/longitud del cliente y cae a Chihuahua si vienen inválidas. */
export function validarUbicacion(lat, lng, referencia) {
  const latitud = Number(lat);
  const longitud = Number(lng);

  const sonValidas =
    Number.isFinite(latitud) &&
    Number.isFinite(longitud) &&
    latitud >= -90 &&
    latitud <= 90 &&
    longitud >= -180 &&
    longitud <= 180;

  if (!sonValidas) {
    return {
      lat: referencia.lat,
      lng: referencia.lng,
      aproximada: true,
      precision: null,
      motivo: 'No se recibió una ubicación válida; usamos Chihuahua como referencia.'
    };
  }

  return { lat: latitud, lng: longitud, aproximada: false, precision: null };
}

/** Convierte un arreglo de servicios a JSON seguro y sin duplicados. */
export function normalizarServicios(lista) {
  if (!Array.isArray(lista)) return [];
  return [...new Set(lista.filter((s) => SERVICIOS_VALIDOS.includes(s)))];
}
