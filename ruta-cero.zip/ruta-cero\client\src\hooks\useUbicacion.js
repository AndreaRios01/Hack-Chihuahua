import { useCallback, useEffect, useRef, useState } from 'react';
import {
  estadoPermisoUbicacion,
  obtenerUbicacion
} from '../lib/ubicacion.js';

/**
 * Estado de ubicación para las pantallas.
 * Solo pide permiso automáticamente si el usuario ya lo había concedido.
 */
export function useUbicacion({ autoSiPermitido = true } = {}) {
  const [ubicacion, setUbicacion] = useState(null);
  const [estado, setEstado] = useState('inicial');
  const montado = useRef(true);

  useEffect(() => {
    montado.current = true;
    return () => {
      montado.current = false;
    };
  }, []);

  const solicitar = useCallback(async () => {
    setEstado('solicitando');
    const resultado = await obtenerUbicacion();
    if (!montado.current) return resultado;

    setUbicacion(resultado);
    setEstado(resultado.aproximada ? 'referencia' : 'lista');
    return resultado;
  }, []);

  useEffect(() => {
    if (!autoSiPermitido) return undefined;
    let activo = true;

    estadoPermisoUbicacion().then((permiso) => {
      if (activo && permiso === 'granted') solicitar();
    });

    return () => {
      activo = false;
    };
  }, [autoSiPermitido, solicitar]);

  return { ubicacion, estado, solicitar };
}
