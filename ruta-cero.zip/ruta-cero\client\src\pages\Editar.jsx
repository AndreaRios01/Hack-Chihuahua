import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSesion } from '../context/SesionContexto.jsx';
import { api } from '../lib/api.js';
import {
  mapearErroresServidor,
  validarFormulario
} from '../lib/validaciones.js';
import BotonVolver from '../components/BotonVolver.jsx';
import Aviso from '../components/Aviso.jsx';
import CamposUsuario from '../components/CamposUsuario.jsx';

export default function Editar() {
  const { usuario, actualizarSesion } = useSesion();
  const navigate = useNavigate();

  const [datos, setDatos] = useState({
    nombre: usuario?.nombre || '',
    telefono: usuario?.telefono || '',
    contacto_emergencia_nombre: usuario?.contacto_emergencia_nombre || '',
    contacto_emergencia_telefono:
      usuario?.contacto_emergencia_telefono || '',
    modelo_vehiculo: usuario?.modelo_vehiculo || '',
    placas: usuario?.placas || '',
    licencia: usuario?.licencia || ''
  });
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState(null);
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    document.title = 'Actualizar datos · RUTA CERO';
  }, []);

  const cambiarCampo = (campo, valor) => {
    setDatos((previos) => ({ ...previos, [campo]: valor }));
    if (errores[campo]) {
      setErrores((previos) => {
        const copia = { ...previos };
        delete copia[campo];
        return copia;
      });
    }
  };

  const guardar = async (evento) => {
    evento.preventDefault();
    setErrorGeneral(null);

    const validacion = validarFormulario(datos);
    if (!validacion.valido) {
      setErrores(validacion.errores);
      setErrorGeneral('Revisa los campos marcados en rojo.');
      return;
    }

    setGuardando(true);
    try {
      const respuesta = await api.actualizarUsuario(usuario.id, datos);
      actualizarSesion(respuesta.usuario);
      navigate('/cuenta', {
        replace: true,
        state: { actualizado: true }
      });
    } catch (fallo) {
      if (fallo.detalles?.length) {
        setErrores(mapearErroresServidor(fallo.detalles));
      }
      setErrorGeneral(fallo.message);
    } finally {
      setGuardando(false);
    }
  };

  if (!usuario) return null;

  return (
    <main className="pantalla pantalla-interior">
      <header className="barra-superior">
        <BotonVolver destino="/cuenta" etiqueta="Mi cuenta" />
        <div className="barra-titulo">
          <span>Editar perfil</span>
          <h1>Actualizar datos</h1>
        </div>
      </header>

      <div className="contenido-interior">
        <Aviso tipo="info" titulo="Datos de demostración">
          Puedes editar todos los campos. El teléfono es tu forma de entrar, así
          que debe ser único. Los cambios se guardan en la base SQLite local.
        </Aviso>

        {errorGeneral ? (
          <Aviso tipo="error" onCerrar={() => setErrorGeneral(null)}>
            {errorGeneral}
          </Aviso>
        ) : null}

        <form className="formulario" onSubmit={guardar} noValidate>
          <CamposUsuario
            datos={datos}
            errores={errores}
            onChange={cambiarCampo}
          />

          <div className="editar-acciones">
            <button
              type="submit"
              className="boton boton-verde boton-grande boton-ancho"
              disabled={guardando}
            >
              {guardando ? (
                <>
                  <span className="girador girador-boton" aria-hidden="true" />
                  GUARDANDO…
                </>
              ) : (
                'GUARDAR CAMBIOS'
              )}
            </button>
            <Link
              to="/cuenta"
              className="boton boton-secundario boton-ancho"
              aria-disabled={guardando}
            >
              CANCELAR
            </Link>
          </div>
        </form>
      </div>
    </main>
  );
}
