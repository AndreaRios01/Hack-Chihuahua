import { IconoUbicacion, IconoReloj } from './Iconos.jsx';

const ETIQUETAS = {
  inicial: 'Activar ubicación',
  solicitando: 'Ubicando…',
  lista: 'Ubicación activa',
  referencia: 'Ubicación de referencia'
};

export default function IndicadorUbicacion({ ubicacion, estado, solicitar }) {
  const esReferencia = estado === 'referencia';

  return (
    <button
      type="button"
      className={`chip-ubicacion ${esReferencia ? 'chip-ubicacion-referencia' : ''}`.trim()}
      onClick={() => solicitar?.()}
      disabled={estado === 'solicitando'}
      aria-label={
        esReferencia
          ? 'Ubicación aproximada de Chihuahua. Toca para intentar obtener tu ubicación real.'
          : 'Ubicación del dispositivo. Toca para actualizarla.'
      }
      title={ubicacion?.motivo || 'Toca para actualizar tu ubicación'}
    >
      <span className="chip-ubicacion-icono" aria-hidden="true">
        {estado === 'solicitando' ? (
          <span className="girador girador-chico" />
        ) : esReferencia ? (
          <IconoReloj size={16} />
        ) : (
          <IconoUbicacion size={16} />
        )}
      </span>
      <span className="chip-ubicacion-texto">
        <strong>{ETIQUETAS[estado] || ETIQUETAS.inicial}</strong>
        <small>
          {estado === 'lista' && ubicacion?.precision
            ? `Precisión ±${ubicacion.precision} m`
            : esReferencia
              ? 'Chihuahua, Chih. · toca para reintentar'
              : estado === 'solicitando'
                ? 'Pidiendo permiso al navegador'
                : 'Toca para permitir el GPS'}
        </small>
      </span>
    </button>
  );
}
