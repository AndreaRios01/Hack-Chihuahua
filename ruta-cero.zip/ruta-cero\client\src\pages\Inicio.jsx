import { useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSesion } from '../context/SesionContexto.jsx';
import { useUbicacion } from '../hooks/useUbicacion.js';
import { guardarResultado } from '../lib/sesion.js';
import Logo from '../components/Logo.jsx';
import Aviso from '../components/Aviso.jsx';
import IndicadorUbicacion from '../components/IndicadorUbicacion.jsx';
import EmergenciaOverlay from '../components/EmergenciaOverlay.jsx';
import {
  IconoAlerta,
  IconoChoque,
  IconoCuenta,
  IconoMapa,
  IconoRuta
} from '../components/Iconos.jsx';

export default function Inicio() {
  const { usuario } = useSesion();
  const navigate = useNavigate();
  const location = useLocation();
  const { ubicacion, estado, solicitar } = useUbicacion();

  const [emergenciaAbierta, setEmergenciaAbierta] = useState(false);
  const [bienvenida, setBienvenida] = useState(location.state?.bienvenida || null);

  useEffect(() => {
    document.title = 'Inicio · RUTA CERO';
  }, []);

  const cerrarEmergencia = useCallback(() => {
    setEmergenciaAbierta(false);
  }, []);

  const alEnviarEmergencia = useCallback(
    (datos) => {
      guardarResultado(datos);
      setEmergenciaAbierta(false);
      navigate('/resultado');
    },
    [navigate]
  );

  const primerNombre = usuario.nombre.split(' ')[0];

  return (
    <main className="pantalla pantalla-inicio">
      <header className="inicio-cabecera">
        <div className="inicio-marca">
          <Logo tamano={38} />
          <div className="inicio-saludo">
            <p>Hola, {primerNombre}</p>
            <h1>¿Todo bien?</h1>
          </div>
        </div>
        <Link
          to="/mapa"
          className="boton-icono"
          aria-label="Abrir mapa de servicios y tráfico simulado"
        >
          <IconoMapa size={22} aria-hidden="true" />
        </Link>
      </header>

      <div className="inicio-ubicacion">
        <IndicadorUbicacion
          ubicacion={ubicacion}
          estado={estado}
          solicitar={solicitar}
        />
        <span className="insignia-demo">MODO DEMO</span>
      </div>

      {bienvenida ? (
        <Aviso tipo="exito" onCerrar={() => setBienvenida(null)}>
          {bienvenida}
        </Aviso>
      ) : null}

      <section className="acciones" aria-label="Acciones principales">
        <button
          type="button"
          className="boton-accion accion-emergencia"
          onClick={() => setEmergenciaAbierta(true)}
          aria-label="Emergencia. Envía tu ubicación a tu contacto, a la grúa más cercana y a tránsito. Pide confirmación de 3 segundos."
        >
          <span className="accion-brillo" aria-hidden="true" />
          <span className="accion-icono" aria-hidden="true">
            <IconoAlerta size={38} />
          </span>
          <span className="accion-titulo">EMERGENCIA</span>
          <span className="accion-subtitulo">
            Un toque · confirmación de 3 segundos
          </span>
          <span className="accion-sello" aria-hidden="true">
            3 s
          </span>
        </button>

        <button
          type="button"
          className="boton-accion accion-choque"
          onClick={() => navigate('/choque')}
          aria-label="Choque o accidente. Elige los servicios que necesitas y llama."
        >
          <span className="accion-icono" aria-hidden="true">
            <IconoChoque size={26} />
          </span>
          <span className="accion-titulo">CHOQUE</span>
          <span className="accion-subtitulo">
            Ambulancia, grúa o tránsito
          </span>
        </button>

        <button
          type="button"
          className="boton-accion accion-cuenta"
          onClick={() => navigate('/cuenta')}
          aria-label="Mi cuenta. Ver licencia y datos del vehículo."
        >
          <span className="accion-icono" aria-hidden="true">
            <IconoCuenta size={24} />
          </span>
          <span className="accion-titulo">CUENTA</span>
          <span className="accion-subtitulo">Licencia y vehículo</span>
        </button>
      </section>

      <footer className="inicio-pie">
        <Link to="/mapa" className="enlace-mapa">
          <IconoRuta size={17} aria-hidden="true" />
          Mapa de servicios, grúas y tráfico simulado
        </Link>
        <p>Alertas simuladas · Sin llamadas reales · Chihuahua, Chih.</p>
      </footer>

      {emergenciaAbierta ? (
        <EmergenciaOverlay
          usuario={usuario}
          onCerrar={cerrarEmergencia}
          onEnviado={alEnviarEmergencia}
        />
      ) : null}
    </main>
  );
}
