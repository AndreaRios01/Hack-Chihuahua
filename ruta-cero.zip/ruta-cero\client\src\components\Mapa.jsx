import { useEffect, useRef } from 'react';
import L from 'leaflet';

const LETRAS = { grua: 'G', transito: 'T', ambulancia: 'A' };
const NOMBRES = { grua: 'Grúa', transito: 'Tránsito', ambulancia: 'Ambulancia' };
const CENTRO = [28.6353, -106.0889];

const escapar = (texto = '') =>
  String(texto).replace(
    /[&<>"']/g,
    (caracter) =>
      ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[caracter]
  );

/**
 * Mapa Leaflet + OpenStreetMap (sin API key).
 * Recibe la ubicación, servicios y (opcionalmente) corredores de tráfico simulados.
 */
export default function Mapa({
  usuario,
  servicios = [],
  trafico = [],
  conexiones = false,
  alto = 300,
  zoom = 13,
  ajustar = true,
  etiqueta = 'Mapa de ubicación y servicios cercanos'
}) {
  const contenedorRef = useRef(null);
  const mapaRef = useRef(null);
  const capaRef = useRef(null);

  useEffect(() => {
    if (!contenedorRef.current || mapaRef.current) return undefined;

    const centro = usuario
      ? [Number(usuario.lat), Number(usuario.lng)]
      : CENTRO;

    const mapa = L.map(contenedorRef.current, {
      zoomControl: true,
      scrollWheelZoom: false,
      attributionControl: true
    }).setView(centro, zoom);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(mapa);

    capaRef.current = L.layerGroup().addTo(mapa);
    mapaRef.current = mapa;

    const temporizador = setTimeout(() => mapa.invalidateSize(), 120);

    return () => {
      clearTimeout(temporizador);
      mapa.remove();
      mapaRef.current = null;
      capaRef.current = null;
    };
    // El mapa se inicializa una vez; las capas se actualizan en el efecto siguiente.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const mapa = mapaRef.current;
    const capa = capaRef.current;
    if (!mapa || !capa) return;

    capa.clearLayers();
    const puntos = [];

    // Corredores de tráfico simulados
    for (const corredor of trafico) {
      const lat = Number(corredor.latitud);
      const lng = Number(corredor.longitud);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;

      L.circleMarker([lat, lng], {
        radius: 13,
        color: corredor.color || '#FFC300',
        weight: 2,
        fillColor: corredor.color || '#FFC300',
        fillOpacity: 0.22
      })
        .bindTooltip(
          `${escapar(corredor.nombre)} · ${escapar(corredor.nivel)} (${corredor.porcentaje}%)`,
          { direction: 'top', offset: [0, -10] }
        )
        .addTo(capa);
    }

    // Conexiones desde el usuario a los servicios (referencia visual de ruta)
    if (conexiones && usuario) {
      for (const servicio of servicios) {
        L.polyline(
          [
            [Number(usuario.lat), Number(usuario.lng)],
            [Number(servicio.latitud), Number(servicio.longitud)]
          ],
          {
            color: '#9DB4CE',
            weight: 2,
            opacity: 0.75,
            dashArray: '4 7'
          }
        ).addTo(capa);
      }
    }

    // Servicios: grúa, tránsito y ambulancias
    for (const servicio of servicios) {
      const lat = Number(servicio.latitud);
      const lng = Number(servicio.longitud);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;

      const tipo = LETRAS[servicio.tipo] ? servicio.tipo : 'grua';
      const icono = L.divIcon({
        className: 'pin-contenedor',
        html: `<div class="pin pin-${tipo}" aria-hidden="true">${LETRAS[tipo]}</div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      const detalle = [
        `<strong>${escapar(servicio.nombre)}</strong>`,
        NOMBRES[tipo],
        servicio.distancia_texto ? `a ${escapar(servicio.distancia_texto)}` : '',
        servicio.eta_min ? `≈ ${servicio.eta_min} min` : ''
      ]
        .filter(Boolean)
        .join(' · ');

      L.marker([lat, lng], { icon: icono, title: servicio.nombre })
        .bindTooltip(detalle, { direction: 'top', offset: [0, -14] })
        .addTo(capa);

      puntos.push([lat, lng]);
    }

    // Ubicación del conductor
    if (usuario && Number.isFinite(Number(usuario.lat))) {
      const lat = Number(usuario.lat);
      const lng = Number(usuario.lng);
      const icono = L.divIcon({
        className: 'pin-contenedor',
        html: '<div class="pin pin-usuario" aria-hidden="true"><span></span></div>',
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      L.marker([lat, lng], { icon: icono, title: 'Tu ubicación' })
        .bindTooltip('Tu ubicación', { direction: 'top', offset: [0, -14] })
        .addTo(capa);

      if (Number.isFinite(Number(usuario.precision)) && usuario.precision > 40) {
        L.circle([lat, lng], {
          radius: Number(usuario.precision),
          color: '#8FA6C4',
          fillColor: '#8FA6C4',
          fillOpacity: 0.08,
          weight: 1
        }).addTo(capa);
      }

      puntos.unshift([lat, lng]);
    }

    if (ajustar && puntos.length > 1) {
      mapa.fitBounds(L.latLngBounds(puntos), {
        padding: [42, 42],
        maxZoom: 14
      });
    } else if (puntos.length === 1) {
      mapa.setView(puntos[0], zoom);
    }

    mapa.invalidateSize();
  }, [usuario, servicios, trafico, conexiones, ajustar, zoom]);

  return (
    <div className="mapa-bloque">
      <div
        className="mapa"
        style={{ height: `${alto}px` }}
        ref={contenedorRef}
        role="region"
        aria-label={etiqueta}
      />
      <div className="mapa-leyenda" aria-hidden="true">
        <span>
          <i className="punto punto-usuario" /> Tú
        </span>
        <span>
          <i className="punto punto-grua" /> Grúa
        </span>
        <span>
          <i className="punto punto-transito" /> Tránsito
        </span>
        <span>
          <i className="punto punto-ambulancia" /> Ambulancia
        </span>
      </div>
      <p className="mapa-credito">
        Mapa: OpenStreetMap · Sin llave de API. Si no hay internet, las calles
        pueden no cargar y los marcadores seguirán visibles.
      </p>
    </div>
  );
}
