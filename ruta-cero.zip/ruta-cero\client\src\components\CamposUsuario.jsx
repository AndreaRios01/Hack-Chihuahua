import Campo from './Campo.jsx';
import {
  normalizarLicencia,
  normalizarPlacas,
  soloDigitos
} from '../lib/validaciones.js';

export default function CamposUsuario({ datos, errores, onChange }) {
  const actualizarTelefono = (campo) => (valor) =>
    onChange(campo, soloDigitos(valor, 10));

  return (
    <>
      <section className="grupo-formulario" aria-labelledby="grupo-tus-datos">
        <div className="grupo-cabecera">
          <span className="grupo-numero" aria-hidden="true">
            1
          </span>
          <div>
            <h2 id="grupo-tus-datos">Tus datos</h2>
            <p>Así te reconoceremos en tu cuenta.</p>
          </div>
        </div>

        <Campo
          id="nombre"
          label="Nombre completo"
          valor={datos.nombre}
          onChange={(valor) => onChange('nombre', valor)}
          error={errores.nombre}
          placeholder="Ana Sofía Ramos"
          autoComplete="name"
          maxLength={80}
        />

        <Campo
          id="telefono"
          label="Tu teléfono"
          valor={datos.telefono}
          onChange={actualizarTelefono('telefono')}
          error={errores.telefono}
          placeholder="614 123 4567"
          inputMode="numeric"
          autoComplete="tel-national"
          prefijo="+52"
          maxLength={10}
          ayuda="10 dígitos. Con este número entras a tu cuenta, sin contraseña."
        />
      </section>

      <section className="grupo-formulario" aria-labelledby="grupo-contacto">
        <div className="grupo-cabecera">
          <span className="grupo-numero" aria-hidden="true">
            2
          </span>
          <div>
            <h2 id="grupo-contacto">Contacto de emergencia</h2>
            <p>La persona a la que avisaremos primero.</p>
          </div>
        </div>

        <Campo
          id="contacto_emergencia_nombre"
          label="Nombre del contacto"
          valor={datos.contacto_emergencia_nombre}
          onChange={(valor) => onChange('contacto_emergencia_nombre', valor)}
          error={errores.contacto_emergencia_nombre}
          placeholder="Luis Ramos"
          autoComplete="name"
          maxLength={80}
        />

        <Campo
          id="contacto_emergencia_telefono"
          label="Teléfono del contacto"
          valor={datos.contacto_emergencia_telefono}
          onChange={actualizarTelefono('contacto_emergencia_telefono')}
          error={errores.contacto_emergencia_telefono}
          placeholder="614 987 6543"
          inputMode="numeric"
          autoComplete="tel-national"
          prefijo="+52"
          maxLength={10}
        />
      </section>

      <section className="grupo-formulario" aria-labelledby="grupo-vehiculo">
        <div className="grupo-cabecera">
          <span className="grupo-numero" aria-hidden="true">
            3
          </span>
          <div>
            <h2 id="grupo-vehiculo">Tu vehículo</h2>
            <p>Datos ficticios para la licencia de demostración.</p>
          </div>
        </div>

        <Campo
          id="modelo_vehiculo"
          label="Marca y modelo"
          valor={datos.modelo_vehiculo}
          onChange={(valor) => onChange('modelo_vehiculo', valor)}
          error={errores.modelo_vehiculo}
          placeholder="Nissan Versa 2021"
          autoComplete="off"
          maxLength={80}
        />

        <div className="fila-campos">
          <Campo
            id="placas"
            label="Placas"
            valor={datos.placas}
            onChange={(valor) => onChange('placas', normalizarPlacas(valor))}
            error={errores.placas}
            placeholder="RCD-1201"
            autoComplete="off"
            maxLength={12}
            ayuda="4 a 12 caracteres."
          />

          <Campo
            id="licencia"
            label="Número de licencia"
            valor={datos.licencia}
            onChange={(valor) => onChange('licencia', normalizarLicencia(valor))}
            error={errores.licencia}
            placeholder="CHIH-DEMO-001"
            autoComplete="off"
            maxLength={24}
          />
        </div>
      </section>
    </>
  );
}
