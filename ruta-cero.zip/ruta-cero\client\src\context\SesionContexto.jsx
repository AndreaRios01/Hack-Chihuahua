import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import {
  borrarSesion,
  guardarSesion,
  leerSesion
} from '../lib/sesion.js';

const Contexto = createContext(null);

export function SesionProvider({ children }) {
  const [usuario, setUsuario] = useState(() => leerSesion());

  const iniciarSesion = useCallback((nuevoUsuario) => {
    guardarSesion(nuevoUsuario);
    setUsuario(nuevoUsuario);
  }, []);

  const actualizarSesion = useCallback((nuevoUsuario) => {
    guardarSesion(nuevoUsuario);
    setUsuario(nuevoUsuario);
  }, []);

  const cerrarSesion = useCallback(() => {
    borrarSesion();
    setUsuario(null);
  }, []);

  const valor = useMemo(
    () => ({
      usuario,
      autenticado: Boolean(usuario),
      iniciarSesion,
      actualizarSesion,
      cerrarSesion
    }),
    [usuario, iniciarSesion, actualizarSesion, cerrarSesion]
  );

  return <Contexto.Provider value={valor}>{children}</Contexto.Provider>;
}

export function useSesion() {
  const contexto = useContext(Contexto);
  if (!contexto) {
    throw new Error('useSesion debe usarse dentro de <SesionProvider>.');
  }
  return contexto;
}
