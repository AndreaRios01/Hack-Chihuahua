import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useSesion } from '../context/SesionContexto.jsx';
import {
  CAMPOS_INICIALES,
  mapearErroresServidor,
  soloDigitos,
  validarFormulario
} from '../lib/validaciones.js';
import Campo from '../components/Campo.jsx';
import CamposUsuario from '../components/CamposUsuario.jsx';
import Logo from '../components/Logo.jsx';
import Aviso from '../components/Aviso.jsx';
import {
  IconoAlerta,
  IconoEscudo,
  IconoRuta,
  IconoBateria
} from '../components/Iconos.jsx';

export default function Registro() {
  const navigate = useNavigate();
  const location = useLocation();
  const { iniciarSesion } = useSesion();

  const [modo, setModo] = useState('registro');
  const [datos, setDatos] = useState(CAMPOS_INICIALES);
  const [telefonoLogin, setTelefonoLogin] = useState('');
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState(null);
  const [enviando, setEnviando] = useState(false);
  const [aviso, setAviso] = useState(location.state?.aviso || null);

  useEffect(() => {
    document.title = 'Acceso · RUTA CERO';
  }, []);

  const titulo = useMemo(
    () => (modo === 'registro' ? 'Crea tu cuenta' : 'Entra a tu cuenta'),
    [modo]
  );

  const cambiarModo = (nuevoModo) => {
    setModo(nuevoModo);
    setErrores({});
    setErrorGeneral(null);
  };

  const cambiarCampo = (campo, valor) => {
    setDatos((previos) => ({ ...previos, [campo]: valor }));
    if (errores[campo]) {
      setErrores((previos) => {
        const copia = { ...previos };
        delete copia[campo];
        return copia;
      });
    }
  };

  const entrar = (usuario, mensaje) => {
    iniciarSesion(usuario);
    navigate('/inicio', {
      replace: true,
      state: { bienvenida: mensaje }
    });
  };

  const alRegistrarme = async (evento) => {
    evento.preventDefault();
    setErrorGeneral(null);

    const validacion = validarFormulario(datos);
    if (!validacion.valido) {
      setErrores(validacion.errores);
      setErrorGeneral('Revisa los campos marcados en rojo.');
      return;
    }

    setEnviando(true);
    try {
      const respuesta = await api.registro(datos);
      entrar(respuesta.usuario, respuesta.mensaje);
    } catch (fallo) {
      if (fallo.detalles?.length) {
        setErrores(mapearErroresServidor(fallo.detalles));
      }
      setErrorGeneral(fallo.message);
    } finally {
      setEnviando(false);
    }
  };

  const alEntrar = async (evento) => {
    evento?.preventDefault();
    setErrorGeneral(null);

    if (!/^\d{10}$/.test(telefonoLogin)) {
      setErrorGeneral('Escribe tu teléfono de 10 dígitos para entrar.');
      return;
    }

    setEnviando(true);
    try {
      const respuesta = await api.login(telefonoLogin);
      entrar(respuesta.usuario, respuesta.mensaje);
    } catch (fallo) {
      setErrorGeneral(fallo.message);
    } finally {
      setEnviando(false);
    }
  };

  const entrarConDemo = async () => {
    setTelefonoLogin('6141234567');
    setErrorGeneral(null);
    setEnviando(true);
    try {
      const respuesta = await api.login('6141234567');
      entrar(respuesta.usuario, 'Cuenta demo: Ana Sofía Ramos.');
    } catch (fallo) {
      setErrorGeneral(
        `${fallo.message} Si es la primera vez, ejecuta «npm run seed» y vuelve a intentar.`
      );
    } finally {
      setEnviando(false);
    }
  };

  return (
    <main className="pantalla pantalla-auth">
      <div className="auth-fondo" aria-hidden="true" />

      <header className="auth-hero">
        <Logo tamano={62} eslogan />
        <h1 className="auth-titular">
          Llega a <span>cero</span> incidentes.
        </h1>
        <p className="auth-lema">
          Movilidad inteligente y ayuda inmediata en un solo lugar.
        </p>

        <ul className="auth-beneficios" aria-label="Beneficios de RUTA CERO">
          <li>
            <IconoAlerta size={17} aria-hidden="true" /> Emergencia en 3 s
          </li>
          <li>
            <IconoRuta size={17} aria-hidden="true" /> Servicios cercanos
          </li>
          <li>
            <IconoEscudo size={17} aria-hidden="true" /> Contacto avisado
          </li>
          <li>
            <IconoBateria size={17} aria-hidden="true" /> Sin API keys
          </li>
        </ul>
      </header>

      <section className="auth-tarjeta" aria-labelledby="titulo-formulario">
        <div className="pestanas" role="tablist" aria-label="Acceso a RUTA CERO">
          <button
            type="button"
            role="tab"
            aria-selected={modo === 'registro'}
            className={`pestana ${modo === 'registro' ? 'pestana-activa' : ''}`.trim()}
            onClick={() => cambiarModo('registro')}
          >
            Crear cuenta
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={modo === 'login'}
            className={`pestana ${modo === 'login' ? 'pestana-activa' : ''}`.trim()}
            onClick={() => cambiarModo('login')}
          >
            Ya tengo cuenta
          </button>
        </div>

        <div className="auth-cabecera">
          <h2 id="titulo-formulario">{titulo}</h2>
          <p>
            {modo === 'registro'
              ? 'Solo una vez. Después entras con tu teléfono, sin contraseña.'
              : 'Escribe el teléfono con el que te registraste.'}
          </p>
        </div>

        {aviso ? (
          <Aviso tipo="exito" onCerrar={() => setAviso(null)}>
            {aviso}
          </Aviso>
        ) : null}

        {errorGeneral ? (
          <Aviso tipo="error" onCerrar={() => setErrorGeneral(null)}>
            {errorGeneral}
          </Aviso>
        ) : null}

        {modo === 'registro' ? (
          <form className="formulario" onSubmit={alRegistrarme} noValidate>
            <CamposUsuario
              datos={datos}
              errores={errores}
              onChange={cambiarCampo}
            />

            <p className="nota-demo">
              Demo sin contraseña. Tus datos se guardan en una base SQLite local
              y no se envían a servicios externos.
            </p>

            <button
              type="submit"
              className="boton boton-amarillo boton-grande boton-ancho"
              disabled={enviando}
            >
              {enviando ? (
                <>
                  <span className="girador girador-boton" aria-hidden="true" />
                  CREANDO CUENTA…
                </>
              ) : (
                'CREAR MI CUENTA'
              )}
            </button>

            <p className="auth-pie">
              ¿Ya tienes cuenta?{' '}
              <button
                type="button"
                className="enlace-texto"
                onClick={() => cambiarModo('login')}
              >
                Entra con tu teléfono
              </button>
            </p>
          </form>
        ) : (
          <form className="formulario" onSubmit={alEntrar} noValidate>
            <Campo
              id="telefono-login"
              label="Teléfono"
              valor={telefonoLogin}
              onChange={(valor) => setTelefonoLogin(soloDigitos(valor, 10))}
              placeholder="614 123 4567"
              inputMode="numeric"
              autoComplete="tel-national"
              prefijo="+52"
              maxLength={10}
              ayuda="Sin contraseña: es una demo. Si el teléfono no existe, regístrate."
            />

            <button
              type="submit"
              className="boton boton-verde boton-grande boton-ancho"
              disabled={enviando}
            >
              {enviando ? (
                <>
                  <span className="girador girador-boton" aria-hidden="true" />
                  ENTRANDO…
                </>
              ) : (
                'ENTRAR A MI CUENTA'
              )}
            </button>

            <div className="separador" aria-hidden="true">
              <span>o prueba la demo</span>
            </div>

            <button
              type="button"
              className="boton boton-secundario boton-ancho"
              onClick={entrarConDemo}
              disabled={enviando}
            >
              USAR CUENTA DEMO · ANA SOFÍA
            </button>
            <p className="auth-pie auth-pie-centrado">
              Teléfono demo: 614 123 4567 · requiere «npm run seed».
            </p>
          </form>
        )}
      </section>

      <footer className="auth-footer">
        <IconoEscudo size={15} aria-hidden="true" /> Prototipo de hackatón ·
        Servicios y alertas simulados · Chihuahua, México
      </footer>
    </main>
  );
}
