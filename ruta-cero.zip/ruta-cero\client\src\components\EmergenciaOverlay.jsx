import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { api } from '../lib/api.js';
import { obtenerUbicacion } from '../lib/ubicacion.js';
import { vibrar } from '../lib/formato.js';
import Aviso from './Aviso.jsx';
import {
  IconoAlerta,
  IconoEscudo,
  IconoGrua,
  IconoTelefono,
  IconoTransito,
  IconoX
} from './Iconos.jsx';

const CIRCUNFERENCIA = 2 * Math.PI * 46;

/**
 * Confirmación de 3 segundos con cancelación. Si no se cancela, envía la
 * emergencia y obtiene la ubicación en paralelo para ahorrar tiempo.
 */
export default function EmergenciaOverlay({ usuario, onCerrar, onEnviado }) {
  const [restante, setRestante] = useState(3);
  const [fase, setFase] = useState('contando');
  const [ubicacion, setUbicacion] = useState(null);
  const [error, setError] = useState(null);

  const canceladoRef = useRef(false);
  const enviandoRef = useRef(false);
  const ubicacionRef = useRef(null);
  const promesaUbicacionRef = useRef(null);
  const enviarRef = useRef(null);
  const botonCancelarRef = useRef(null);

  const enviar = useCallback(async () => {
    if (enviandoRef.current) return;
    enviandoRef.current = true;
    setFase('enviando');
    setError(null);

    try {
      const ubi =
        ubicacionRef.current ||
        (await (promesaUbicacionRef.current || obtenerUbicacion()));

      ubicacionRef.current = ubi;
      if (!canceladoRef.current) setUbicacion(ubi);

      const datos = await api.emergencia({
        usuario_id: usuario.id,
        latitud: ubi.lat,
        longitud: ubi.lng,
        precision: ubi.precision,
        aproximada: ubi.aproximada
      });

      vibrar([500, 150, 500, 150, 800]);

      if (!canceladoRef.current) onEnviado(datos);
    } catch (fallo) {
      if (canceladoRef.current) return;
      enviandoRef.current = false;
      setError(fallo);
      setFase('error');
    }
  }, [usuario.id, onEnviado]);

  enviarRef.current = enviar;

  const cancelar = useCallback(() => {
    canceladoRef.current = true;
    onCerrar();
  }, [onCerrar]);

  useEffect(() => {
    canceladoRef.current = false;
    const overflowPrevio = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    vibrar([300, 120, 300, 120, 600]);

    promesaUbicacionRef.current = obtenerUbicacion().then((ubi) => {
      ubicacionRef.current = ubi;
      if (!canceladoRef.current) setUbicacion(ubi);
      return ubi;
    });

    let segundos = 3;
    const intervalo = setInterval(() => {
      segundos -= 1;
      if (segundos <= 0) {
        clearInterval(intervalo);
        setRestante(0);
        enviarRef.current?.();
      } else {
        setRestante(segundos);
      }
    }, 1000);

    const foco = requestAnimationFrame(() => {
      botonCancelarRef.current?.focus();
    });

    const alTeclear = (evento) => {
      if (evento.key === 'Escape' && !enviandoRef.current) cancelar();
    };
    document.addEventListener('keydown', alTeclear);

    return () => {
      canceladoRef.current = true;
      clearInterval(intervalo);
      cancelAnimationFrame(foco);
      document.removeEventListener('keydown', alTeclear);
      document.body.style.overflow = overflowPrevio;
    };
  }, [cancelar]);

  const porcentaje = Math.max(0, restante) / 3;
  const progreso = ubicacion
    ? ubicacion.aproximada
      ? 'Usaremos Chihuahua como ubicación de referencia.'
      : `Ubicación lista${ubicacion.precision ? ` · ±${ubicacion.precision} m` : ''}.`
    : 'Obteniendo tu ubicación…';

  return createPortal(
    <div className="emergencia-overlay">
      <div
        className="emergencia-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="titulo-emergencia"
      >
        <div className="emergencia-cabecera">
          <span className="emergencia-sirena" aria-hidden="true">
            <IconoAlerta size={30} />
          </span>
          <div>
            <p className="emergencia-kicker">Confirmación de seguridad</p>
            <h2 id="titulo-emergencia">EMERGENCIA</h2>
          </div>
          {fase === 'contando' ? (
            <button
              type="button"
              className="emergencia-cerrar"
              onClick={cancelar}
              aria-label="Cerrar y cancelar la emergencia"
            >
              <IconoX size={20} />
            </button>
          ) : null}
        </div>

        {fase === 'error' ? (
          <div className="emergencia-cuerpo">
            <Aviso
              tipo="error"
              titulo="No pudimos enviar la alerta"
              onCerrar={() => setError(null)}
            >
              {error?.message || 'Intenta de nuevo.'}
            </Aviso>
            <div className="emergencia-botones">
              <button
                type="button"
                className="boton boton-rojo boton-grande"
                onClick={() => {
                  enviandoRef.current = false;
                  enviar();
                }}
              >
                REINTENTAR
              </button>
              <button
                type="button"
                className="boton boton-secundario boton-grande"
                onClick={cancelar}
              >
                CERRAR
              </button>
            </div>
          </div>
        ) : (
          <div className="emergencia-cuerpo">
            {fase === 'enviando' ? (
              <div className="emergencia-enviando" role="status" aria-live="polite">
                <span className="girador girador-grande" aria-hidden="true" />
                <p className="emergencia-enviando-titulo">Enviando tu emergencia…</p>
                <p className="emergencia-enviando-texto">
                  Buscando la grúa y la delegación de tránsito más cercanas con
                  Haversine, y notificando a tu contacto.
                </p>
              </div>
            ) : (
              <>
                <div className="cuenta-regresiva">
                  <svg viewBox="0 0 100 100" aria-hidden="true">
                    <circle
                      className="anillo-fondo"
                      cx="50"
                      cy="50"
                      r="46"
                    />
                    <circle
                      className="anillo-progreso"
                      cx="50"
                      cy="50"
                      r="46"
                      style={{
                        strokeDasharray: CIRCUNFERENCIA,
                        strokeDashoffset:
                          CIRCUNFERENCIA * (1 - porcentaje)
                      }}
                    />
                  </svg>
                  <span
                    className="cuenta-numero"
                    role="timer"
                    aria-live="polite"
                    aria-label={`Enviando en ${restante} segundos`}
                  >
                    {restante}
                  </span>
                </div>

                <p className="emergencia-texto">
                  Enviaremos tu ubicación a estos servicios en{' '}
                  <strong>{restante} segundo{restante === 1 ? '' : 's'}</strong>.
                  Si fue una falsa alarma, cancela ahora.
                </p>

                <ul className="emergencia-destinos">
                  <li>
                    <IconoTelefono size={18} aria-hidden="true" />
                    <span>Contacto</span>
                    <strong>{usuario.contacto_emergencia_nombre}</strong>
                  </li>
                  <li>
                    <IconoGrua size={18} aria-hidden="true" />
                    <span>Grúa</span>
                    <strong>La más cercana</strong>
                  </li>
                  <li>
                    <IconoTransito size={18} aria-hidden="true" />
                    <span>Tránsito</span>
                    <strong>Delegación cercana</strong>
                  </li>
                </ul>

                <p
                  className={`emergencia-ubicacion ${ubicacion?.aproximada ? 'es-referencia' : ''}`.trim()}
                >
                  <IconoEscudo size={16} aria-hidden="true" />
                  {progreso}
                </p>

                <div className="emergencia-botones">
                  <button
                    type="button"
                    ref={botonCancelarRef}
                    className="boton boton-secundario boton-grande"
                    onClick={cancelar}
                    data-enfoque-inicial
                  >
                    CANCELAR
                  </button>
                  <button
                    type="button"
                    className="boton boton-rojo boton-grande"
                    onClick={() => {
                      if (enviandoRef.current) return;
                      enviar();
                    }}
                  >
                    ENVIAR AHORA
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        <p className="emergencia-nota">
          Esta demo no llama al 911. Si hay una emergencia real, usa tu teléfono.
        </p>
      </div>
    </div>,
    document.body
  );
}
