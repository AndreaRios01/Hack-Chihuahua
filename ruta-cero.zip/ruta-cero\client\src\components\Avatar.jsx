import { useId, useMemo } from 'react';

/**
 * Avatar vectorial "hecho a mano". No usa fotos ni servicios externos.
 * Los colores se derivan del nombre para que cada persona tenga su retrato.
 */

const PIELES = [
  ['#F2C9A8', '#D9A57F'],
  ['#C98F65', '#A96F4A'],
  ['#8D5A3B', '#6E4329'],
  ['#E8B58E', '#C8916A']
];

const CABELLOS = ['#2B211B', '#4A3024', '#1F2A38', '#5B3A24'];
const CAMISAS = ['#2E9E4F', '#1F5F8B', '#D62828', '#5A4B8B', '#B9791E'];
const FONDOS = [
  ['#FFC300', '#D69E00'],
  ['#2E9E4F', '#1C6E36'],
  ['#3D7EA6', '#24516B'],
  ['#D62828', '#941B1B']
];

function hashTexto(texto = '') {
  let hash = 0;
  for (let i = 0; i < texto.length; i += 1) {
    hash = (hash * 31 + texto.charCodeAt(i)) % 100000;
  }
  return hash;
}

export default function Avatar({
  nombre = 'Conductor',
  tamano = 76,
  className = ''
}) {
  const id = useId().replace(/[^a-zA-Z0-9]/g, '');
  const gradiente = `avatar-fondo-${id}`;
  const brillo = `avatar-brillo-${id}`;

  const paleta = useMemo(() => {
    const hash = hashTexto(nombre);
    return {
      piel: PIELES[hash % PIELES.length],
      cabello: CABELLOS[hash % CABELLOS.length],
      camisa: CAMISAS[(hash + 2) % CAMISAS.length],
      fondo: FONDOS[(hash + 1) % FONDOS.length]
    };
  }, [nombre]);

  const [piel, pielSombra] = paleta.piel;

  return (
    <svg
      width={tamano}
      height={tamano}
      viewBox="0 0 120 120"
      className={`avatar ${className}`.trim()}
      role="img"
      aria-label={`Avatar ilustrado de ${nombre}`}
      focusable="false"
    >
      <defs>
        <linearGradient id={gradiente} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={paleta.fondo[0]} />
          <stop offset="1" stopColor={paleta.fondo[1]} />
        </linearGradient>
        <radialGradient id={brillo} cx="0.3" cy="0.2" r="0.8">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.35" />
          <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
        </radialGradient>
      </defs>

      <rect width="120" height="120" rx="60" fill={`url(#${gradiente})`} />
      <rect width="120" height="120" rx="60" fill={`url(#${brillo})`} />
      <circle cx="60" cy="60" r="51" fill="none" stroke="#FFFFFF" strokeOpacity="0.22" strokeWidth="2" />
      <path d="M10 92c18-7 32-2 40 7M110 30c-14 2-25 11-29 22" stroke="#FFFFFF" strokeOpacity="0.18" strokeWidth="2" fill="none" />

      {/* Hombros y cuello */}
      <path
        d="M15 120c2-23 19-34 45-34s43 11 45 34Z"
        fill={paleta.camisa}
      />
      <path
        d="M49 80h22v14c0 8-22 8-22 0Z"
        fill={pielSombra}
      />
      <path
        d="M48 94c3 5 8 8 12 8s9-3 12-8l-3-2-9 4-9-4Z"
        fill="#FFFFFF"
        fillOpacity="0.9"
      />
      <path
        d="M57 97c2 4 4 6 5 9 3-4 5-8 3-11Z"
        fill={paleta.camisa}
      />

      {/* Orejas y rostro */}
      <ellipse cx="33" cy="57" rx="6" ry="8" fill={pielSombra} />
      <ellipse cx="87" cy="57" rx="6" ry="8" fill={pielSombra} />
      <ellipse cx="60" cy="54" rx="27" ry="30" fill={piel} />

      {/* Cabello */}
      <path
        d="M32 52c-2-22 12-34 28-34 17 0 30 12 28 34-4-8-9-12-16-12-11 0-13 9-24 9-7 0-12 1-16 3Z"
        fill={paleta.cabello}
      />
      <path
        d="M34 48c-1 9 0 14 2 18-6-5-8-12-7-20Z"
        fill={paleta.cabello}
      />
      <path
        d="M86 48c1 9 0 14-2 18 6-5 8-12 7-20Z"
        fill={paleta.cabello}
      />

      {/* Cejas, ojos, nariz y sonrisa */}
      <path d="M45 48c3-2 7-2 10 0M65 48c3-2 7-2 10 0" stroke="#3A2A22" strokeWidth="2.2" strokeLinecap="round" />
      <ellipse cx="50" cy="55" rx="2.6" ry="3.2" fill="#231A16" />
      <ellipse cx="70" cy="55" rx="2.6" ry="3.2" fill="#231A16" />
      <circle cx="50.8" cy="54" r="0.9" fill="#FFFFFF" />
      <circle cx="70.8" cy="54" r="0.9" fill="#FFFFFF" />
      <path d="M60 57v7c0 2-2 3-4 3" stroke={pielSombra} strokeWidth="2" strokeLinecap="round" fill="none" />
      <path d="M51 70c5 5 13 5 18 0" stroke="#8A3B36" strokeWidth="2.6" strokeLinecap="round" fill="none" />
      <ellipse cx="43" cy="64" rx="4.5" ry="2.4" fill="#E78A82" fillOpacity="0.35" />
      <ellipse cx="77" cy="64" rx="4.5" ry="2.4" fill="#E78A82" fillOpacity="0.35" />
    </svg>
  );
}
