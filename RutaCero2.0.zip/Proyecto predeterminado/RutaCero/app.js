(function () {
    'use strict';

    /* ========================================================================
       0. CONFIGURACIÓN ("lectura simulada de .env")
       En una app real Vite inyectaría estas variables. Aquí se leen desde:
       1) window.RUTACERO_ENV (bloque <script> previo), 2) query string ?VITE_...,
       3) localStorage, y finalmente 4) los valores por defecto de este objeto.
       Ninguna llave es necesaria para que la demo funcione offline.
       ======================================================================== */
    const ENV_CONFIG = {
      VITE_GEMINI_API_KEY: '',
      VITE_EMERGENCY_PHONE: '911',
      VITE_APP_CITY: 'Torreón, Coahuila',
      VITE_GPS_DEFAULT_LAT: 25.6506,
      VITE_GPS_DEFAULT_LNG: -103.3719,
      VITE_SIMULATE_NOTIFICATIONS: true,
      VITE_SOUND_ENABLED: true
    };

    const DB_KEY = 'rutacero.db.v1';
    const ENV_KEY = 'rutacero.env.v1';
    const memoria = {}; // Respaldos si el navegador bloquea localStorage (file:// estricto).

    function lee(clave) {
      try { return localStorage.getItem(clave); } catch (e) { return memoria[clave] || null; }
    }
    function escribe(clave, valor) {
      try { localStorage.setItem(clave, valor); } catch (e) { memoria[clave] = valor; }
    }
    function borra(clave) {
      try { localStorage.removeItem(clave); } catch (e) { delete memoria[clave]; }
    }

    function aplicarEnv() {
      const fuentes = [];
      if (window.RUTACERO_ENV && typeof window.RUTACERO_ENV === 'object') fuentes.push(window.RUTACERO_ENV);
      try {
        const guardado = JSON.parse(lee(ENV_KEY) || '{}');
        fuentes.push(guardado);
      } catch (e) { /* configuración inválida: se ignora */ }
      const params = new URLSearchParams(location.search);
      const desdeUrl = {};
      params.forEach((valor, clave) => { if (clave.indexOf('VITE_') === 0) desdeUrl[clave] = valor; });
      fuentes.push(desdeUrl);

      fuentes.forEach((fuente) => {
        Object.keys(ENV_CONFIG).forEach((clave) => {
          if (fuente[clave] !== undefined && fuente[clave] !== '') ENV_CONFIG[clave] = fuente[clave];
        });
      });
      ENV_CONFIG.VITE_SIMULATE_NOTIFICATIONS = ENV_CONFIG.VITE_SIMULATE_NOTIFICATIONS !== false;
    }
    aplicarEnv();

    /* ========================================================================
       1. DATOS PRECARGADOS (catálogo local, sin servidor)
       ======================================================================== */
    const GRUAS = [
      { id: 'g1', nombre: 'Grúas Laguna Express', eta: 6, telefono: '871 000 0001', lat: 25.6490, lng: -103.3550, zona: 'Sur' },
      { id: 'g2', nombre: 'Asistencia Vial Centro', eta: 9, telefono: '871 000 0002', lat: 25.6710, lng: -103.3400, zona: 'Centro' },
      { id: 'g3', nombre: 'Grúas Ruta Norte', eta: 12, telefono: '871 000 0003', lat: 25.7050, lng: -103.3250, zona: 'Norte' }
    ];

    const CALLES = [
      { nombre: 'Blvd. Independencia', a: [0, 180], b: [800, 180] },
      { nombre: 'Av. Revolución', a: [300, 0], b: [300, 560] },
      { nombre: 'Periférico Raúl López Sánchez', a: [0, 430], b: [420, 460] },
      { nombre: 'Periférico Raúl López Sánchez', a: [420, 460], b: [800, 410] },
      { nombre: 'Av. Juárez', a: [0, 330], b: [800, 330] },
      { nombre: 'Av. Cuauhtémoc', a: [560, 0], b: [560, 560] },
      { nombre: 'Blvd. Diagonal', a: [60, 520], b: [740, 80] }
    ];

    const LIMITES = { norte: 25.74, sur: 25.63, oeste: -103.39, este: -103.29 };
    const LUGAR_FALLBACK = { lat: 25.6506, lng: -103.3719, aproximada: true, motivo: 'GPS no disponible: usamos una referencia en el sur de Torreón.' };

    const TIPOS_REPORTE = {
      bache: { titulo: 'Bache profundo', severidad: 'media', icono: '▲', descripcion: 'Bache reportado por la comunidad. Reduce la velocidad.' },
      inundacion: { titulo: 'Inundación en la vía', severidad: 'media', icono: '≈', descripcion: 'Acumulación de agua que dificulta el paso.' },
      choque: { titulo: 'Choque de tercero', severidad: 'alta', icono: '✕', descripcion: 'Colisión presenciada por un conductor de la red.' },
      obra: { titulo: 'Obra / bloqueo vial', severidad: 'media', icono: '⚒', descripcion: 'Obra o cierre parcial sin señalización suficiente.' }
    };

    function incidentesSemilla() {
      const ahora = Date.now();
      return [
        {
          id: 'inc-seed-choque', tipo: 'choque', titulo: 'Choque con dos vehículos',
          direccion: 'Blvd. Independencia y Av. Revolución', x: 300, y: 180,
          severidad: 'alta', origen: 'semilla', creadoEn: ahora - 4 * 60000,
          descripcion: 'Dos unidades bloquean el carril poniente. Tránsito desviado hacia Av. Juárez.',
          validaciones: { sigue: 3, libre: 0 }, estado: 'activo',
          esPropio: false, desviando: true
        },
        {
          id: 'inc-seed-bache', tipo: 'bache', titulo: 'Bache/obra en periférico',
          direccion: 'Periférico Raúl López Sánchez', x: 575, y: 452,
          severidad: 'media', origen: 'semilla', creadoEn: ahora - 11 * 60000,
          descripcion: 'Obra sin señalización; los conductores reportan baja visibilidad.',
          validaciones: { sigue: 2, libre: 1 }, estado: 'activo',
          esPropio: false, desviando: false
        }
      ];
    }

    /* ========================================================================
       2. PERSISTENCIA LOCAL
       ======================================================================== */
    function dbNueva() {
      return {
        version: 1, sesionActiva: false, usuario: null,
        incidentes: [], semillaCargada: false, alertas: [],
        ultimaUbicacion: null, preferencias: { sonido: true, vibracion: true }
      };
    }

    function guardar() { escribe(DB_KEY, JSON.stringify(DB)); }

    function cargarDB() {
      const crudo = lee(DB_KEY);
      if (!crudo) {
        const nueva = dbNueva();
        nueva.incidentes = incidentesSemilla();
        nueva.semillaCargada = true;
        return nueva;
      }
      try {
        const datos = JSON.parse(crudo);
        const base = dbNueva();
        Object.keys(base).forEach((clave) => {
          if (datos[clave] !== undefined) base[clave] = datos[clave];
        });
        if (!Array.isArray(base.incidentes)) base.incidentes = [];
        if (!Array.isArray(base.alertas)) base.alertas = [];
        if (!base.semillaCargada) {
          base.incidentes = incidentesSemilla().concat(base.incidentes);
          base.semillaCargada = true;
        }
        // Migración de registros guardados con la versión anterior del demo.
        base.incidentes.forEach(function (inc) {
          if (inc.desviando === undefined) inc.desviando = inc.severidad === 'alta';
          if (inc.esPropio === undefined) {
            inc.esPropio = inc.origen === 'emergencia' ||
              (inc.origen === 'choque' && !/tercero/i.test(inc.titulo || ''));
          }
        });
        return base;
      } catch (e) {
        const nueva = dbNueva();
        nueva.incidentes = incidentesSemilla();
        nueva.semillaCargada = true;
        return nueva;
      }
    }

    let DB = cargarDB();
    guardar();

    /* ========================================================================
       3. UTILIDADES
       ======================================================================== */
    const $ = (selector) => document.querySelector(selector);
    const $$ = (selector) => Array.prototype.slice.call(document.querySelectorAll(selector));
    const clamp = (valor, min, max) => Math.min(max, Math.max(min, valor));
    const esc = (valor) => String(valor == null ? '' : valor).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const normalizar = (valor) => String(valor || '').replace(/\s+/g, ' ').trim();
    const digitos = (valor) => String(valor || '').replace(/\D/g, '');
    const formatoTel = (valor) => {
      const d = digitos(valor);
      if (d.length !== 10) return String(valor || '');
      return d.slice(0, 3) + ' ' + d.slice(3, 6) + ' ' + d.slice(6);
    };
    const hace = (timestamp) => {
      const min = Math.max(0, Math.floor((Date.now() - timestamp) / 60000));
      if (min < 1) return 'ahora mismo';
      if (min === 1) return 'hace 1 min';
      if (min < 60) return 'hace ' + min + ' min';
      return 'hace ' + Math.floor(min / 60) + ' h';
    };

    function anunciar(mensaje) {
      const region = $('#anuncios');
      if (!region) return;
      region.textContent = '';
      window.setTimeout(function () { region.textContent = mensaje; }, 30);
    }

    let timerToast;
    function mostrarToast(mensaje, color) {
      const el = $('#toast');
      el.textContent = mensaje;
      el.style.borderLeftColor = color || 'var(--verde)';
      el.hidden = false;
      window.clearTimeout(timerToast);
      timerToast = window.setTimeout(function () { el.hidden = true; }, 3900);
    }

    let audioCtx = null;
    function pitido(frecuencia, duracion, volumen) {
      if (!ENV_CONFIG.VITE_SOUND_ENABLED || DB.preferencias.sonido === false) return;
      try {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        audioCtx = audioCtx || new Ctx();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const ganancia = audioCtx.createGain();
        const t = audioCtx.currentTime;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(frecuencia || 880, t);
        ganancia.gain.setValueAtTime(0.0001, t);
        ganancia.gain.exponentialRampToValueAtTime(volumen || 0.07, t + 0.02);
        ganancia.gain.exponentialRampToValueAtTime(0.0001, t + (duracion || 0.13));
        osc.connect(ganancia);
        ganancia.connect(audioCtx.destination);
        osc.start(t);
        osc.stop(t + (duracion || 0.13) + 0.03);
      } catch (e) { /* Audio no disponible: la demo sigue funcionando */ }
    }

    function vibrar(patron) {
      if (DB.preferencias.vibracion === false) return;
      try { if (navigator.vibrate) navigator.vibrate(patron); } catch (e) { /* no soportado */ }
    }

    function distanciaKm(a, b) {
      const R = 6371;
      const dLat = (b.lat - a.lat) * Math.PI / 180;
      const dLng = (b.lng - a.lng) * Math.PI / 180;
      const la = a.lat * Math.PI / 180;
      const lb = b.lat * Math.PI / 180;
      const h = Math.sin(dLat / 2) ** 2 + Math.cos(la) * Math.cos(lb) * Math.sin(dLng / 2) ** 2;
      return 2 * R * Math.asin(Math.sqrt(h));
    }

    function gruaMasCercana(punto) {
      const origen = punto || LUGAR_FALLBACK;
      return GRUAS.map(function (g) {
        return Object.assign({}, g, { distanciaKm: distanciaKm(origen, g), distanciaTexto: distanciaKm(origen, g).toFixed(1) + ' km' });
      }).sort(function (a, b) { return a.distanciaKm - b.distanciaKm; })[0];
    }

    function geoAMapa(punto) {
      const lat = clamp(Number(punto.lat), LIMITES.sur, LIMITES.norte);
      const lng = clamp(Number(punto.lng), LIMITES.oeste, LIMITES.este);
      return {
        x: Math.round(40 + ((lng - LIMITES.oeste) / (LIMITES.este - LIMITES.oeste)) * 720),
        y: Math.round(520 - ((lat - LIMITES.sur) / (LIMITES.norte - LIMITES.sur)) * 480)
      };
    }

    function mapaAGeo(x, y) {
      return {
        lat: Number((LIMITES.sur + ((520 - y) / 480) * (LIMITES.norte - LIMITES.sur)).toFixed(5)),
        lng: Number((LIMITES.oeste + ((x - 40) / 720) * (LIMITES.este - LIMITES.oeste)).toFixed(5)),
        aproximada: false
      };
    }

    function distanciaASegmento(p, a, b) {
      const dx = b[0] - a[0], dy = b[1] - a[1];
      const largo = dx * dx + dy * dy;
      const t = largo === 0 ? 0 : clamp(((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / largo, 0, 1);
      const px = a[0] + t * dx, py = a[1] + t * dy;
      return Math.hypot(p[0] - px, p[1] - py);
    }

    function calleCercana(x, y) {
      let mejor = CALLES[0].nombre, menor = Infinity;
      CALLES.forEach(function (calle) {
        const d = distanciaASegmento([x, y], calle.a, calle.b);
        if (d < menor) { menor = d; mejor = calle.nombre; }
      });
      return mejor;
    }

    function obtenerUbicacion() {
      return new Promise(function (resolver) {
        if (!navigator.geolocation) { resolver(LUGAR_FALLBACK); return; }
        let terminado = false;
        const finalizar = (valor) => { if (!terminado) { terminado = true; resolver(valor); } };
        const temporizador = window.setTimeout(function () { finalizar(LUGAR_FALLBACK); }, 5500);
        navigator.geolocation.getCurrentPosition(function (pos) {
          window.clearTimeout(temporizador);
          finalizar({
            lat: Number(pos.coords.latitude.toFixed(6)),
            lng: Number(pos.coords.longitude.toFixed(6)),
            precision: Math.round(pos.coords.accuracy || 0),
            aproximada: false
          });
        }, function () {
          window.clearTimeout(temporizador);
          finalizar(LUGAR_FALLBACK);
        }, { enableHighAccuracy: true, timeout: 5000, maximumAge: 60000 });
      });
    }

    /* ========================================================================
       4. RENDERIZADO
       ======================================================================== */
    const estado = {
      recalcando: false, temporizadorRecalculo: null,
      incidenteAbierto: null, ubicacionReporte: null,
      idDespacho: null, cuentaAtras: null, ubicacionEmergencia: null
    };
    const NS = 'http://www.w3.org/2000/svg';
    const activos = () => DB.incidentes.filter(function (i) { return i.estado === 'activo'; });

    function renderCabecera() {
      if (!DB.usuario) return;
      const nombre = normalizar(DB.usuario.nombre);
      const iniciales = nombre.split(' ').filter(Boolean).slice(0, 2).map(function (p) { return p.charAt(0).toUpperCase(); }).join('');
      $('#avatarInicio').textContent = iniciales || 'RC';
      $('#saludoNombre').textContent = 'Hola, ' + (nombre.split(' ')[0] || 'conductor');
    }

    function renderRutasYEstado() {
      const lista = activos();
      // Solo los incidentes que siguen "desviando" tráfico activan la ruta alterna.
      const criticos = lista.filter(function (i) { return i.desviando === true; });
      $('#mapaContenedor').classList.toggle('con-desvio', criticos.length > 0);
      $('#contadorIncidentes').textContent = lista.length + (lista.length === 1 ? ' activo' : ' activos');
      $('#contadorIncidentes').className = 'chip ' + (lista.length ? 'chip-rojo' : 'chip-verde');

      const banner = $('#estadoRuta');
      let titulo, detalle, icono, clase;
      if (estado.recalcando) {
        titulo = 'Recalculando ruta…'; detalle = 'Evaluando el desvío con la red RutaCero'; icono = '⟳'; clase = 'modo-alerta';
      } else if (criticos.length > 0) {
        titulo = 'Tráfico desviado'; detalle = criticos.length + ' incidente(s) grave(s) · ruta alterna +8 min'; icono = '⚠'; clase = 'modo-alerta';
      } else if (lista.length > 0) {
        titulo = 'Ruta óptima activa'; detalle = 'Ahorrando 12 min · avisos leves en la vía'; icono = '✓'; clase = '';
      } else {
        titulo = 'Ruta óptima activa'; detalle = 'Ahorrando 12 min · vía libre en Torreón'; icono = '✓'; clase = '';
      }
      banner.className = 'estado-ruta ' + clase;
      $('#estadoTitulo').textContent = titulo;
      $('#estadoDetalle').textContent = detalle;
      $('#estadoIcono').textContent = icono;
    }

    function crearMarcador(inc) {
      const g = document.createElementNS(NS, 'g');
      g.setAttribute('class', 'marcador-incidente');
      g.setAttribute('transform', 'translate(' + inc.x + ' ' + inc.y + ')');
      g.setAttribute('tabindex', '0');
      g.setAttribute('role', 'button');
      g.setAttribute('aria-label', inc.titulo + ' en ' + inc.direccion + '. Toca para validar o cerrar.');

      const titulo = document.createElementNS(NS, 'title');
      titulo.textContent = inc.titulo + ' · ' + inc.direccion;
      g.appendChild(titulo);

      const pulso = document.createElementNS(NS, 'circle');
      pulso.setAttribute('r', '24');
      pulso.setAttribute('class', inc.severidad === 'alta' ? 'pulso-rojo' : 'pulso-ambar');
      g.appendChild(pulso);

      const forma = document.createElementNS(NS, inc.severidad === 'alta' ? 'circle' : 'polygon');
      forma.setAttribute('class', 'marcador-forma');
      forma.setAttribute('stroke', '#FFFFFF');
      forma.setAttribute('stroke-width', '3');
      if (inc.severidad === 'alta') {
        forma.setAttribute('r', '14');
        forma.setAttribute('fill', '#EF4444');
      } else {
        forma.setAttribute('points', '0,-18 18,14 -18,14');
        forma.setAttribute('fill', '#F59E0B');
      }
      g.appendChild(forma);

      const barra = document.createElementNS(NS, 'path');
      barra.setAttribute('d', 'M0 -8 V2');
      barra.setAttribute('stroke', '#FFFFFF');
      barra.setAttribute('stroke-width', '3.5');
      barra.setAttribute('stroke-linecap', 'round');
      g.appendChild(barra);
      const punto = document.createElementNS(NS, 'circle');
      punto.setAttribute('cy', '8'); punto.setAttribute('r', '2'); punto.setAttribute('fill', '#FFFFFF');
      g.appendChild(punto);

      g.addEventListener('click', function () { abrirIncidente(inc.id); });
      g.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); abrirIncidente(inc.id); }
      });
      return g;
    }

    function renderIncidentes() {
      const capa = $('#capaIncidentes');
      capa.textContent = '';
      const lista = activos();
      lista.forEach(function (inc) { capa.appendChild(crearMarcador(inc)); });

      const contenedor = $('#listaIncidentes');
      contenedor.textContent = '';
      if (!lista.length) {
        contenedor.innerHTML = '<p class="sin-incidentes">✓ Vía libre: no hay incidentes activos en la red.</p>';
        return;
      }
      lista.forEach(function (inc) {
        const boton = document.createElement('button');
        boton.type = 'button';
        boton.className = 'chip-incidente';
        boton.innerHTML =
          '<span class="chip-punto ' + (inc.severidad === 'alta' ? '' : 'medio') + '" aria-hidden="true"></span>' +
          '<span class="chip-texto"><strong>' + esc(inc.titulo) + '</strong><small>' + esc(inc.direccion) + ' · ' + esc(hace(inc.creadoEn)) + '</small></span>' +
          '<span class="chip-flecha" aria-hidden="true">›</span>';
        boton.setAttribute('aria-label', 'Ver incidente: ' + inc.titulo + ' en ' + inc.direccion);
        boton.addEventListener('click', function () { abrirIncidente(inc.id); });
        contenedor.appendChild(boton);
      });
    }

    function renderUbicador() {
      const punto = geoAMapa(DB.ultimaUbicacion || LUGAR_FALLBACK);
      $('#marcadorUsuario').setAttribute('transform', 'translate(' + punto.x + ' ' + punto.y + ')');
      const d = 'M' + punto.x + ' ' + punto.y + ' L300 430 L300 180 L560 180 L720 80';
      const a = 'M' + punto.x + ' ' + punto.y + ' L170 330 L420 330 L420 250 L620 250 L720 80';
      $('#rutaPrincipal').setAttribute('d', d);
      $('#rutaPrincipalBrillo').setAttribute('d', d);
      $('#rutaAlterna').setAttribute('d', a);
    }

    function hashTexto(texto) {
      let h = 2166136261;
      for (let i = 0; i < texto.length; i++) { h ^= texto.charCodeAt(i); h = Math.imul(h, 16777619); }
      return h >>> 0;
    }

    function generarQR(semilla) {
      const g = $('#qrVector');
      g.textContent = '';
      const fondo = document.createElementNS(NS, 'rect');
      fondo.setAttribute('x', '-5'); fondo.setAttribute('y', '-5');
      fondo.setAttribute('width', '96'); fondo.setAttribute('height', '96');
      fondo.setAttribute('rx', '6'); fondo.setAttribute('fill', '#0B1B33');
      g.appendChild(fondo);

      const n = 15, celda = 5.7;
      let semillaNum = hashTexto(semilla || 'rutacero');
      const aleatorio = function () {
        semillaNum ^= semillaNum << 13; semillaNum ^= semillaNum >>> 17; semillaNum ^= semillaNum << 5;
        return (semillaNum >>> 0) / 4294967296;
      };
      const esFinder = function (f, c) {
        return (f < 6 && c < 6) || (f < 6 && c >= n - 6) || (f >= n - 6 && c < 6);
      };
      for (let f = 0; f < n; f++) {
        for (let c = 0; c < n; c++) {
          if (esFinder(f, c)) continue;
          if (aleatorio() > 0.52) {
            const r = document.createElementNS(NS, 'rect');
            r.setAttribute('x', (c * celda).toFixed(1)); r.setAttribute('y', (f * celda).toFixed(1));
            r.setAttribute('width', celda.toFixed(1)); r.setAttribute('height', celda.toFixed(1));
            r.setAttribute('fill', '#E2F5FF');
            g.appendChild(r);
          }
        }
      }
      [[0, 0], [n - 6, 0], [0, n - 6]].forEach(function (pos) {
        const ox = pos[1] * celda, oy = pos[0] * celda;
        const marco = document.createElementNS(NS, 'rect');
        marco.setAttribute('x', ox.toFixed(1)); marco.setAttribute('y', oy.toFixed(1));
        marco.setAttribute('width', (celda * 6).toFixed(1)); marco.setAttribute('height', (celda * 6).toFixed(1));
        marco.setAttribute('fill', 'none'); marco.setAttribute('stroke', '#38BDF8'); marco.setAttribute('stroke-width', '3');
        g.appendChild(marco);
        const centro = document.createElementNS(NS, 'rect');
        centro.setAttribute('x', (ox + celda * 2).toFixed(1)); centro.setAttribute('y', (oy + celda * 2).toFixed(1));
        centro.setAttribute('width', (celda * 2).toFixed(1)); centro.setAttribute('height', (celda * 2).toFixed(1));
        centro.setAttribute('fill', '#F59E0B');
        g.appendChild(centro);
      });
    }

    function generarBarras(semilla) {
      const g = $('#codigoBarras');
      g.textContent = '';
      let num = hashTexto('barras-' + (semilla || 'ruta'));
      let x = 0;
      for (let i = 0; i < 42 && x < 160; i++) {
        num = (Math.imul(num, 1664525) + 1013904223) >>> 0;
        const ancho = 1 + (num % 3);
        const r = document.createElementNS(NS, 'rect');
        r.setAttribute('x', x); r.setAttribute('y', '0');
        r.setAttribute('width', ancho); r.setAttribute('height', i % 5 === 0 ? '26' : '21');
        g.appendChild(r);
        x += ancho + 1 + (num % 2);
      }
    }

    function cortar(texto, max) {
      const t = normalizar(texto) || '—';
      return t.length > max ? t.slice(0, max - 1) + '…' : t;
    }

    function renderLicencia() {
      if (!DB.usuario) return;
      const u = DB.usuario;
      $('#licNombre').textContent = cortar(u.nombre, 22);
      $('#licPlacas').textContent = cortar(u.placas || 'SIN VEHÍCULO', 14);
      $('#licModelo').textContent = cortar(u.modelo || 'NO REGISTRADO', 22);
      $('#licNumero').textContent = cortar(u.licencia, 18);
      $('#licContacto').textContent = cortar(u.contactoNombre, 24);
      $('#licTel').textContent = formatoTel(u.contactoTelefono);
      $('#licEmitida').textContent = 'EMITIDA ' + new Date(u.creadoEn || Date.now()).getFullYear();
      generarQR((u.licencia || '') + '|' + (u.placas || ''));
      generarBarras(u.licencia || u.nombre || 'rutacero');
      $('#estadoVehiculo').hidden = u.vehiculoActivo !== false;
    }

    function renderHistorial() {
      const c = $('#listaHistorial');
      c.textContent = '';
      if (!DB.alertas.length) {
        c.innerHTML = '<div class="historial-item"><strong>Sin alertas todavía</strong><small>Tus reportes aparecerán aquí.</small></div>';
        return;
      }
      DB.alertas.slice(0, 5).forEach(function (a) {
        const item = document.createElement('div');
        item.className = 'historial-item';
        item.innerHTML = '<strong>' + esc(a.titulo) + '</strong><small>' + esc(new Date(a.fecha).toLocaleString('es-MX', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' })) + ' · ' + esc(a.direccion) + '</small>';
        c.appendChild(item);
      });
    }

    function renderGruaChoque() {
      const g = gruaMasCercana(DB.ultimaUbicacion || LUGAR_FALLBACK);
      $('#gruaCercanaChoque').textContent = 'Unidad más cercana: ' + g.nombre + ' · ' + g.eta + ' min · ' + g.distanciaTexto;
      $('#emergGrua').textContent = g.nombre + ' · ' + g.eta + ' min';
    }

    /* Panel visible SOLO mientras exista un reporte levantado por este conductor
       (EMERGENCIA o CHOQUE propio / accidente menor). Nunca para baches o choques
       de terceros, que se gestionan únicamente con validación comunitaria. */
    function reportePropioActivo() {
      return DB.incidentes
        .filter(function (i) { return i.estado === 'activo' && i.esPropio === true; })
        .sort(function (a, b) { return b.creadoEn - a.creadoEn; })[0] || null;
    }

    function renderReportePropio() {
      const inc = reportePropioActivo();
      const panel = $('#panelReportePropio');
      panel.hidden = !inc;
      if (!inc) return;
      $('#tituloReportePropio').textContent = inc.titulo;
      $('#direccionReportePropio').textContent = inc.direccion;
      $('#tiempoReportePropio').textContent = hace(inc.creadoEn);
      const grua = inc.gruaAsignada
        ? inc.gruaAsignada + (inc.etaGrua ? ' · ETA ' + inc.etaGrua + ' min' : '')
        : 'Unidad en asignación';
      $('#detalleReportePropio').textContent =
        'Tu punto rojo y el desvío están activos para la red. ' + grua + '. ' +
        'Cuando la unidad retire el vehículo o estés a salvo, cierra tu reporte aquí.';
    }

    function renderTodo() {
      renderCabecera();
      renderUbicador();
      renderRutasYEstado();
      renderIncidentes();
      renderReportePropio();
      renderLicencia();
      renderHistorial();
      renderGruaChoque();
    }

    /* ========================================================================
       5. GESTIÓN DE OVERLAYS, FOCO Y NAVEGACIÓN
       ======================================================================== */
    let overlayActual = null;
    let focoAnterior = null;
    let escapeActual = null;

    function abrirOverlay(elemento, alEscape) {
      if (overlayActual && overlayActual !== elemento) cerrarOverlay(false);
      focoAnterior = document.activeElement;
      overlayActual = elemento;
      escapeActual = typeof alEscape === 'function' ? alEscape : null;
      elemento.hidden = false;
      window.requestAnimationFrame(function () {
        const objetivo = elemento.querySelector('[data-autofoco]') ||
          elemento.querySelector('button, input, [href], [tabindex]:not([tabindex="-1"])');
        if (objetivo) objetivo.focus();
      });
    }

    function cerrarOverlay(devolverFoco) {
      if (!overlayActual) return;
      overlayActual.hidden = true;
      overlayActual = null;
      escapeActual = null;
      if (devolverFoco !== false && focoAnterior && focoAnterior.isConnected) focoAnterior.focus();
    }

    document.addEventListener('keydown', function (e) {
      if (!overlayActual) return;
      if (e.key === 'Escape') {
        e.preventDefault();
        if (escapeActual) escapeActual(); else cerrarOverlay();
        return;
      }
      if (e.key !== 'Tab') return;
      const focusables = Array.prototype.slice.call(
        overlayActual.querySelectorAll('button:not([disabled]), input:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])')
      ).filter(function (n) { return n.getClientRects().length > 0; });
      if (!focusables.length) return;
      const primero = focusables[0], ultimo = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === primero) { e.preventDefault(); ultimo.focus(); }
      else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primero.focus(); }
    });

    function mostrarPantalla(id) {
      ['pantallaLogin', 'pantallaInicio', 'pantallaCuenta'].forEach(function (pantalla) {
        document.getElementById(pantalla).hidden = pantalla !== id;
      });
      const destino = document.getElementById(id);
      destino.scrollTop = 0;
      document.title = (id === 'pantallaLogin' ? 'Acceso' : id === 'pantallaCuenta' ? 'Mi cuenta' : 'Panel') + ' · RutaCero';
      if (id === 'pantallaInicio' || id === 'pantallaCuenta') { renderTodo(); renderUbicador(); }
      if (id === 'pantallaLogin') actualizarBannerSesion();
    }

    function actualizarBannerSesion() {
      const banner = $('#bannerSesion');
      const hayPerfil = Boolean(DB.usuario);
      banner.hidden = !(hayPerfil && !DB.sesionActiva);
      if (hayPerfil) $('#textoSesionGuardada').textContent = 'Perfil guardado: ' + normalizar(DB.usuario.nombre) + '.';
    }

    function entrar(player) {
      if (player) DB.usuario = player;
      DB.sesionActiva = true;
      guardar();
      mostrarPantalla('pantallaInicio');
      anunciar('Sesión iniciada. Panel principal listo.');
    }

    function salir() {
      DB.sesionActiva = false;
      guardar();
      cerrarOverlay(false);
      mostrarPantalla('pantallaLogin');
      mostrarToast('Sesión cerrada. Tu perfil sigue guardado en este dispositivo.');
    }

    /* ========================================================================
       6. FORMULARIO DE ACCESO
       ======================================================================== */
    const REGLAS_LOGIN = [
      ['nombre', function (v) { return normalizar(v).length >= 4; }, 'Escribe tu nombre completo (mínimo 4 caracteres).'],
      ['telefono', function (v) { return digitos(v).length === 10; }, 'El teléfono debe tener 10 dígitos.'],
      ['contactoNombre', function (v) { return normalizar(v).length >= 3; }, 'Escribe el nombre de tu contacto de emergencia.'],
      ['contactoTelefono', function (v) { return digitos(v).length === 10; }, 'El teléfono del contacto debe tener 10 dígitos.'],
      ['modelo', function (v) { return normalizar(v).length >= 4; }, 'Indica modelo y año, por ejemplo Nissan Versa 2022.'],
      ['placas', function (v) { return /^[A-Za-z0-9-]{6,10}$/.test(normalizar(v)); }, 'Usa un formato válido, por ejemplo FGH-452-A.'],
      ['licencia', function (v) { return normalizar(v).length >= 6; }, 'La licencia debe tener al menos 6 caracteres.']
    ];

    function limpiarErrores(formato) {
      $$('#' + formato + ' .error').forEach(function (n) { n.textContent = ''; });
      $$('#' + formato + ' input').forEach(function (n) { n.removeAttribute('aria-invalid'); });
    }

    function validar(formato, reglas) {
      limpiarErrores(formato);
      let valido = true, primero = null;
      reglas.forEach(function (regla) {
        const campo = document.getElementById(regla[0]);
        const valor = campo ? campo.value : '';
        if (!regla[1](valor)) {
          valido = false;
          const error = document.getElementById('err-' + regla[0]);
          if (error) error.textContent = regla[2];
          campo.setAttribute('aria-invalid', 'true');
          if (!primero) primero = campo;
        }
      });
      if (primero) primero.focus();
      return valido;
    }

    function llenarDemo() {
      const valores = {
        nombre: 'Ana Sofía Ramos', telefono: '8711234567',
        contactoNombre: 'Luis Ramos', contactoTelefono: '8719876543',
        modelo: 'Nissan Versa 2022', placas: 'FGH-452-A', licencia: 'COAH-2026-1842'
      };
      Object.keys(valores).forEach(function (id) { document.getElementById(id).value = valores[id]; });
      limpiarErrores('formLogin');
      mostrarToast('Datos de prueba cargados. Ya puedes ingresar.', 'var(--ambar)');
      anunciar('Datos de prueba cargados.');
    }

    /* ========================================================================
       7. REPORTE COMUNITARIO Y CICLO DE VIDA DE INCIDENTES
       ======================================================================== */
    function textoUbicacionReporte() {
      const p = estado.ubicacionReporte;
      if (!p) return;
      $('#ubicacionReporte').innerHTML = 'Ubicación: <strong>' + esc(calleCercana(p.x, p.y)) + '</strong> · Torreón<br /><small>Lat ' + p.geo.lat.toFixed(5) + ', Lng ' + p.geo.lng.toFixed(5) + '</small>';
      $('#marcadorTemporal').setAttribute('transform', 'translate(' + p.x + ' ' + p.y + ')');
      $('#marcadorTemporal').hidden = false;
    }

    function abrirReporte() {
      const punto = geoAMapa(DB.ultimaUbicacion || LUGAR_FALLBACK);
      estado.ubicacionReporte = { x: punto.x, y: punto.y, geo: mapaAGeo(punto.x, punto.y) };
      textoUbicacionReporte();
      abrirOverlay($('#modalReporte'));
      anunciar('Reporte comunitario abierto. Toca el mapa para colocar el punto.');
    }

    function usarMiUbicacion() {
      const punto = geoAMapa(DB.ultimaUbicacion || LUGAR_FALLBACK);
      estado.ubicacionReporte = { x: punto.x, y: punto.y, geo: Object.assign({}, DB.ultimaUbicacion || LUGAR_FALLBACK) };
      textoUbicacionReporte();
      mostrarToast('Ubicación actual colocada en el mapa.');
    }

    function coordsSvg(evento) {
      const svg = $('#mapaSvg');
      const ctm = svg.getScreenCTM();
      if (!ctm || !svg.createSVGPoint) return null;
      const punto = svg.createSVGPoint();
      punto.x = evento.clientX; punto.y = evento.clientY;
      const local = punto.matrixTransform(ctm.inverse());
      return { x: Math.round(clamp(local.x, 20, 780)), y: Math.round(clamp(local.y, 20, 540)) };
    }

    function recalcularRuta(mensajeFinal) {
      estado.recalcando = true;
      $('#pillRecalc').hidden = false;
      $('#mapaContenedor').classList.add('recalculando');
      renderRutasYEstado();
      anunciar('Recalculando la ruta de la red RutaCero…');
      window.clearTimeout(estado.temporizadorRecalculo);
      estado.temporizadorRecalculo = window.setTimeout(function () {
        estado.recalcando = false;
        $('#pillRecalc').hidden = true;
        $('#mapaContenedor').classList.remove('recalculando');
        renderRutasYEstado();
        anunciar(mensajeFinal || 'Ruta recalculada.');
      }, 1400);
    }

    function confirmarReporte() {
      const tipo = (document.querySelector('input[name="tipoReporte"]:checked') || {}).value || 'bache';
      const plantilla = TIPOS_REPORTE[tipo];
      const p = estado.ubicacionReporte;
      if (!p) { mostrarToast('Coloca primero el punto en el mapa.', 'var(--ambar)'); return; }
      const inc = {
        id: 'inc-' + Date.now(), tipo: tipo, titulo: plantilla.titulo,
        direccion: calleCercana(p.x, p.y) + ', Torreón', x: p.x, y: p.y,
        severidad: plantilla.severidad, origen: 'reporte', creadoEn: Date.now(),
        descripcion: plantilla.descripcion, validaciones: { sigue: 0, libre: 0 }, estado: 'activo',
        esPropio: false, desviando: plantilla.severidad === 'alta'
      };
      DB.incidentes.push(inc);
      guardar();
      $('#marcadorTemporal').hidden = true;
      cerrarOverlay(false);
      renderTodo();
      recalcularRuta(plantilla.severidad === 'alta'
        ? 'Reporte comunitario publicado. Ruta alterna activada para la red.'
        : 'Aviso leve publicado. La comunidad podrá validarlo al pasar.');
      pitido(660, 0.12, 0.06);
      vibrar(120);
      mostrarToast('Reporte publicado: ' + plantilla.titulo + '. La red ya fue avisada.', 'var(--ambar)');
    }

    const ORIGENES = {
      semilla: 'RED RUTACERO', reporte: 'COMUNIDAD', emergencia: 'EMERGENCIA',
      choque: 'REPORTE DE CHOQUE'
    };

    function abrirIncidente(id) {
      if (!$('#modalReporte').hidden) return;
      const inc = DB.incidentes.filter(function (i) { return i.id === id; })[0];
      if (!inc || inc.estado !== 'activo') return;
      estado.incidenteAbierto = id;
      $('#tituloIncidente').textContent = inc.titulo;
      $('#incDireccion').textContent = '📍 ' + inc.direccion + ' · reportado ' + hace(inc.creadoEn);
      $('#incDescripcion').textContent = inc.descripcion;
      const badge = $('#incBadge');
      badge.textContent = inc.severidad === 'alta' ? 'SEVERIDAD ALTA' : 'AVISO LEVE';
      badge.className = 'badge ' + (inc.severidad === 'alta' ? 'alta' : 'media');
      $('#incOrigen').textContent = ORIGENES[inc.origen] || 'REPORTE';
      $('#incSigue').textContent = inc.validaciones.sigue;
      $('#incLibre').textContent = inc.validaciones.libre;

      // Separación de flujos: el cierre operativo solo existe para el reporte propio.
      const esPropio = inc.esPropio === true;
      $('#btnCerrarIncidente').hidden = !esPropio;
      $('#btnSigueAqui').hidden = esPropio;
      $('#btnViaLibre').hidden = esPropio;
      $('#incModoTexto').textContent = esPropio
        ? 'Este es tu reporte activo. Ciérralo cuando la grúa haya retirado la unidad o ya estés a salvo.'
        : 'Incidente de la comunidad: solo puedes validarlo. Con 2 votos de “vía libre” se retira del mapa.';
      abrirOverlay($('#modalIncidente'));
    }

    function incidenteAbierto() {
      return DB.incidentes.filter(function (i) { return i.id === estado.incidenteAbierto; })[0];
    }

    function validarIncidente(tipo) {
      const inc = incidenteAbierto();
      if (!inc) return;
      inc.validaciones[tipo] += 1;
      guardar();
      $('#incSigue').textContent = inc.validaciones.sigue;
      $('#incLibre').textContent = inc.validaciones.libre;
      renderIncidentes();
      if (tipo === 'libre' && inc.validaciones.libre >= 2) {
        resolverIncidente('Vía libre confirmada por 2 conductores de la red');
        return;
      }
      mostrarToast(tipo === 'sigue' ? 'Confirmación registrada: el incidente sigue activo.' : 'Vía libre registrada. Esperando otra confirmación.', tipo === 'sigue' ? 'var(--rojo)' : 'var(--ambar)');
      anunciar(tipo === 'sigue' ? 'Incidente confirmado como activo.' : 'Vía libre registrada por la comunidad.');
    }

    function resolverIncidente(motivo) {
      const inc = incidenteAbierto();
      if (!inc) return;
      inc.estado = 'resuelto';
      inc.resueltoEn = Date.now();
      inc.motivoCierre = motivo;
      inc.desviando = false;
      // La validación comunitaria con 2+ votos da por liberada la vía y
      // restablece la ruta óptima en verde, como pide el flujo de la red.
      if (/Vía libre/i.test(motivo)) {
        DB.incidentes.forEach(function (otro) {
          if (otro.estado === 'activo') otro.desviando = false;
        });
      }
      guardar();
      cerrarOverlay(false);
      renderTodo();
      recalcularRuta('Incidente cerrado. Ruta original en verde restablecida.');
      mostrarToast('Incidente cerrado · ' + motivo + '. Punto eliminado del mapa.');
      anunciar('Incidente cerrado y punto eliminado del mapa. Ruta original restablecida.');
    }

    /* Cierre operativo EXCLUSIVO del reporte propio: retira su punto rojo,
       desactiva cualquier desvío vigente y oculta el panel propia. Los reportes
       de terceros y baches NO pueden cerrarse con este botón. */
    function cerrarReportePropio() {
      const propios = DB.incidentes.filter(function (i) {
        return i.estado === 'activo' && i.esPropio === true;
      });
      if (!propios.length) return;

      propios.forEach(function (inc) {
        inc.estado = 'resuelto';
        inc.resueltoEn = Date.now();
        inc.motivoCierre = 'Cierre operativo: grúa retiró unidad / conductor a salvo';
        inc.desviando = false;
      });
      // Garantiza que el banner vuelva a verde aunque queden avisos leves ajenos.
      DB.incidentes.forEach(function (inc) {
        if (inc.estado === 'activo') inc.desviando = false;
      });

      if (propios.some(function (i) { return i.id === estado.incidenteAbierto; })) {
        cerrarOverlay(false);
      }
      estado.incidenteAbierto = null;
      guardar();
      renderTodo();
      recalcularRuta('Reporte propio cerrado. Desvío retirado y ruta óptima en verde restablecida.');
      mostrarToast('Tu reporte se cerró: tu punto rojo desapareció del mapa para la red RutaCero.');
      anunciar('Reporte propio cerrado. Ruta óptima activa restablecida.');
    }

    /* ========================================================================
       8. EMERGENCIA: DESLIZAMIENTO + 3 SEGUNDOS CANCELABLES
       ======================================================================== */
    let sliderValor = 0;
    let arrastrando = false;

    function fijarSlider(valor) {
      sliderValor = clamp(valor, 0, 100);
      const slider = $('#sliderEmergencia');
      const knob = $('#sliderKnob');
      const recorrido = Math.max(0, slider.clientWidth - knob.offsetWidth - 8);
      $('#sliderRelleno').style.width = sliderValor + '%';
      knob.style.transform = 'translateX(' + ((sliderValor / 100) * recorrido) + 'px)';
      knob.setAttribute('aria-valuenow', String(Math.round(sliderValor)));
      knob.setAttribute('aria-valuetext', Math.round(sliderValor) + ' por ciento');
    }

    function reiniciarSlider() {
      $('#sliderEmergencia').classList.remove('sin-transicion');
      fijarSlider(0);
    }

    function configurarSlider() {
      const knob = $('#sliderKnob');
      const slider = $('#sliderEmergencia');
      knob.addEventListener('pointerdown', function (e) {
        arrastrando = true;
        slider.classList.add('sin-transicion');
        try { knob.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        e.preventDefault();
      });
      knob.addEventListener('pointermove', function (e) {
        if (!arrastrando) return;
        const r = slider.getBoundingClientRect();
        const recorrido = Math.max(1, r.width - knob.offsetWidth - 8);
        fijarSlider(((e.clientX - r.left - 4) / recorrido) * 100);
      });
      const soltar = function () {
        if (!arrastrando) return;
        arrastrando = false;
        if (sliderValor >= 96) { activarEmergencia(); reiniciarSlider(); }
        else reiniciarSlider();
      };
      knob.addEventListener('pointerup', soltar);
      knob.addEventListener('pointercancel', soltar);
      knob.addEventListener('keydown', function (e) {
        let valor = sliderValor;
        if (e.key === 'ArrowRight' || e.key === 'ArrowUp') valor += 20;
        else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') valor -= 20;
        else if (e.key === 'Home') valor = 0;
        else if (e.key === 'End') valor = 100;
        else return;
        e.preventDefault();
        fijarSlider(valor);
        if (valor >= 100) { activarEmergencia(); reiniciarSlider(); }
      });
      window.addEventListener('resize', function () { fijarSlider(sliderValor); });
      fijarSlider(0);
    }

    function actualizarAnillo(fraccion) {
      const circunferencia = 2 * Math.PI * 45;
      $('#anilloProgreso').style.strokeDasharray = String(circunferencia);
      $('#anilloProgreso').style.strokeDashoffset = String(circunferencia * (1 - fraccion));
    }

    function activarEmergencia() {
      if (!DB.usuario) return;
      estado.ubicacionEmergencia = null;
      $('#numeroCuenta').textContent = '3';
      $('#textoEmergencia').innerHTML = 'Enviaremos tu ubicación en <strong>3 segundos</strong>. Si fue un error, cancela ahora.';
      $('#emergUbicacion').textContent = 'Obteniendo tu ubicación…';
      $('#emergContacto').textContent = normalizar(DB.usuario.contactoNombre) || '—';
      renderGruaChoque();
      actualizarAnillo(1);
      abrirOverlay($('#overlayEmergencia'), cancelarEmergencia);
      pitido(880, 0.13, 0.08);
      vibrar([250, 120, 250, 120, 500]);

      obtenerUbicacion().then(function (ubi) {
        estado.ubicacionEmergencia = ubi;
        DB.ultimaUbicacion = { lat: ubi.lat, lng: ubi.lng, precision: ubi.precision || 0, aproximada: Boolean(ubi.aproximada) };
        guardar();
        renderUbicador();
        if (!$('#overlayEmergencia').hidden) {
          $('#emergUbicacion').textContent = ubi.aproximada
            ? '⚠ ' + (ubi.motivo || 'Ubicación aproximada.')
            : '✓ GPS listo · lat ' + ubi.lat + ', lng ' + ubi.lng + (ubi.precision ? ' · ±' + ubi.precision + ' m' : '');
          renderGruaChoque();
        }
      });

      window.clearInterval(estado.cuentaAtras);
      let restante = 3;
      estado.cuentaAtras = window.setInterval(function () {
        restante -= 1;
        actualizarAnillo(Math.max(0, restante) / 3);
        if (restante <= 0) {
          window.clearInterval(estado.cuentaAtras);
          $('#numeroCuenta').textContent = '0';
          $('#textoEmergencia').innerHTML = 'Enviando aviso a <strong>tus tres destinatarios</strong…';
          pitido(440, 0.4, 0.11);
          vibrar([800]);
          window.setTimeout(confirmarEmergencia, 380);
        } else {
          $('#numeroCuenta').textContent = String(restante);
          $('#textoEmergencia').innerHTML = 'Enviaremos tu ubicación en <strong>' + restante + ' segundo' + (restante === 1 ? '' : 's') + '</strong>. Si fue un error, cancela ahora.';
          pitido(760 + restante * 60, 0.11, 0.07);
          vibrar(120);
        }
      }, 1000);
    }

    function cancelarEmergencia() {
      window.clearInterval(estado.cuentaAtras);
      cerrarOverlay(false);
      reiniciarSlider();
      mostrarToast('Alerta cancelada. No se envió ningún aviso.', 'var(--ambar)');
      anunciar('Emergencia cancelada por el usuario.');
    }

    function llenarResumen(destinos, contenedor) {
      contenedor.textContent = '';
      destinos.forEach(function (d) {
        const li = document.createElement('li');
        li.innerHTML = '<span class="marca-check" aria-hidden="true">✓</span><span><b>' + esc(d.nombre) + '</b><small>' + esc(d.detalle) + '</small></span>';
        contenedor.appendChild(li);
      });
    }

    function confirmarEmergencia() {
      if ($('#overlayEmergencia').hidden) return;
      window.clearInterval(estado.cuentaAtras);
      cerrarOverlay(false);
      const ubi = estado.ubicacionEmergencia || LUGAR_FALLBACK;
      const grua = gruaMasCercana(ubi);
      const p = geoAMapa(ubi);
      const x = Math.round(clamp(p.x + 24, 30, 770));
      const y = Math.round(clamp(p.y - 20, 30, 530));
      const direccion = calleCercana(x, y) + ', ' + ENV_CONFIG.VITE_APP_CITY;
      const urlMaps = 'https://www.google.com/maps/search/?api=1&query=' + ubi.lat + ',' + ubi.lng;

      const inc = {
        id: 'inc-' + Date.now(), tipo: 'emergencia', titulo: 'Emergencia vial · accidente grave',
        direccion: direccion, x: x, y: y, severidad: 'alta', origen: 'emergencia',
        creadoEn: Date.now(),
        descripcion: 'Alerta grave confirmada. Contacto, grúa y Tránsito notificados; flujo vial desviado por RutaCero.',
        validaciones: { sigue: 0, libre: 0 }, estado: 'activo', servicios: ['contacto', 'grua', 'transito'],
        esPropio: true, desviando: true, gruaAsignada: grua.nombre, etaGrua: grua.eta
      };
      DB.incidentes.push(inc);
      const destinos = [
        { nombre: 'Contacto: ' + normalizar(DB.usuario.contactoNombre), detalle: 'Ubicación GPS y aviso de accidente grave enviados a ' + formatoTel(DB.usuario.contactoTelefono) + '. Canal: ' + (ENV_CONFIG.VITE_SIMULATE_NOTIFICATIONS ? 'simulado' : 'API externa') + '.' },
        { nombre: 'Grúa: ' + grua.nombre, detalle: 'Unidad asignada · ETA ' + grua.eta + ' min · distancia ' + grua.distanciaTexto + '. Tel. demo ' + grua.telefono + '.' },
        { nombre: 'Tránsito y Vialidad · Torreón', detalle: 'Aviso de accidente, bloqueo preventivo y desvío publicado en el mapa de la red.' }
      ];
      DB.alertas.unshift({
        id: 'al-' + Date.now(), tipo: 'emergencia', titulo: 'Emergencia enviada',
        fecha: Date.now(), direccion: direccion, lat: ubi.lat, lng: ubi.lng, destinos: destinos
      });
      guardar();
      estado.idDespacho = inc.id;
      renderTodo();
      recalcularRuta('Emergencia publicada. Ruta alterna activada para todos los conductores.');

      llenarResumen(destinos, $('#resumenExito'));
      $('#gpsExito').textContent = '📍 GPS enviado · lat ' + ubi.lat + ' / lng ' + ubi.lng +
        (ubi.aproximada ? ' (referencia aproximada)' : ' (ubicación exacta)') + '\n' + urlMaps;
      abrirOverlay($('#overlayExito'));
      anunciar('Alerta de emergencia enviada al contacto, a la grúa más cercana y a Tránsito.');
    }

    /* ========================================================================
       9. CHOQUE Y DESPACHO DE SERVICIOS
       ======================================================================== */
    function abrirChoque() {
      const radios = $$('input[name="tipoChoque"]');
      if (radios.length) radios[0].checked = true;
      $$('input[name="servicioChoque"]').forEach(function (c) { c.checked = false; });
      actualizarEstadoChoque();
      renderGruaChoque();
      abrirOverlay($('#modalChoque'));
    }

    function actualizarEstadoChoque() {
      const seleccionados = $$('input[name="servicioChoque"]:checked');
      const boton = $('#btnLlamarChoque');
      boton.disabled = seleccionados.length === 0;
      $('#ayudaChoque').textContent = seleccionados.length === 0
        ? 'Marca al menos un servicio para habilitar la solicitud.'
        : seleccionados.length + ' servicio(s) listo(s) para despacho simultáneo (simulado).';
    }

    function despacharChoque() {
      const servicios = $$('input[name="servicioChoque"]:checked').map(function (n) { return n.value; });
      if (!servicios.length) { mostrarToast('Marca al menos un servicio.', 'var(--ambar)'); return; }
      const tipo = (document.querySelector('input[name="tipoChoque"]:checked') || {}).value || 'propio';
      const ubi = estado.ubicacionEmergencia || DB.ultimaUbicacion || LUGAR_FALLBACK;
      const grua = gruaMasCercana(ubi);
      const p = geoAMapa(ubi);
      const x = Math.round(clamp(p.x + 26, 30, 770));
      const y = Math.round(clamp(p.y - 16, 30, 530));
      const direccion = calleCercana(x, y) + ', ' + ENV_CONFIG.VITE_APP_CITY;
      const titulos = {
        propio: 'Choque propio reportado',
        accidente: 'Accidente menor reportado',
        testigo: 'Choque de tercero reportado'
      };
      const inc = {
        id: 'inc-' + Date.now(), tipo: 'choque', titulo: titulos[tipo],
        direccion: direccion, x: x, y: y, severidad: 'alta', origen: 'choque',
        creadoEn: Date.now(),
        descripcion: 'Punto rojo activo en el mapa vial. Solicitud de servicios enviada y tráfico desviado.',
        validaciones: { sigue: 1, libre: 0 }, estado: 'activo', servicios: servicios,
        // Solo el choque propio / accidente menor habilita el cierre operativo.
        esPropio: tipo === 'propio' || tipo === 'accidente',
        desviando: true,
        gruaAsignada: servicios.indexOf('grua') !== -1 ? grua.nombre : null,
        etaGrua: servicios.indexOf('grua') !== -1 ? grua.eta : null
      };
      DB.incidentes.push(inc);

      const destinos = [];
      if (servicios.indexOf('ambulancia') !== -1) destinos.push({ nombre: 'Ambulancia · atención médica', detalle: 'Unidad médica solicitada en ' + direccion + '. Llegada estimada 5 min (simulado).' });
      if (servicios.indexOf('grua') !== -1) destinos.push({ nombre: 'Grúa · ' + grua.nombre, detalle: 'ETA ' + grua.eta + ' min · ' + grua.distanciaTexto + '. Tel. demo ' + grua.telefono + '.' });
      if (servicios.indexOf('transito') !== -1) destinos.push({ nombre: 'Tránsito / Vialidad', detalle: 'Control de flujo y peritaje solicitados; desvío activado en la red.' });
      if (tipo === 'accidente') destinos.push({ nombre: 'Contacto: ' + normalizar(DB.usuario.contactoNombre), detalle: 'Aviso adicional por accidente con personas involucradas a ' + formatoTel(DB.usuario.contactoTelefono) + '.' });

      DB.alertas.unshift({
        id: 'al-' + Date.now(), tipo: 'choque', titulo: titulos[tipo],
        fecha: Date.now(), direccion: direccion, lat: ubi.lat, lng: ubi.lng, destinos: destinos
      });
      guardar();
      estado.idDespacho = inc.id;
      cerrarOverlay(false);
      renderTodo();
      recalcularRuta('Choque reportado. Desvío activado para los demás conductores.');
      pitido(620, 0.14, 0.06);
      vibrar([180, 90, 180]);

      $('#tituloDespacho').textContent = 'Solicitud enviada';
      $('#descDespacho').textContent = titulos[tipo] + ' · ' + direccion + '. Llamada y mensajes simulados.';
      llenarResumen(destinos, $('#listaDespacho'));
      abrirOverlay($('#modalDespacho'));
      anunciar('Servicios solicitados y punto rojo agregado al mapa.');
    }

    function verDespachoEnMapa() {
      cerrarOverlay(false);
      mostrarPantalla('pantallaInicio');
      if (estado.idDespacho) window.setTimeout(function () { abrirIncidente(estado.idDespacho); }, 120);
    }

    /* ========================================================================
       10. CUENTA: EDICIÓN, BAJA Y SESIÓN
       ======================================================================== */
    const REGLAS_EDICION = [
      ['editTelefono', function (v) { return digitos(v).length === 10; }, 'Teléfono inválido (10 dígitos).'],
      ['editContactoNombre', function (v) { return normalizar(v).length >= 3; }, 'Escribe el nombre del contacto.'],
      ['editContactoTelefono', function (v) { return digitos(v).length === 10; }, 'Teléfono del contacto inválido.'],
      ['editModelo', function (v) { return normalizar(v).length >= 4; }, 'Indica modelo y año del vehículo.'],
      ['editPlacas', function (v) { return /^[A-Za-z0-9-]{6,10}$/.test(normalizar(v)); }, 'Formato de placas inválido.'],
      ['editLicencia', function (v) { return normalizar(v).length >= 6; }, 'Licencia inválida.']
    ];

    function abrirEdicion() {
      const u = DB.usuario || {};
      $('#editTelefono').value = formatoTel(u.telefono || '');
      $('#editContactoNombre').value = u.contactoNombre || '';
      $('#editContactoTelefono').value = formatoTel(u.contactoTelefono || '');
      $('#editModelo').value = u.modelo || '';
      $('#editPlacas').value = u.placas || '';
      $('#editLicencia').value = u.licencia || '';
      limpiarErrores('formEditar');
      $('#tituloEditar').textContent = u.vehiculoActivo === false ? 'Registrar vehículo nuevo' : 'Actualizar datos';
      abrirOverlay($('#modalEditar'));
    }

    function guardarEdicion(e) {
      e.preventDefault();
      if (!validar('formEditar', REGLAS_EDICION)) return;
      const u = DB.usuario;
      u.telefono = digitos($('#editTelefono').value);
      u.contactoNombre = normalizar($('#editContactoNombre').value);
      u.contactoTelefono = digitos($('#editContactoTelefono').value);
      u.modelo = normalizar($('#editModelo').value);
      u.placas = normalizar($('#editPlacas').value).toUpperCase();
      u.licencia = normalizar($('#editLicencia').value).toUpperCase();
      u.vehiculoActivo = true;
      guardar();
      cerrarOverlay(false);
      renderTodo();
      mostrarToast('Datos guardados y licencia actualizada.');
      anunciar('Datos del conductor actualizados correctamente.');
    }

    function darDeBaja() {
      const u = DB.usuario;
      u.vehiculoActivo = false;
      u.modelo = null;
      u.placas = null;
      guardar();
      cerrarOverlay(false);
      renderTodo();
      mostrarToast('Automóvil dado de baja del registro.', 'var(--rojo)');
      anunciar('Vehículo dado de baja. Puedes registrar uno nuevo o cerrar sesión.');
    }

    function reiniciarDemo() {
      if (!window.confirm('¿Reiniciar la demo? Se borrarán el perfil, las alertas y los incidentes guardados en este dispositivo.')) return;
      borra(DB_KEY);
      borra(ENV_KEY);
      DB = dbNueva();
      DB.incidentes = incidentesSemilla();
      DB.semillaCargada = true;
      guardar();
      cerrarOverlay(false);
      $('#formLogin').reset();
      limpiarErrores('formLogin');
      mostrarPantalla('pantallaLogin');
      mostrarToast('Demo reiniciada con datos precargados.');
    }

    /* ========================================================================
       11. CONEXIÓN DE EVENTOS E INICIO
       ======================================================================== */
    function adjuntarEventos() {
      $('#btnDemo').addEventListener('click', llenarDemo);
      $('#formLogin').addEventListener('submit', function (e) {
        e.preventDefault();
        if (!validar('formLogin', REGLAS_LOGIN)) return;
        entrar({
          nombre: normalizar($('#nombre').value),
          telefono: digitos($('#telefono').value),
          contactoNombre: normalizar($('#contactoNombre').value),
          contactoTelefono: digitos($('#contactoTelefono').value),
          modelo: normalizar($('#modelo').value),
          placas: normalizar($('#placas').value).toUpperCase(),
          licencia: normalizar($('#licencia').value).toUpperCase(),
          creadoEn: Date.now(),
          vehiculoActivo: true
        });
        mostrarToast('¡Bienvenido a RutaCero! Tu perfil quedó guardado.');
      });
      $('#btnReanudar').addEventListener('click', function () {
        if (DB.usuario) entrar();
      });

      configurarSlider();
      $('#btnEmergenciaAccesible').addEventListener('click', activarEmergencia);
      $('#btnCancelarEmergencia').addEventListener('click', cancelarEmergencia);
      $('#btnExitoVerMapa').addEventListener('click', verDespachoEnMapa);

      $('#btnChoque').addEventListener('click', abrirChoque);
      $$('input[name="servicioChoque"]').forEach(function (n) { n.addEventListener('change', actualizarEstadoChoque); });
      $$('input[name="tipoChoque"]').forEach(function (n) { n.addEventListener('change', actualizarEstadoChoque); });
      $('#btnLlamarChoque').addEventListener('click', despacharChoque);
      $('#btnVerEnMapa').addEventListener('click', verDespachoEnMapa);

      $('#btnReporte').addEventListener('click', abrirReporte);
      $('#btnUsarMiUbicacion').addEventListener('click', usarMiUbicacion);
      $('#btnConfirmarReporte').addEventListener('click', confirmarReporte);
      $('#mapaSvg').addEventListener('click', function (e) {
        if ($('#modalReporte').hidden) return;
        const p = coordsSvg(e);
        if (!p) return;
        estado.ubicacionReporte = { x: p.x, y: p.y, geo: mapaAGeo(p.x, p.y) };
        textoUbicacionReporte();
        anunciar('Ubicación del reporte actualizada en el mapa.');
      });

      $('#btnVerIncidentes').addEventListener('click', function () {
        const lista = activos();
        if (!lista.length) { mostrarToast('No hay incidentes activos: la vía está libre.'); return; }
        abrirIncidente(lista[0].id);
      });
      $('#btnSigueAqui').addEventListener('click', function () { validarIncidente('sigue'); });
      $('#btnViaLibre').addEventListener('click', function () { validarIncidente('libre'); });
      $('#btnCerrarIncidente').addEventListener('click', cerrarReportePropio);
      $('#btnCerrarReportePropio').addEventListener('click', cerrarReportePropio);

      $('#btnCuenta').addEventListener('click', function () { mostrarPantalla('pantallaCuenta'); });
      $('#btnVolver').addEventListener('click', function () { mostrarPantalla('pantallaInicio'); });
      $('#btnActualizar').addEventListener('click', abrirEdicion);
      $('#btnNuevoVehiculo').addEventListener('click', abrirEdicion);
      $('#formEditar').addEventListener('submit', guardarEdicion);
      $('#btnBaja').addEventListener('click', function () { abrirOverlay($('#modalBaja')); });
      $('#btnConfirmarBaja').addEventListener('click', darDeBaja);
      $('#btnCerrarSesion').addEventListener('click', salir);
      $('#btnSalir').addEventListener('click', salir);
      $('#btnReiniciar').addEventListener('click', reiniciarDemo);

      document.addEventListener('click', function (e) {
        const boton = e.target.closest ? e.target.closest('[data-cerrar]') : null;
        if (boton && overlayActual) cerrarOverlay();
      });
    }

    function iniciar() {
      // Los valores de ENV_CONFIG pueden cambiar el número de emergencia mostrado.
      const telefonoEmergencia = esc(ENV_CONFIG.VITE_EMERGENCY_PHONE);
      $('#notaEmergencia').textContent = 'Esta demo no llama al ' + telefonoEmergencia + '. Si hay una emergencia real, usa tu teléfono.';
      $('#pieEmergencia').innerHTML = 'Demo de hackathon · No llama al ' + telefonoEmergencia + ' ni envía grúas reales.<br />Usa tu teléfono ante una emergencia verdadera.';
      adjuntarEventos();
      actualizarBannerSesion();
      if (DB.usuario && DB.sesionActiva) mostrarPantalla('pantallaInicio');
      else mostrarPantalla('pantallaLogin');
      renderTodo();
      anunciar('RutaCero lista. Modo demostración offline en Torreón.');
    }

    iniciar();
  })();