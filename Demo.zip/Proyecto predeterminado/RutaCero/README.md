# RutaCero · Movilidad urbana inteligente (demo offline)

Aplicación web móvil **100% vanilla** (HTML5 + CSS3 + JavaScript ES6+) para una demo de hackathon.
El proyecto está separado en `index.html`, `styles.css` y `app.js`. No hay dependencias, servidores, bases de datos SQL ni llamadas externas.

> Aviso: teléfonos, grúas y alertas son ficticios. No llama al 911, no envía SMS ni despacha unidades reales. Ante una emergencia verdadera, usa tu teléfono.

---

## Cómo ejecutarla

1. Abre Visual Studio Code en esta carpeta (`RutaCero`).
2. Abre `index.html` con doble clic (o botón derecho → **Open with Live Server** si tienes la extensión).
3. También puedes arrastrar el archivo a Chrome / Edge. Funciona sin internet.

Todas las vistas (acceso, panel, cuenta, hojas y overlays) se muestran dentro de un **marco vertical tipo teléfono**, centrado en escritorio y a pantalla completa en móvil. La licencia digital también usa un SVG en formato retrato.

No necesitas `npm install`.

---

## Qué incluye

### Persistencia local
- `localStorage['rutacero.db.v1']`: perfil, sesión, incidentes, alertas y última ubicación.
- Catálogo precargado de **3 grúas** con ETA: Laguna Express (6 min), Asistencia Vial Centro (9 min) y Ruta Norte (12 min).
- **2 incidentes iniciales** en Torreón: choque en Blvd. Independencia (punto rojo pulsante) y bache/obra en Perif. Raúl López Sánchez (triángulo ámbar).
- Si el navegador bloquea `localStorage` (algunos modos `file://`), la app usa un respaldo en memoria y sigue funcionando.

### Pantalla 1 · Registro
Todos los campos solicitados (nombre, teléfono, contacto, modelo, placas, licencia), validación accesible con errores junto al campo, botón **Llenar con datos de prueba** y acceso directo si ya hay sesión guardada.

### Pantalla 2 · Panel principal
- **Mapa vectorial SVG** de arterias de Torreón con ruta óptima en verde, desvío ámbar, tu ubicación y marcadores interactivos (teclado incluido: Tab + Enter).
- Banner de estado: verde *"Ahorrando 12 min"* → naranja *"Tráfico desviado · ruta alterna +8 min"* cuando hay un incidente grave.
- **+ Bache / Bloqueo**: reporte comunitario. Puedes tocar el mapa para ubicar el punto o usar tu GPS.
- **Validación comunitaria**: tocar un incidente ajeno o un bache/obra abre una tarjeta con *Sí, sigue aquí* y *Vía libre (ya se despejó)*. Con 2 votos de vía libre el punto desaparece, el desvío se retira y la ruta óptima vuelve a verde. Esos incidentes **no tienen botón de cierre operativo**.
- **Cierre operativo propio**: al confirmar una EMERGENCIA o un CHOQUE propio/accidente menor aparece, justo debajo del mapa, el panel **“Tu reporte está activo en la red”** con el botón verde *✓ GRÚA RETIRÓ UNIDAD / YA ESTOY A SALVO*. Ese botón retira tu punto rojo de la red, desactiva el desvío, oculta el panel y restaura el banner verde. No aparece para baches ni choques de terceros.
- **EMERGENCIA**: control táctil *deslizar para activar* (también usable con flechas del teclado y con un enlace alterno). Abre una cuenta regresiva de 3 s con pulso, vibración, pitidos Web Audio y botón gigante de **CANCELAR ALERTA**. Al llegar a 0: GPS, contacto, grúa más cercana (Haversine), Tránsito y punto rojo en el mapa + resumen confirmado.
- **CHOQUE**: tres tipos de percance, checkboxes grandes de Ambulancia / Grúa (con ETA de la unidad cercana) / Tránsito y despacho simultáneo simulado.
- **CUENTA**: abre la licencia digital.

### Pantalla 3 · Cuenta
Licencia vectorial SVG (avatar geométrico, automóvil, sello de verificación, QR y código de barras generados con JS), datos dinámicos desde `localStorage`, **Actualizar datos**, **Dar de baja automóvil** (con confirmación), registro de vehículo nuevo, cerrar sesión y reinicio de demo.

### Accesibilidad
Alto contraste, textos grandes, objetivos táctiles ≥ 48 px, foco visible de 3 px, `aria-live` para avisos y cuenta regresiva, `role="slider"`, navegación por teclado y soporte de `prefers-reduced-motion`.

---

## Configuración tipo `.env`

El objeto `ENV_CONFIG` está al inicio del `<script>`. Puedes sobreescribirlo sin tocar el código mediante:

```html
<script>
  window.RUTACERO_ENV = { VITE_EMERGENCY_PHONE: '911', VITE_GEMINI_API_KEY: 'TU_LLAVE' };
</script>
```

O por URL:

```
index.html?VITE_EMERGENCY_PHONE=911&VITE_SOUND_ENABLED=false
```

O con `localStorage['rutacero.env.v1']`. Revisa `.env.example` para la lista completa. No hace falta configurar nada para la demo.

---

## Guion rápido de demostración (90 s)

1. **Llenar con datos de prueba** → **Ingresar a RutaCero**.
2. Señalar el banner naranja y los dos incidentes precargados en el mapa.
3. Tocar el **bache precargado** → **Vía libre** (ya trae 1 voto, basta uno más) → ver cómo desaparece y vuelve la ruta verde. Observa que la tarjeta **no tiene** botón de grúa.
4. **+ Bache / Bloqueo** → elegir *Inundación* → tocar el mapa → **Reportar en el mapa** (también es validación comunitaria).
5. Deslizar **EMERGENCIA** → dejar correr los 3 segundos → ver el resumen de contacto, grúa y Tránsito y el panel verde **“Tu reporte está activo en la red”** bajo el mapa.
6. Pulsar **✓ GRÚA RETIRÓ UNIDAD / YA ESTOY A SALVO** → tu punto rojo desaparece y el banner vuelve a verde.
7. **CHOQUE** → *Accidente menor* + *Grúa* → **LLAMAR Y SOLICITAR** → el panel propio vuelve a aparecer; ciérralo con el botón verde.
8. **CUENTA** → licencia vectorial → **Actualizar datos** y **Dar de baja automóvil**.

---

## Estructura

```
RutaCero/
├─ index.html       # Estructura y markup de las 3 pantallas
├─ styles.css       # Diseño mobile-first, mapa y componentes
├─ app.js           # Estado, localStorage, mapa y flujos
├─ .env.example     # Variables VITE_* simuladas
└─ README.md        # Este documento
```
